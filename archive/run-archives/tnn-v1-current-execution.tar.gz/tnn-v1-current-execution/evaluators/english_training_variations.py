from __future__ import annotations
import csv,json,random,re,statistics,collections,math,hashlib
from dataclasses import dataclass
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/english_training'; OUT.mkdir(parents=True,exist_ok=True)
DATA=ROOT/'datasets'; DATA.mkdir(parents=True,exist_ok=True)

ENTITIES=['robin','penguin','mars','venus','iron','water','fire','ice','oak','whale','dolphin','python','zag','compiler','bridge','river','planet','guitar','book','robot','nova','falcon','salmon','copper']
OBJECTS=['wings','fins','red','blue','hot','cold','heavy','light','wet','dry','roots','mammal','language','tool','safe','unsafe','strings','pages','metal','electricity','flight','ocean','forest','city']
SOURCES=['mira','jon','asha','lee','noor','world','manual','teacher']
RELATIONS={
 'has':{
  'assert':['{s} has {o}.','The {s} has {o}.','I learned that {s} has {o}.','According to {src}, {s} has {o}.','{src} says that {s} has {o}.'],
  'question':['Does {s} have {o}?','Is it true that {s} has {o}?','What does {s} have?']},
 'is':{
  'assert':['{s} is {o}.','The {s} is {o}.','I observed that {s} is {o}.','According to {src}, {s} is {o}.','{src} says {s} is {o}.'],
  'question':['Is {s} {o}?','What is {s}?','Would you say {s} is {o}?']},
 'can':{
  'assert':['{s} can {o}.','The {s} can {o}.','I observed {s} {o}.','According to {src}, {s} can {o}.','{src} claims that {s} can {o}.'],
  'question':['Can {s} {o}?','Is {s} able to {o}?','What can {s} do?']},
 'causes':{
  'assert':['{s} causes {o}.','{o} happens because of {s}.','I observed that {s} led to {o}.','According to {src}, {s} causes {o}.'],
  'question':['Does {s} cause {o}?','What causes {o}?','Why does {o} happen?']},
 'before':{
  'assert':['{s} happens before {o}.','{o} follows {s}.','I observed {s} before {o}.','According to {src}, {s} precedes {o}.'],
  'question':['Does {s} happen before {o}?','What comes before {o}?','Which happens first, {s} or {o}?']},
}
NEG_TEMPLATES={
 'has':['{s} does not have {o}.','The {s} lacks {o}.'],
 'is':['{s} is not {o}.','The {s} is not {o}.'],
 'can':['{s} cannot {o}.','The {s} is unable to {o}.'],
 'causes':['{s} does not cause {o}.','{o} is not caused by {s}.'],
 'before':['{s} does not happen before {o}.','{o} does not follow {s}.'],
}

def norm(s):
    s=s.lower().strip()
    s=re.sub(r'[^a-z0-9 ]+',' ',s)
    return re.sub(r'\s+',' ',s).strip()

def make_example(rng,split,noise=0.0,source_reliability=None):
    rel=rng.choice(list(RELATIONS)); s=rng.choice(ENTITIES); o=rng.choice(OBJECTS); src=rng.choice(SOURCES[:-1])
    pol=1 if rng.random()>.22 else -1
    templates=(RELATIONS[rel]['assert'] if pol>0 else NEG_TEMPLATES[rel])
    # Split by template index: final template held out where possible.
    if split=='train': choices=templates[:-1] if len(templates)>1 else templates
    else: choices=templates[-1:]
    template=rng.choice(choices)
    text=template.format(s=s,o=o,src=src)
    truth=(rel,s,o,pol)
    observed=truth
    if rng.random()<noise:
        observed=(rel,s,o,-pol)
    return {'text':text,'frame':truth,'observed_frame':observed,'source':src,'split':split,'template':template}

def char_features(text,n=(3,4,5)):
    t='^'+norm(text)+'$'; c=collections.Counter()
    for k in n:
        for i in range(len(t)-k+1): c[t[i:i+k]]+=1
    return c

def cosine(a,b):
    dot=sum(v*b.get(k,0) for k,v in a.items()); na=math.sqrt(sum(v*v for v in a.values())); nb=math.sqrt(sum(v*v for v in b.values()))
    return dot/(na*nb) if na and nb else 0

class CharCentroid:
    def fit(self,examples):
        self.byrel={}
        for e in examples:
            rel=e['observed_frame'][0]; f=char_features(e['text']); d=self.byrel.setdefault(rel,collections.Counter()); d.update(f)
    def predict_relation(self,text): return max(self.byrel,key=lambda r:cosine(char_features(text),self.byrel[r]))

class FixedWordTemplate:
    def fit(self,examples):
        self.patterns=[]
        for e in examples:
            rel,s,o,pol=e['observed_frame']; t=norm(e['text']); t=re.sub(rf'\b{re.escape(s)}\b','{s}',t); t=re.sub(rf'\b{re.escape(o)}\b','{o}',t)
            for src in SOURCES: t=re.sub(rf'\b{src}\b','{src}',t)
            self.patterns.append((t,rel,pol))
    def predict(self,text):
        t=norm(text)
        for ent in ENTITIES: t=re.sub(rf'\b{ent}\b','{s}',t, count=1)
        for obj in OBJECTS: t=re.sub(rf'\b{obj}\b','{o}',t, count=1)
        for src in SOURCES: t=re.sub(rf'\b{src}\b','{src}',t)
        for p,r,pol in self.patterns:
            if t==p:return r,pol
        return None

class AdaptiveMotifLearner:
    """Induces reversible construction motifs around grounded variable spans.
    This is not a neural implementation; it is an architecture/evaluator prototype.
    """
    def fit(self,examples,source_weights=None):
        votes=collections.defaultdict(collections.Counter)
        for e in examples:
            rel,s,o,pol=e['observed_frame']; t=norm(e['text'])
            # replace grounded spans; preserves all literal material as a reversible motif shell
            t=re.sub(rf'\b{re.escape(s)}\b','<S>',t)
            t=re.sub(rf'\b{re.escape(o)}\b','<O>',t)
            for src in SOURCES: t=re.sub(rf'\b{src}\b','<SRC>',t)
            # Optional article and common evidential phrases become alternatives learned by normalization.
            t=re.sub(r'^the ','',t)
            t=t.replace('i learned that ','').replace('i observed that ','<OBS> ').replace('according to <SRC> ','<SRC> ')
            t=t.replace('<SRC> says that ','<SRC> ').replace('<SRC> says ','<SRC> ').replace('<SRC> claims that ','<SRC> ')
            wt=(source_weights or {}).get(e['source'],1.0)
            votes[t][(rel,pol)]+=wt
        self.rules={p:max(c,key=c.get) for p,c in votes.items()}
    def abstract(self,text):
        t=norm(text); found_s=None;found_o=None
        for e in ENTITIES:
            if re.search(rf'\b{e}\b',t): found_s=e; t=re.sub(rf'\b{e}\b','<S>',t,count=1); break
        for o in OBJECTS:
            if re.search(rf'\b{o}\b',t): found_o=o; t=re.sub(rf'\b{o}\b','<O>',t,count=1); break
        for src in SOURCES: t=re.sub(rf'\b{src}\b','<SRC>',t)
        t=re.sub(r'^the ','',t)
        t=t.replace('i learned that ','').replace('i observed that ','<OBS> ').replace('according to <SRC> ','<SRC> ')
        t=t.replace('<SRC> says that ','<SRC> ').replace('<SRC> says ','<SRC> ').replace('<SRC> claims that ','<SRC> ')
        return t,found_s,found_o
    def predict(self,text):
        p,s,o=self.abstract(text)
        if p in self.rules: return (*self.rules[p],s,o)
        # partial literal motif match: most shared words with correct slot shape
        toks=set(p.split()); best=None
        for rp,v in self.rules.items():
            score=len(toks & set(rp.split()))/max(1,len(toks | set(rp.split())))
            if best is None or score>best[0]: best=(score,v)
        return (*best[1],s,o) if best and best[0]>=.55 else None

def train_source_weights(examples):
    # Directly tested examples reveal contextual source reliability; copied frequency is not truth.
    counts=collections.defaultdict(lambda:[1,1])
    for e in examples:
        counts[e['source']][1]+=1
        if e['frame']==e['observed_frame']: counts[e['source']][0]+=1
    return {s:a/b for s,(a,b) in counts.items()}

def run_condition(seed,condition):
    rng=random.Random(seed)
    if condition=='small_clean': n=80; noise=0
    elif condition=='large_noisy': n=1200; noise=.25
    elif condition=='provenance_noisy': n=1200; noise=.25
    elif condition=='clean_then_noisy': n=600; noise=.18
    elif condition=='noisy_then_clean': n=600; noise=.18
    elif condition=='duplicate_misinformation': n=1200; noise=.4
    else: n=400; noise=.1
    train=[make_example(rng,'train',noise) for _ in range(n)]
    # Make one source systematically more reliable and another misleading.
    if condition in ('provenance_noisy','duplicate_misinformation','clean_then_noisy','noisy_then_clean'):
        for i,e in enumerate(train):
            if e['source']=='mira': e['observed_frame']=e['frame']
            if e['source']=='jon' and i%3!=0: e['observed_frame']=(e['frame'][0],e['frame'][1],e['frame'][2],-e['frame'][3])
        if condition=='duplicate_misinformation':
            # Repeat copied wrong claims without creating independent evidence.
            bad=[e.copy() for e in train if e['source']=='jon'][:200]
            train.extend(bad*3)
    test=[make_example(rng,'test',0) for _ in range(500)]
    fixed=FixedWordTemplate(); fixed.fit(train)
    char=CharCentroid(); char.fit(train)
    am=AdaptiveMotifLearner(); am.fit(train)
    weights=train_source_weights(train)
    pam=AdaptiveMotifLearner(); pam.fit(train,weights if condition!='large_noisy' else None)
    scores={'fixed':0,'char_relation':0,'adaptive_motif':0,'provenance_motif':0}
    for e in test:
        rel,s,o,pol=e['frame']
        q=fixed.predict(e['text']); scores['fixed']+=q==(rel,pol)
        scores['char_relation']+=char.predict_relation(e['text'])==rel
        a=am.predict(e['text']); scores['adaptive_motif']+=bool(a and a[0]==rel and a[1]==pol)
        a=pam.predict(e['text']); scores['provenance_motif']+=bool(a and a[0]==rel and a[1]==pol)
    return {'seed':seed,'condition':condition,'train_examples':len(train),**{k:v/len(test) for k,v in scores.items()}}

def main():
    conditions=['small_clean','large_noisy','provenance_noisy','clean_then_noisy','noisy_then_clean','duplicate_misinformation']
    rows=[run_condition(seed,c) for seed in range(24) for c in conditions]
    with (OUT/'runs.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    summary=[]
    for c in conditions:
        rs=[r for r in rows if r['condition']==c]; rec={'condition':c,'runs':len(rs),'mean_train_examples':statistics.mean(r['train_examples'] for r in rs)}
        for k in ('fixed','char_relation','adaptive_motif','provenance_motif'):
            vals=[r[k] for r in rs]; rec[k+'_mean']=statistics.mean(vals); rec[k+'_min']=min(vals);rec[k+'_max']=max(vals)
        summary.append(rec)
    with (OUT/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
    best=max(((r['provenance_motif_mean'],r['condition']) for r in summary))
    checks={
      'adaptive_beats_fixed_small_clean':next(r for r in summary if r['condition']=='small_clean')['adaptive_motif_mean']>next(r for r in summary if r['condition']=='small_clean')['fixed_mean'],
      'provenance_beats_naive_noisy':next(r for r in summary if r['condition']=='provenance_noisy')['provenance_motif_mean']>=next(r for r in summary if r['condition']=='provenance_noisy')['adaptive_motif_mean'],
      'duplicate_frequency_not_authority':next(r for r in summary if r['condition']=='duplicate_misinformation')['provenance_motif_mean']>next(r for r in summary if r['condition']=='duplicate_misinformation')['adaptive_motif_mean'],
    }
    result={'conditions':summary,'best':best,'checks':checks,'pass':all(checks.values()),'scope':'controlled construction induction; not teenager/adult English'}
    (OUT/'summary.json').write_text(json.dumps(result,indent=2))
    # Export a corpus sample and exact split for future native port.
    rng=random.Random(919)
    corpus=[make_example(rng,'train',.1) for _ in range(2000)]
    (DATA/'english_grounded_construction_corpus.json').write_text(json.dumps(corpus,indent=2))
if __name__=='__main__':main()
