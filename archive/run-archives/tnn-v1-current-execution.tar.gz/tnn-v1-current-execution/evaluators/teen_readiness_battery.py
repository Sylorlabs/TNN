from __future__ import annotations
import json,subprocess,random,csv,re,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/teen_readiness';OUT.mkdir(parents=True,exist_ok=True)
best=json.loads((ROOT/'results/best_runtime_candidate.json').read_text());mode=best.get('mode','nostate');binary=ROOT/'bin/tnn-english-a'
entities=['robin','penguin','mars','venus','iron','water','fire','ice','oak','whale','dolphin','python','zag','compiler','bridge','river','planet','guitar','book','robot','nova','falcon','salmon','copper','silver','forest','ocean','clock','house','car','plane']
props=['wings','fins','red','blue','hot','cold','heavy','light','wet','dry','roots','mammal','language','tool','safe','unsafe','strings','pages','metal','electricity','engines','windows','wheels','hands','green','white','fast','slow']
sources=['mira','jon','asha','lee','noor']
rng=random.Random(9051)

def run(dialog,state):
    args=[str(binary)]+([str(OUT/state)] if mode=='state' else [])
    p=subprocess.run(args,input=dialog,capture_output=True,text=True,timeout=30,cwd=str(ROOT))
    return p

def has(out,groups):
    l=out.lower();return all(any(x in l for x in g) for g in groups)
rows=[]
# Level A: direct grounded sentence memory, 200.
for i in range(200):
    e=rng.choice(entities);p=rng.choice(props);dialog=f'{e.capitalize()} has {p}.\nDoes {e} have {p}?\n'
    state=f'a-{i}.tnn';sp=OUT/state
    if sp.exists():sp.unlink()
    q=run(dialog,state);passed=has(q.stdout,[[e],[p],['yes','support','has','evidence']])
    rows.append({'id':f'A-{i}','tier':'direct','pass':passed,'rc':q.returncode})
# Level B: observation beats assertion/opinion, 100.
for i in range(100):
    e=rng.choice(entities);wrong,right=rng.sample(props,2);src=rng.choice(sources)
    dialog=f'According to {src}, {e} is {wrong}.\nI observed that {e} is {right}.\nIs {e} {wrong}?\nWhat is {e}?\n'
    state=f'b-{i}.tnn';sp=OUT/state
    if sp.exists():sp.unlink()
    q=run(dialog,state);passed=has(q.stdout,[[e],[right],['no','contradict','observation','evidence']])
    rows.append({'id':f'B-{i}','tier':'epistemic','pass':passed,'rc':q.returncode})
# Level C: paraphrase/pronoun/conjunction, 100.
for i in range(100):
    e=rng.choice(entities);p1,p2=rng.sample(props,2)
    dialog=f'The {e} has {p1} and {p2}.\nIt is important.\nWhat does the {e} have?\n'
    state=f'c-{i}.tnn';sp=OUT/state
    if sp.exists():sp.unlink()
    q=run(dialog,state);passed=has(q.stdout,[[e],[p1],[p2]])
    rows.append({'id':f'C-{i}','tier':'composition','pass':passed,'rc':q.returncode})
# Level D: rule transfer, 100.
for i in range(100):
    ex=rng.sample(entities,4);p=rng.choice(props);ability=rng.choice(['fly','move','conduct electricity','stay warm','make sound'])
    dialog=''.join(f'{x.capitalize()} has {p}.\n{x.capitalize()} can {ability}.\n' for x in ex[:3])+f'{ex[3].capitalize()} has {p}.\nCan {ex[3]} {ability}?\n'
    state=f'd-{i}.tnn';sp=OUT/state
    if sp.exists():sp.unlink()
    q=run(dialog,state);passed=has(q.stdout,[[ex[3]],[ability.split()[-1]],['yes','infer','support','likely']])
    rows.append({'id':f'D-{i}','tier':'relational_transfer','pass':passed,'rc':q.returncode})
# Level E: multisentence delayed retrieval across restart, 50.
for i in range(50):
    facts=[];chosen=[]
    for _ in range(8):
        e=rng.choice(entities);p=rng.choice(props);facts.append(f'{e.capitalize()} has {p}.');chosen.append((e,p))
    state=f'e-{i}.tnn';sp=OUT/state
    if sp.exists():sp.unlink()
    run('\n'.join(facts)+'\n',state)
    e,p=rng.choice(chosen);q=run(f'Does {e} have {p}?\n',state);passed=has(q.stdout,[[e],[p],['yes','support','has','evidence']])
    rows.append({'id':f'E-{i}','tier':'delayed_memory','pass':passed,'rc':q.returncode})
with (OUT/'cases.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
tiers={}
for r in rows:tiers.setdefault(r['tier'],[]).append(r['pass'])
summary={'cases':len(rows),'accuracy':sum(r['pass'] for r in rows)/len(rows),'tier_scores':{k:sum(v)/len(v) for k,v in tiers.items()},
         'teenager_level_qualified':False,'adult_level_qualified':False,
         'qualification_rule':'Teenager level requires natural unseen reading, dialogue, narrative, instruction, vocabulary, ambiguity, and broad transfer—not generated construction accuracy alone.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
