from __future__ import annotations
from pathlib import Path
import json,subprocess,shutil,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]
res=json.loads((ROOT/'results/candidate_compilation_std.json').read_text())
probes=json.loads((ROOT/'results/probe_summary.json').read_text())
probe_by={(p['index'],p['mode']):p for p in probes}
records=[]
for cand in res:
    if cand['compile_rc']!=0:continue
    idx=cand['index']
    for mode in ('state','nostate'):
        pinfo=probe_by.get((idx,mode))
        if pinfo is None:continue
        shutil.copy2(cand['copy'],ROOT/'canonical/english_brain_candidate.zag')
        best={**cand,'mode':mode,'score':pinfo.get('score',0),'checks':pinfo.get('checks',{})}
        (ROOT/'results/best_runtime_candidate.json').write_text(json.dumps(best,indent=2))
        # Clear old qualification/state and run qualifier + battery.
        for p in (ROOT/'results').glob('verify-*.tnn'):p.unlink()
        q=subprocess.run(['python3',str(ROOT/'evaluators/qualify_english.py')],cwd=str(ROOT),capture_output=True,text=True,timeout=300)
        b=subprocess.run(['python3',str(ROOT/'evaluators/english_battery.py')],cwd=str(ROOT),capture_output=True,text=True,timeout=300)
        try:qual=json.loads((ROOT/'results/english_qualification.json').read_text())
        except:qual={}
        try:bat=json.loads((ROOT/'results/english_battery/summary.json').read_text())
        except:bat={}
        record={'candidate_index':idx,'mode':mode,'source':cand['source'],'bytes':cand['bytes'],'sha256':cand['sha256'],
                'qualifier_pass':bool(qual.get('pass')),'battery_accuracy':bat.get('accuracy',0),'battery_passed':bat.get('passed',0),
                'persistence':bool(bat.get('persistence_reload')),'assessment':bat.get('assessment'),'qualifier':qual,'battery':bat,
                'qualifier_rc':q.returncode,'battery_rc':b.returncode}
        records.append(record)
# Rank by held-out battery, persistence, qualifier, then size.
if not records:
    (ROOT/'results/english_candidate_tournament.json').write_text(json.dumps({'error':'no compilable candidates'},indent=2));sys.exit(0)
records.sort(key=lambda r:(r['battery_accuracy'],r['persistence'],r['qualifier_pass'],r['bytes']),reverse=True)
winner=records[0]
# Restore winner and generate final results.
cand=next(r for r in res if r['index']==winner['candidate_index'])
shutil.copy2(cand['copy'],ROOT/'canonical/english_brain_candidate.zag')
best={**cand,'mode':winner['mode'],'score':probe_by[(winner['candidate_index'],winner['mode'])].get('score',0),'checks':probe_by[(winner['candidate_index'],winner['mode'])].get('checks',{})}
(ROOT/'results/best_runtime_candidate.json').write_text(json.dumps(best,indent=2))
subprocess.run(['python3',str(ROOT/'evaluators/qualify_english.py')],cwd=str(ROOT),check=False,timeout=300)
subprocess.run(['python3',str(ROOT/'evaluators/english_battery.py')],cwd=str(ROOT),check=False,timeout=300)
(ROOT/'results/english_candidate_tournament.json').write_text(json.dumps({'winner':winner,'candidates':records},indent=2))
