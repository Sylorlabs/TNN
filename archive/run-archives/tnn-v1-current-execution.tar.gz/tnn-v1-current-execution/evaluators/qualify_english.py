from __future__ import annotations
from pathlib import Path
import json,subprocess,shutil,hashlib,time,statistics,sys
ROOT=Path(__file__).resolve().parents[1]
RESULTS=ROOT/'results'; LOGS=ROOT/'logs'; BIN=ROOT/'bin'
RESULTS.mkdir(exist_ok=True);LOGS.mkdir(exist_ok=True);BIN.mkdir(exist_ok=True)
best_path=RESULTS/'best_runtime_candidate.json'
metrics={'stage':'english-native-qualification'}
if not best_path.exists():
    metrics.update({'pass':False,'reason':'no runtime candidate'});(RESULTS/'english_qualification.json').write_text(json.dumps(metrics,indent=2));sys.exit(0)
best=json.loads(best_path.read_text()); metrics['candidate']=best
src=ROOT/'canonical/english_brain_candidate.zag'
if not src.exists():
    metrics.update({'pass':False,'reason':'canonical source missing'});(RESULTS/'english_qualification.json').write_text(json.dumps(metrics,indent=2));sys.exit(0)
zn=str(ROOT/'toolchain/pinned/znc'); proj=ROOT/'canonical_project';proj.mkdir(exist_ok=True)
shutil.copy2(src,proj/'main.zag');(proj/'zag.mod').write_text('edition = "2027"\n')
a=BIN/'tnn-english-a';b=BIN/'tnn-english-b';c=BIN/'tnn-english-checked'
def comp(out,extra=[]):return subprocess.run([zn,str(proj/'main.zag'),'-o',str(out),'--no-zagd','--no-foreground-cache','--analyze-strict',*extra],cwd=str(ROOT),capture_output=True,text=True)
ca=comp(a);cb=comp(b);cc=comp(c,['--safety=checked'])
for name,p in [('english-normal-a.log',ca),('english-normal-b.log',cb),('english-checked.log',cc)]: (LOGS/name).write_text((p.stdout or '')+(p.stderr or ''))
metrics.update({'compile_a':ca.returncode,'compile_b':cb.returncode,'compile_checked':cc.returncode})
if ca.returncode or cb.returncode or cc.returncode:
    metrics.update({'pass':False,'reason':'compile failure'});(RESULTS/'english_qualification.json').write_text(json.dumps(metrics,indent=2));sys.exit(0)
metrics['binary_identical']=a.read_bytes()==b.read_bytes();mode=best.get('mode','nostate')
def run(binary,state,dialog):
    args=[str(binary)]+([str(RESULTS/state)] if mode=='state' else [])
    return subprocess.run(args,input=dialog,capture_output=True,text=True,timeout=30,cwd=str(ROOT))
dialog='''Robin has wings.\nAccording to Mira, robin can fly.\nPenguin has wings.\nI observed that penguin cannot fly.\nDoes robin have wings?\nCan penguin fly?\nWhat does robin have?\nWhy do you think robin has wings?\nI think Mars is blue.\nI observed that Mars is red.\nIs Mars blue?\nWhat is Mars?\nIt is cold.\nWhat is Mars?\n'''

for q in ('verify-normal.tnn','verify-checked.tnn'):
    x=RESULTS/q
    if x.exists(): x.unlink()
rn=run(a,'verify-normal.tnn',dialog);rc=run(c,'verify-checked.tnn',dialog)
(RESULTS/'english-normal-transcript.txt').write_text((rn.stdout or '')+(rn.stderr or ''));(RESULTS/'english-checked-transcript.txt').write_text((rc.stdout or '')+(rc.stderr or ''))
metrics['run_normal_rc']=rn.returncode;metrics['run_checked_rc']=rc.returncode;metrics['normal_checked_equal']=rn.stdout==rc.stdout
low=(rn.stdout or '').lower();criteria={'understands_assertion':'robin' in low and 'wings' in low,'handles_negative':'penguin' in low and any(x in low for x in ['cannot','contradict','no.']),'source_or_evidence':any(x in low for x in ['mira','source','evidence','according']),'opinion_not_fact':any(x in low for x in ['opinion','not established','provisional']),'observation_revision':'mars' in low and 'red' in low,'explanation':any(x in low for x in ['because','why','evidence'])};metrics['criteria']=criteria
if mode=='state':
    rr=run(a,'verify-normal.tnn','What does robin have?\nCan penguin fly?\nWhat is Mars?\n');rlow=(rr.stdout or '').lower();metrics['state_reload_rc']=rr.returncode;metrics['state_reload_pass']='robin' in rlow and 'penguin' in rlow and 'mars' in rlow;(RESULTS/'english-reload-transcript.txt').write_text((rr.stdout or '')+(rr.stderr or ''))
else: metrics['state_reload_pass']=False
# Speed is measured separately from functional pass.
bench='Robin has wings.\nDoes robin have wings?\n';times=[];outs=[]
for i in range(20):
    bp=RESULTS/f'verify-bench-{i}.tnn'
    if bp.exists(): bp.unlink()
    t0=time.perf_counter();p=run(a,f'verify-bench-{i}.tnn',bench);times.append(time.perf_counter()-t0);outs.append(len((p.stdout or '').encode()))
metrics['benchmark']={'repetitions':len(times),'median_ms':statistics.median(times)*1000,'p95_ms':sorted(times)[max(0,int(len(times)*.95)-1)]*1000,'dialogues_per_second':len(times)/sum(times),'mean_output_bytes':statistics.mean(outs),'surface_bytes_per_second':sum(outs)/sum(times)}
metrics['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest();metrics['source_bytes']=src.stat().st_size
metrics['pass']=metrics['binary_identical'] and metrics['normal_checked_equal'] and sum(criteria.values())>=4
metrics['claimed_level']='controlled free-form English, below teenager-level' if metrics['pass'] else 'not qualified'
(RESULTS/'english_qualification.json').write_text(json.dumps(metrics,indent=2))
