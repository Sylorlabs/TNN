from __future__ import annotations
import json,subprocess,time,statistics,random,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
Q=ROOT/'results/english_qualification.json'
OUT=ROOT/'results/english_battery'
OUT.mkdir(parents=True,exist_ok=True)
if not Q.exists():
    (OUT/'summary.json').write_text(json.dumps({'pass':False,'reason':'qualification missing'},indent=2)); raise SystemExit
qual=json.loads(Q.read_text())
if not qual.get('candidate') or not Path(ROOT/'bin/tnn-english-a').exists():
    (OUT/'summary.json').write_text(json.dumps({'pass':False,'reason':'native English binary unavailable'},indent=2)); raise SystemExit
binary=ROOT/'bin/tnn-english-a'; mode=qual['candidate'].get('mode')

def run(dialogue:str,state:str):
    args=[str(binary)]
    if mode=='state': args.append(str(OUT/state))
    return subprocess.run(args,input=dialogue,capture_output=True,text=True,timeout=30,cwd=str(ROOT))

def check_contains(out:str,*groups):
    low=out.lower()
    return all(any(term.lower() in low for term in group) for group in groups)

cases=[]
def add(cid,category,dialogue,expected_groups,description):
    cases.append({'id':cid,'category':category,'dialogue':dialogue,'expected_groups':expected_groups,'description':description})

# Core natural constructions.
for i,(entity,part) in enumerate([('robin','wings'),('shark','fins'),('car','wheels'),('tree','roots'),('book','pages'),('guitar','strings'),('house','windows'),('dog','fur'),('plane','engines'),('clock','hands')]):
    add(f'fact-{i}','simple facts',f'{entity.capitalize()} has {part}.\nDoes {entity} have {part}?\n',[[entity],[part],['yes','support','evidence','has']], 'learn then answer a natural yes/no fact')
for i,(entity,action) in enumerate([('penguin','fly'),('stone','breathe'),('fish','walk'),('ice','burn'),('square','roll')]):
    add(f'neg-{i}','negation',f'{entity.capitalize()} cannot {action}.\nCan {entity} {action}?\n',[[entity],[action],['no','cannot','contradict']], 'preserve explicit negation')
for i,(entity,wrong,right) in enumerate([('mars','blue','red'),('leaf','purple','green'),('snow','black','white'),('sun','cold','hot'),('ocean','dry','wet')]):
    add(f'epistemic-{i}','opinion versus observation',f'I think {entity} is {wrong}.\nI observed that {entity} is {right}.\nIs {entity} {wrong}?\nWhat is {entity}?\n',[[entity],[right],['no','contradict','observation','evidence']], 'observation should outrank opinion without deleting history')
for i,(source,entity,prop) in enumerate([('Mira','robin','can fly'),('Jon','iron','is heavy'),('Asha','water','is wet'),('Lee','fire','is hot'),('Noor','ice','is cold')]):
    add(f'source-{i}','source attribution',f'According to {source}, {entity} {prop}.\nWhy do you think {entity} {prop}?\n',[[entity],[source.lower(),'source','according','evidence']], 'retain source provenance')
# Pronoun continuity.
add('pronoun-1','pronouns','Mars is a planet.\nIt is cold.\nWhat is Mars?\n',[['mars'],['planet','cold']], 'resolve recent singular pronoun')
add('pronoun-2','pronouns','The robot is metal.\nIt has wheels.\nWhat does the robot have?\n',[['robot'],['wheels']], 'pronoun plus article')
# Correction and contradictions.
add('corr-1','correction','Mira says that mercury is cold.\nCorrection: mercury is hot.\nIs mercury cold?\nWhat is mercury?\n',[['mercury'],['hot'],['no','contradict','correct']], 'natural correction')
add('conflict-1','conflicting evidence','According to Mira, the bridge is safe.\nAccording to Jon, the bridge is unsafe.\nIs the bridge safe?\n',[['bridge'],['uncertain','conflict','evidence','source']], 'preserve unresolved conflict')
# Conjunctions and paraphrases likely beyond original grammar.
add('conj-1','conjunction','A robin has wings and feathers.\nWhat does a robin have?\n',[['robin'],['wings'],['feathers']], 'learn coordinated objects')
add('para-1','paraphrase','Mira says that whales are mammals.\nAre whales mammals?\n',[['whales'],['mammals'],['yes','support','evidence']], 'source paraphrase')
add('para-2','paraphrase','From my observation, copper conducts electricity.\nDoes copper conduct electricity?\n',[['copper'],['electricity'],['yes','support','evidence']], 'observation paraphrase')
# Simple rule / transfer.
add('rule-1','relational transfer','Robin has wings.\nRobin can fly.\nEagle has wings.\nEagle can fly.\nCrow has wings.\nCrow can fly.\nNova has wings.\nCan Nova fly?\n',[['nova'],['fly'],['infer','yes','support','likely']], 'induce a relation and transfer it')
# Multi-turn persistence in one process.
add('long-1','long session','Robin has wings.\nMars is red.\nPenguin cannot fly.\nBook has pages.\nGuitar has strings.\nDoes robin have wings?\nCan penguin fly?\nWhat is Mars?\nWhat does book have?\nWhat does guitar have?\n',[['robin'],['penguin'],['mars'],['book'],['guitar']], 'retain several unrelated facts in active session')

results=[]
for case in cases:
    state=f"{case['id']}.tnn"
    sp=OUT/state
    if sp.exists(): sp.unlink()
    p=run(case['dialogue'],state)
    out=(p.stdout or '')+(p.stderr or '')
    passed=p.returncode==0 and check_contains(out,*case['expected_groups'])
    (OUT/f"{case['id']}.txt").write_text(out)
    results.append({**{k:v for k,v in case.items() if k not in ('dialogue','expected_groups')},'pass':passed,'returncode':p.returncode,'output_file':str(OUT/f"{case['id']}.txt")})
# Persistence test across process restart.
persist_dialogue='Robin has wings.\nPenguin cannot fly.\nMars is red.\n'
pp=OUT/'persistence.tnn'
if pp.exists(): pp.unlink()
p=run(persist_dialogue,'persistence.tnn')
r=run('Does robin have wings?\nCan penguin fly?\nWhat is Mars?\n','persistence.tnn')
persist_out=(r.stdout or '')+(r.stderr or '')
persist=check_contains(persist_out,['robin'],['penguin'],['mars'])
(OUT/'persistence-reload.txt').write_text(persist_out)
# Aggregate by category.
cats={}
for r0 in results:
    cats.setdefault(r0['category'],[]).append(r0['pass'])
category_scores={k:sum(v)/len(v) for k,v in cats.items()}
score=sum(r['pass'] for r in results)/len(results)
# Level labels are conservative and empirical for this battery only.
if score>=.95 and persist and all(category_scores.get(c,0)>=.8 for c in ('paraphrase','pronouns','relational transfer','conflicting evidence')):
    level='broad short-form construction competence; still not teenager-level'
elif score>=.75 and persist:
    level='controlled conversational English prototype'
elif score>=.5:
    level='early grounded English'
else:
    level='below conversational threshold'
summary={'cases':len(results),'passed':sum(r['pass'] for r in results),'accuracy':score,'persistence_reload':persist,'category_scores':category_scores,'assessment':level,'teenager_level_qualified':False,'adult_level_qualified':False}
(OUT/'case_results.json').write_text(json.dumps(results,indent=2))
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
