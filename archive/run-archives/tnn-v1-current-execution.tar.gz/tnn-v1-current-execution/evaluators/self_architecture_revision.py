from __future__ import annotations
import csv,json,statistics,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/self_revision';OUT.mkdir(parents=True,exist_ok=True)

def load(path):
    with open(path,newline='') as f:return list(csv.DictReader(f))
rows=load(ROOT/'results/sensory_deep/pam_noise_runs.csv')
for r in rows:
    for k in list(r):
        try:r[k]=float(r[k])
        except:pass
train=[r for r in rows if int(r['seed'])<8]
test=[r for r in rows if int(r['seed'])>=8]
architectures=['central','mini','pam']
# Utility is not a universal TNN objective; this is an evaluator's external measurement combining correctness and cost.
def utility(r,a,cost_weight):return r[f'{a}_accuracy']-cost_weight*r[f'{a}_cost']/1_000_000
# Global replacement: choose one architecture from train.
results=[]
for cw in (0,0.0005,0.001,0.002,0.005,0.01):
    global_choice=max(architectures,key=lambda a:statistics.mean(utility(r,a,cw) for r in train))
    # Contextual architecture revision: choose by (noise band, base frames) from shadow trials.
    policy={}
    for noise in sorted(set(r['noise'] for r in train)):
      for frames in sorted(set(r['base_frames'] for r in train)):
        subset=[r for r in train if r['noise']==noise and r['base_frames']==frames]
        policy[(noise,frames)]=max(architectures,key=lambda a:statistics.mean(utility(r,a,cw) for r in subset))
    def eval_policy(kind):
        vals=[];acc=[];cost=[];counts=collections.Counter()
        for r in test:
            a=global_choice if kind=='global' else policy[(r['noise'],r['base_frames'])]
            vals.append(utility(r,a,cw));acc.append(r[f'{a}_accuracy']);cost.append(r[f'{a}_cost']);counts[a]+=1
        return statistics.mean(vals),statistics.mean(acc),statistics.mean(cost),dict(counts)
    gu,ga,gc,gcnt=eval_policy('global');cu,ca,cc,ccnt=eval_policy('contextual')
    results.append({'cost_weight':cw,'global_choice':global_choice,'global_utility':gu,'global_accuracy':ga,'global_cost':gc,
                    'contextual_utility':cu,'contextual_accuracy':ca,'contextual_cost':cc,'contextual_choices':ccnt,'policy':{f'{k[0]}|{k[1]}':v for k,v in policy.items()}})
# Architecture replacement stress: one sensor changes after training; selector must reopen alternatives.
# Use heldout rows but artificially degrade previously chosen central at high noise to model sensor change.
stress=[]
for rec in results:
    cw=rec['cost_weight']; policy={tuple(map(float,k.split('|'))):v for k,v in rec['policy'].items()}
    before=after=0
    changed=0
    for r in test:
        key=(r['noise'],r['base_frames']); old=policy[key]
        old_score=utility(r,old,cw)
        scores={a:utility(r,a,cw) for a in architectures}
        if r['noise']>=.3: scores['central']-=.25
        new=max(scores,key=scores.get)
        before+=old_score;after+=scores[new];changed+=new!=old
    stress.append({'cost_weight':cw,'mean_old':before/len(test),'mean_revised':after/len(test),'contexts_revised':changed})
summary={'contextual_results':results,'sensor_change_stress':stress,
         'checks':{
          'contextual_not_worse_than_global':all(r['contextual_utility']>=r['global_utility']-1e-9 for r in results),
          'revision_improves_after_sensor_change':all(r['mean_revised']>=r['mean_old'] for r in stress),
          'retains_multiple_architectures':any(len(r['contextual_choices'])>1 for r in results),
         },
         'scope':'evaluator-level shadow comparison; not autonomous production self-rewrite'}
summary['pass']=all(summary['checks'].values())
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
with (OUT/'contextual_revision.csv').open('w',newline='') as f:
    fields=['cost_weight','global_choice','global_utility','global_accuracy','global_cost','contextual_utility','contextual_accuracy','contextual_cost','contextual_choices']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();
    for r in results:w.writerow({k:r[k] for k in fields})
with (OUT/'sensor_change_stress.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=stress[0].keys());w.writeheader();w.writerows(stress)
