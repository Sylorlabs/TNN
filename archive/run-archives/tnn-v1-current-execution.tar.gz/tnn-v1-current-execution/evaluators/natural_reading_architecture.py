from __future__ import annotations
import json,re,math,collections,random,statistics,csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/natural_reading_architecture';OUT.mkdir(parents=True,exist_ok=True)
data=json.loads((ROOT/'datasets/raw_archives/squad-dev-v1.1.json').read_text())

def sentences(text):
    spans=[]
    for m in re.finditer(r'[^.!?]+(?:[.!?]+|$)',text):
        s=m.group(0).strip()
        if s:spans.append((m.start(),m.end(),s))
    return spans

def char_motifs(s,ks=(3,4,5,6)):
    t=' '+re.sub(r'\s+',' ',s.lower())+' '
    c=collections.Counter()
    for k in ks:
        for i in range(len(t)-k+1):
            g=t[i:i+k]
            if any(ch.isalpha() for ch in g):c[g]+=1
    return c

def wordset(s):return set(re.findall(r"[a-z0-9']+",s.lower()))
records=[]
for ai,art in enumerate(data['data']):
    for para in art['paragraphs']:
        ss=sentences(para['context'])
        for qa in para['qas']:
            if not qa.get('answers'):continue
            ans=qa['answers'][0];pos=ans['answer_start'];target=0
            for i,(a,b,s) in enumerate(ss):
                if a<=pos<b:target=i;break
            records.append({'article':ai,'question':qa['question'],'sentences':[s for _,_,s in ss],'target':target})
# Article-disjoint split.
articles=sorted(set(r['article'] for r in records));rng=random.Random(620);rng.shuffle(articles);cut=int(len(articles)*.55);train_ids=set(articles[:cut]);test_ids=set(articles[cut:])
train=[r for r in records if r['article'] in train_ids][:2500];test=[r for r in records if r['article'] in test_ids][:1000]
# Motif IDF over training question/sentence material.
df=collections.Counter();N=0
for r in train:
    for text in [r['question'],*r['sentences']]:
        N+=1;df.update(set(char_motifs(text)))
idf={g:math.log((N+1)/(v+1))+1 for g,v in df.items()}
# Learn which motif correspondences are useful by comparing answer versus non-answer co-occurrence.
assoc=collections.Counter();base=collections.Counter()
for r in train:
    q=set(char_motifs(r['question']))
    for i,s in enumerate(r['sentences']):
        sm=set(char_motifs(s));target=i==r['target']
        shared=q&sm
        for g in shared:
            if target:assoc[g]+=1
            else:base[g]+=1
weights={g:math.log((assoc[g]+1)/(base[g]+1)) for g in set(assoc)|set(base)}

def overlap_score(q,s):
    qset=wordset(q);sset=wordset(s);return len(qset&sset)/max(1,len(qset|sset))
def motif_score(q,s):
    qf=char_motifs(q);sf=char_motifs(s);shared=set(qf)&set(sf)
    num=sum(idf.get(g,1)**2*max(.05,1+weights.get(g,0)) for g in shared)
    den=math.sqrt(sum(idf.get(g,1)**2 for g in qf))*math.sqrt(sum(idf.get(g,1)**2 for g in sf))
    return num/den if den else 0
rows=[]
for r in test:
    first=0
    ov=max(range(len(r['sentences'])),key=lambda i:overlap_score(r['question'],r['sentences'][i]))
    am=max(range(len(r['sentences'])),key=lambda i:motif_score(r['question'],r['sentences'][i]))
    rows.append({'first':int(first==r['target']),'word_overlap':int(ov==r['target']),'adaptive_motif':int(am==r['target'])})
summary={'train_records':len(train),'test_records':len(test),'article_disjoint':True,
         'first_sentence_accuracy':statistics.mean(x['first'] for x in rows),
         'word_overlap_accuracy':statistics.mean(x['word_overlap'] for x in rows),
         'adaptive_motif_accuracy':statistics.mean(x['adaptive_motif'] for x in rows),
         'scope':'answer-bearing sentence retrieval, not adult semantic answering'}
summary['checks']={'adaptive_beats_first':summary['adaptive_motif_accuracy']>summary['first_sentence_accuracy'],'adaptive_not_worse_than_word_overlap':summary['adaptive_motif_accuracy']>=summary['word_overlap_accuracy']-.01}
summary['pass']=all(summary['checks'].values())
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
with (OUT/'cases.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
