# Repeated TNN terms

- **PAM — Peripheral Adaptive Microcircuit:** persistent local sensory neural tissue; not a separate brain.
- **Fiber:** temporary concurrent train of thought inside the one shared TNN brain.
- **FMC — Fiber-to-Memory Consolidation:** preserves useful discoveries from temporary fibers in shared long-term memory.
- **SCD — State-Continuous Development:** continue training from the accepted current brain rather than restarting.
- **Adaptive Motif:** reversible self-learned chunk or construction over raw text, sound, vision, action, or thought.
- **EGRD — Evidence-Grounded Relational Dynamics:** logic-centered belief formation using evidence, assumptions, derivations, conflict, and uncertainty.
- **SAR — Self-Architecture Revision:** controlled evidence-based modification of TNN's own mechanisms.
- **CAR — Contextual Architecture Revision:** retain multiple mechanisms when each is best in a different context.
- **CRE — Cognitive Resource Envelope:** human-defined RAM, storage, compute, sensor, and tool limits; TNN decides allocation within them.
