# Teenager and adult English gap report

## Controlled generated-language battery

- Cases: `n/a`
- Accuracy: `0.0%`
- Tier scores:

```json
{}
```

This battery is useful for regression testing, but it cannot qualify teenager English because the constructions and semantics are generated.

## Natural prose probe

- Natural reading cases: `n/a`
- Exact answer-substring accuracy: `0.0%`

The natural prose probe deliberately feeds unchanged public reading passages and questions to the native English candidate. It exposes the gap between controlled fact grammar and real reading comprehension.

## Adaptive Motif reading architecture

- Article-disjoint training records: `n/a`
- Article-disjoint test records: `n/a`
- First-sentence baseline: `0.0%`
- Word-overlap baseline: `0.0%`
- Adaptive Motif retrieval: `0.0%`

This architecture retrieves an answer-bearing sentence. It does not yet derive and express unrestricted answers, so it remains a training mechanism rather than teenager English.

## Promotion boundary

Teenager-level English requires natural unseen reading, ordinary dialogue, narrative continuity, instructions, vocabulary acquisition, ambiguity, social language, and persistent learning. Adult English additionally requires professional writing, long technical discourse, metaphor, humor, broad domain transfer, and spoken interaction.

Current result:

```text
TEENAGER_ENGLISH=0
ADULT_ENGLISH=0
```
