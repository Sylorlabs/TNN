# Self-Architecture Revision results

**SAR — Self-Architecture Revision**: TNN models the consequences of its own mechanisms, tests alternatives in shadow continuations, and can modify or replace a mechanism after regression tests.

**CAR — Contextual Architecture Revision**: TNN retains more than one mechanism when different contexts justify different designs instead of globally replacing A with B.

The present experiment uses held-out shadow evaluations over central, sensory-mini-brain, and PAM architectures. Its checks are:

```json
{}
```

Pass: `n/a`

This is evaluator-level architecture selection, not autonomous source rewriting. The next native gate is for the same persistent Zag brain to propose, test, migrate, and roll back a local architecture change itself.
