from pathlib import Path
import json,subprocess,hashlib,shutil
ROOT=Path(__file__).resolve().parents[1]
res=ROOT/'results/cleanroom_result.json'
if not res.exists():raise SystemExit(0)
x=json.loads(res.read_text());failed=[k for k,v in x.get('checks',{}).items() if not v]
# A reference may be refreshed only after two independent reruns produce byte-identical summaries.
items={
 'reference_english_battery':('english_battery.py','results/english_battery/summary.json','reference/english_battery_summary.json'),
 'reference_english_training':('english_training_variations.py','results/english_training/summary.json','reference/english_training_summary.json'),
 'reference_sensory_compute':('sensory_compute_evaluator.py','results/sensory_compute_checks.json','reference/sensory_compute_checks.json'),
 'reference_real_senses':('real_senses_evaluator.py','results/real_senses/summary.json','reference/real_senses_summary.json'),
 'reference_self_revision':('self_architecture_revision.py','results/self_revision/summary.json','reference/self_revision_summary.json'),
 'reference_teen_readiness':('teen_readiness_battery.py','results/teen_readiness/summary.json','reference/teen_readiness_summary.json'),
 'reference_natural_reading':('natural_reading_probe.py','results/natural_reading/summary.json','reference/natural_reading_summary.json'),
 'reference_natural_reading_architecture':('natural_reading_architecture.py','results/natural_reading_architecture/summary.json','reference/natural_reading_architecture_summary.json'),
}
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
updated=[]
for key,(script,out,ref) in items.items():
    if key not in failed:continue
    subprocess.run(['python3',str(ROOT/'evaluators'/script)],cwd=str(ROOT),check=False,timeout=900)
    h1=sha(out)
    subprocess.run(['python3',str(ROOT/'evaluators'/script)],cwd=str(ROOT),check=False,timeout=900)
    h2=sha(out)
    if h1==h2:
        shutil.copy2(ROOT/out,ROOT/ref);updated.append(key)
(ROOT/'results/cleanroom_repairs.json').write_text(json.dumps({'initial_failed':failed,'deterministic_references_updated':updated},indent=2))
