from __future__ import annotations
from pathlib import Path
import hashlib,json,subprocess,sys,shutil,tempfile,os
ROOT=Path(__file__).resolve().parents[1]
EXPECTED_COMPILER='498abcb5ab346f8cb246222a1ca63699d035a4277dedfba4782e1373137e58ef'
checks={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks['compiler_hash']=sha(ROOT/'toolchain/pinned/znc')==EXPECTED_COMPILER
# Source manifest, excluding manifest itself.
manifest=ROOT/'MANIFEST.sha256'
if manifest.exists():
    ok=True
    for line in manifest.read_text().splitlines():
        if not line.strip():continue
        h,rel=line.split('  ',1);p=ROOT/rel
        if not p.exists() or sha(p)!=h:ok=False;break
    checks['manifest']=ok
else:checks['manifest']=False
# Rerun English native and deterministic evaluators.
commands=[
 ['python3',str(ROOT/'evaluators/qualify_english.py')],
 ['python3',str(ROOT/'evaluators/english_battery.py')],
 ['python3',str(ROOT/'evaluators/english_training_variations.py')],
 ['python3',str(ROOT/'evaluators/sensory_compute_evaluator.py')],
 ['python3',str(ROOT/'evaluators/real_senses_evaluator.py')],
 ['python3',str(ROOT/'evaluators/self_architecture_revision.py')],
 ['python3',str(ROOT/'evaluators/teen_readiness_battery.py')],
 ['python3',str(ROOT/'evaluators/natural_reading_probe.py')],
 ['python3',str(ROOT/'evaluators/natural_reading_architecture.py')],
]
for cmd in commands:
    p=subprocess.run(cmd,cwd=str(ROOT),capture_output=True,text=True,timeout=600)
    checks['run_'+Path(cmd[-1]).stem]=p.returncode==0
    (ROOT/'logs'/('verify-'+Path(cmd[-1]).stem+'.log')).write_text((p.stdout or '')+(p.stderr or ''))
# Verify functional statuses and deterministic reference equivalence where appropriate.
def load(p):return json.loads(Path(p).read_text())
eng=load(ROOT/'results/english_qualification.json');checks['english_native_controlled']=bool(eng.get('pass'))
comparisons=[
 ('english_battery',ROOT/'results/english_battery/summary.json',ROOT/'reference/english_battery_summary.json'),
 ('english_training',ROOT/'results/english_training/summary.json',ROOT/'reference/english_training_summary.json'),
 ('sensory_compute',ROOT/'results/sensory_compute_checks.json',ROOT/'reference/sensory_compute_checks.json'),
 ('real_senses',ROOT/'results/real_senses/summary.json',ROOT/'reference/real_senses_summary.json'),
 ('self_revision',ROOT/'results/self_revision/summary.json',ROOT/'reference/self_revision_summary.json'),
 ('teen_readiness',ROOT/'results/teen_readiness/summary.json',ROOT/'reference/teen_readiness_summary.json'),
 ('natural_reading',ROOT/'results/natural_reading/summary.json',ROOT/'reference/natural_reading_summary.json'),
 ('natural_reading_architecture',ROOT/'results/natural_reading_architecture/summary.json',ROOT/'reference/natural_reading_architecture_summary.json'),
]
for name,a,b in comparisons:
    checks['reference_'+name]=a.exists() and b.exists() and sha(a)==sha(b)
# Adaptive Motif native source.
am=ROOT/'canonical/adaptive_motif_native.zag'
if am.exists():
    zn=str(ROOT/'toolchain/pinned/znc');td=Path(tempfile.mkdtemp(prefix='tnn-am-'));(td/'zag.mod').write_text('edition = "2027"\n')
    outs=[]
    for name,extra in [('a',[]),('b',[]),('checked',['--safety=checked'])]:
        o=td/name;p=subprocess.run([zn,str(am),'-o',str(o),'--no-zagd','--no-foreground-cache','--analyze-strict',*extra],cwd=str(ROOT),capture_output=True,text=True)
        checks['am_compile_'+name]=p.returncode==0;outs.append(o)
    if all(o.exists() for o in outs):
        checks['am_binary_determinism']=outs[0].read_bytes()==outs[1].read_bytes()
        ra=subprocess.run([str(outs[0])],capture_output=True,text=True);rc=subprocess.run([str(outs[2])],capture_output=True,text=True)
        checks['am_checked_parity']=ra.stdout==rc.stdout
else:checks['am_source_present']=False
# The complete package is not teen/adult TNN; verify honest claim boundary.
checks['teen_claim_false']=not load(ROOT/'results/english_battery/summary.json').get('teenager_level_qualified',False)
checks['adult_claim_false']=not load(ROOT/'results/english_battery/summary.json').get('adult_level_qualified',False)
result={'checks':checks,'pass':all(checks.values()),'claim':'controlled integrated research package; not TNN v1 Beta'}
(ROOT/'results/cleanroom_result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
sys.exit(0 if result['pass'] else 1)
