#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/results" "$TMP/datasets"
cp "$ROOT/evaluators/run_research.py" "$TMP/run_research.py"
cp "$ROOT/evaluators/run_extended_research.py" "$TMP/run_extended_research.py"
cp "$ROOT/datasets/legacy_real_web_claims.json" "$TMP/datasets/real_web_claims.json"
(cd "$TMP" && python run_extended_research.py > run.log)
cmp "$TMP/results/extended/deterministic_fingerprint.txt" "$ROOT/results/evaluator/deterministic_fingerprint.txt"
echo TNN_STAGE_EVALUATOR_REPLAY_PASS=1
