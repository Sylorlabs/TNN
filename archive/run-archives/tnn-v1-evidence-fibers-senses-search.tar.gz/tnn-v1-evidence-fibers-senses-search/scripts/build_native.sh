#!/usr/bin/env bash
set -euo pipefail
COMMIT=4b19a9c159bed58a45d18c15f36a78dd82870c57
EXPECTED=498abcb5ab346f8cb246222a1ca63699d035a4277dedfba4782e1373137e58ef
ROOT=$(cd "$(dirname "$0")/.." && pwd)
WORK="$ROOT/.native-work"
rm -rf "$WORK" && mkdir -p "$WORK/project"
curl -fsSL "https://codeload.github.com/Sylorlabs/zag/tar.gz/$COMMIT" -o "$WORK/zag.tgz"
tar -xzf "$WORK/zag.tgz" -C "$WORK"
REPO=$(find "$WORK" -maxdepth 1 -type d -name 'zag-*' | head -1)
ZNC="$REPO/zag-poc/znc"
chmod +x "$ZNC"
echo "$EXPECTED  $ZNC" | sha256sum -c -
cp "$ROOT/src/tnn_next_stage.zag" "$WORK/project/tnn_next_stage.zag"
printf 'edition = "2027"
' > "$WORK/project/zag.mod"
"$ZNC" "$WORK/project/tnn_next_stage.zag" -o "$WORK/a" --no-zagd --no-foreground-cache --analyze-strict
"$ZNC" "$WORK/project/tnn_next_stage.zag" -o "$WORK/b" --no-zagd --no-foreground-cache --analyze-strict
cmp "$WORK/a" "$WORK/b"
"$WORK/a" > "$WORK/normal.csv"
"$ZNC" "$WORK/project/tnn_next_stage.zag" -o "$WORK/c" --safety=checked --no-zagd --no-foreground-cache --analyze-strict
"$WORK/c" > "$WORK/checked.csv"
cmp "$WORK/normal.csv" "$WORK/checked.csv"
echo TNN_NEXT_STAGE_NATIVE_REPLAY_PASS=1
