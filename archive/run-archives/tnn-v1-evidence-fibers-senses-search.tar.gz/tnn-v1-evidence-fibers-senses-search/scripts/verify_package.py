from pathlib import Path
import hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parent.parent
expected=(ROOT/'results/evaluator/deterministic_fingerprint.txt').read_text().strip()
subprocess.run([sys.executable, str(ROOT/'evaluators/run_extended_research.py')], cwd=ROOT, check=True)
# Evaluator writes into ROOT/results/extended; use that if present.
actual_path=ROOT/'results/extended/deterministic_fingerprint.txt'
if not actual_path.exists():
    raise SystemExit('evaluator did not emit fingerprint')
actual=actual_path.read_text().strip()
if actual!=expected:
    raise SystemExit(f'fingerprint mismatch: {actual} != {expected}')
manifest=ROOT/'MANIFEST.sha256'
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    digest, rel=line.split('  ',1)
    p=ROOT/rel
    if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
        raise SystemExit(f'manifest mismatch: {rel}')
print('TNN_STAGE_PACKAGE_REPLAY_PASS=1')
