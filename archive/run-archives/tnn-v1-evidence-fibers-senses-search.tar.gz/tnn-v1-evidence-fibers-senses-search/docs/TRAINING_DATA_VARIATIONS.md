# Training Data Variations

The same learning architecture was raised through eight histories. The evaluator preserved source lineage, ordering, contamination, corrections, and minority truths. The source-type names are evaluator labels only; production TNN must infer reliability from consequences.

| Variation | EWBR accuracy | Majority accuracy | Minority-truth recall | Interpretation |
|---|---:|---:|---:|---|
| clean_then_noisy | 1.000 | 0.851 | 0.999 | Earlier calibration protects later learning without freezing beliefs. |
| joke_saturation | 1.000 | 0.566 | 1.000 | Repeated jokes/echoes do not become factual instructions. |
| large_low_quality | 1.000 | 0.763 | 1.000 | Large volume is usable only when repetition and provenance are separated. |
| large_provenance_rich | 1.000 | 0.774 | 1.000 | Adding provenance prevents noisy scale from becoming majority truth. |
| minority_truth | 1.000 | 0.455 | 1.000 | The well-supported minority remains recoverable against repeated falsehoods. |
| noisy_then_clean | 1.000 | 0.851 | 0.999 | Later high-quality evidence can repair earlier bad structure. |
| small_high_quality | 0.968 | 0.784 | 0.913 | Curated data helps, but small samples leave more uncertainty. |
| source_reversal | 0.997 | 0.573 | 0.998 | Source reliability is contextual and can reverse over time. |

## Training procedure

1. Continue from the accepted State-Continuous Development (SCD) state.
2. Fork equal starting states for each data history.
3. Preserve exact source, lineage, ordering, corrections, and test outcomes.
4. Hold compute constant so quality/ordering—not extra compute—drives the comparison.
5. Evaluate current belief, false confidence, minority-truth recall, and later repair.
6. Promote only if old competence survives and the new state improves hidden evidence cases.

A trainer should not label “popular,” “official,” or “joke” inside the production brain. Those labels exist only for evaluation. TNN must learn what different sources actually do over time.
