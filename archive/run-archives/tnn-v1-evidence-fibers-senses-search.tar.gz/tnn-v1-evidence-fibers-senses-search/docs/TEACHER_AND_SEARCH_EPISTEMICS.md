# Teacher Questions and Web-Search Epistemics

## Source-Conditional Verification (SCV)

Source-Conditional Verification (SCV) stores a teacher statement as a source-attributed claim, not as direct truth. In the native suite, blindly accepting the teacher scored 0.593 while consequence testing scored 1.000 across 64 bounded causal tasks.

The current native experiment still scaffolds three discriminating questions. That is not the final architecture. The scaffold remains in the failure ledger until TNN learns when and how to create the questioning trajectory as a Cognitive Operator.

## Query Intent Grounding (QIG)

Query Intent Grounding (QIG) represents what a question/search is supposed to resolve. In the extended evaluator, overall search rate was 0.323, direct-test rate 0.133, teacher rate 0.133, and accuracy 0.976. This is intentionally not an always-search policy.

Examples:

- Arithmetic was solved internally with no search.
- Python `range()` was usually tested directly and sometimes checked against official documentation.
- Repository-local conventions were usually asked of the contextual teacher.
- An underdetermined future event preserved uncertainty instead of searching until a confident guess appeared.

## Search Evidence Adjudication (SEA)

Search Evidence Adjudication (SEA) evaluates search results by independence, provenance, category, tests, and consistency—not raw count.

For the glue/pizza joke, twenty-four repeated pages form one echo lineage. FDA material explains that adhesives can be authorized for specific indirect food-contact uses; that does not make household glue a food ingredient. Poison Control treats glue as an art/adhesive product and says not to use art products for food decoration unless labeled safe. USDA recipe material uses mozzarella as cheese. The promoted conclusion is therefore “glue is not a suitable cheese substitute,” without relying on the unsupported horse-hoof folklore claim.

## Boundary

This is bounded structured epistemics. Adult-English autonomous web research remains explicitly unpassed in the native metrics.
