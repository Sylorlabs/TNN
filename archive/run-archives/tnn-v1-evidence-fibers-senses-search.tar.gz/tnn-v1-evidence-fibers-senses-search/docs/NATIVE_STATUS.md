# Native Zag v2 Status

- Deployment: `dpl_2HgRV6kknz7yjRvCDjPTFbBu9CBf`
- Source: `src/tnn_next_stage.zag`
- Source SHA-256: `addd6e95445dfc502cef679b1c0bcc385897b7ce8c0776409af3541d7fe32dba`
- Compiler SHA-256: `498abcb5ab346f8cb246222a1ca63699d035a4277dedfba4782e1373137e58ef`
- Zag commit: `4b19a9c159bed58a45d18c15f36a78dd82870c57`
- Edition: 2027
- Strict analyzer: PASS
- Normal double compilation: byte-identical, 27,971 bytes
- Checked-mode execution: PASS
- Normal/checked output: identical
- Native marker: `TNN_NEXT_STAGE_NATIVE_STRICT_PASS=1`
