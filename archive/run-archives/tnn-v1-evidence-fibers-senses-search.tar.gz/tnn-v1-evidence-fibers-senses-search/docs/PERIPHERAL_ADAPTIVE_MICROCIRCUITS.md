# Peripheral Adaptive Microcircuits (PAMs)

Peripheral Adaptive Microcircuits (PAMs) are local sensory neural fields—loosely analogous to neural processing outside the cerebral cortex—that adapt and compress receptor signals before those signals enter wider cognition.

They are **not** separate minds. They have no private identity, goals, autobiography, or world model. They share entity handles and long-term memory with the whole TNN.

## Tournament

1. **Central raw:** all sensor values are sent centrally with little local adaptation.
2. **Separate mini-brains:** each modality learns locally with private codes, producing strong local classification but fragmented identity.
3. **PAMs:** local adaptation uses shared entity codes and one autobiographical brain.

At 30% corruption:

| Architecture | Identity | Cross-modal | Fragmentation |
|---|---:|---:|---:|
| Central raw | 0.598 | 0.330 | 0.000 |
| Separate mini-brains | 0.734 | 0.508 | 0.926 |
| PAMs | 0.799 | 0.527 | 0.000 |

PAMs produced the strongest identity with no measured fragmentation at moderate corruption. Separate mini-brains fragmented into modality-private identities.

## Failure boundary

At 45% corruption, all three approaches collapsed: PAM identity was only 0.133. This means the senses are **not ready**. The next variants must add temporal recurrence, cross-modal repair, active resampling, adaptive gain, and lesion-driven reorganization before natural sensory gates can close.
