# Fiber Resources and Long-Term Memory

## Resource-Elastic Fiber Scheduling (REFS)

Resource-Elastic Fiber Scheduling (REFS) means the owner sets a total resource envelope while TNN decides how many fibers exist and how much each one receives. Fibers are not equal-cost workers. A visual monitoring fiber may need little compute; a theorem or compiler-debugging fiber may need much more.

The bounded evaluator used envelopes 16, 32, 64, 128, and 256. All completed the 90 unresolved tasks, but mean update steps fell from 135.65 at envelope 16 to 19.66 at envelope 256. Allocation variance was 7.48, demonstrating unequal resource use rather than fixed equal shares.

The task count is an environmental workload, not a hardcoded production fiber count. Production TNN must grow and retire fibers from unresolved work inside the owner envelope.

## Fiber-to-Memory Consolidation (FMC)

Fiber-to-Memory Consolidation (FMC) preserves useful discoveries before a fiber is suspended or terminated. The evaluator averaged 42.1 shared long-term records at envelope 64 and reused shared work while avoiding 65.7 duplicate operations.

A fiber ending must not mean its useful result disappears. TNN may preserve:

- a discovered premise or counterexample;
- an exact tool result keyed by source/version/flags;
- a reusable procedure;
- a failed approach and why it failed;
- an unresolved dependency;
- an exact suspended state when resumption is justified.

The human can ask why resources were allocated. REFS records allocation events and their triggering state; it does not expose fictional sub-agent conversations.

## Shared Tool State (STS)

Shared Tool State (STS) makes a compiler invocation common brain state. In the evaluator, version-aware sharing used about 0.137 executions per request and produced zero stale results. A deliberately unsafe project-only cache reused 1249.0 stale results on average.
