# State-Continuous Development (SCD)

State-Continuous Development (SCD) means training resumes from the accepted brain state instead of restarting from birth or replaying the complete lifetime.

Across 100 lineages:

- old competence before continuation: 1.000
- old competence after continuation: 1.000
- new competence after continuation: 1.000
- fresh learning examples: 15.57
- targeted replay examples: 0.69
- hash-validated unchanged replay: 0.00
- unique snapshot hashes: 100

The first replay criterion failed because selective replay was not sufficiently cheaper than fresh learning. Rather than lowering the criterion, the replay architecture was split into full, fixed, dependency-targeted, and hash-validated variants. Dependency-targeted replay and zero-replay unchanged continuation then passed while old and new knowledge remained exact.
