# Research Report

## Execution scope

- 1 native Zag v2 integrated suite, strict-analyzer and checked-mode verified.
- 4,370 deterministic evaluator rows across eight campaign groups.
- 23/23 promotion checks passed for this bounded stage.
- Repeated evaluator fingerprint: `172866ec1ed95b1c207d6aaad4ea3ce01e5b469a233f7d7b274c0a679cd7cf8c`.

## Key findings

1. Evidence-Weighted Belief Revision (EWBR) and Provenance-Aware Curriculum (PAC) resisted repeated falsehoods substantially better than majority voting.
2. Minority-Evidence Preservation (MEP) kept well-supported minority truth available instead of treating low frequency as falsity.
3. Resource-Elastic Fiber Scheduling (REFS) allowed unequal fiber resource consumption inside owner envelopes; more resources reduced time without changing the cognitive architecture.
4. Fiber-to-Memory Consolidation (FMC) retained useful discoveries after fiber termination rather than simply degrading them.
5. Shared Tool State (STS) prevented duplicate compiler work and, when keyed by source/version/flags, avoided stale outputs.
6. Peripheral Adaptive Microcircuits (PAMs) outperformed isolated sensory mini-brains at moderate noise while preserving one identity; all variants failed at extreme noise.
7. Query Intent Grounding (QIG) and Search Evidence Adjudication (SEA) made search selective rather than reflexive, but adult-English autonomous search is still open.
8. State-Continuous Development (SCD) retained old skills, learned new ones, and used dependency-targeted or zero replay instead of full-lifetime retraining.

## AHI/AGI claim boundary

These results support TNN as a serious research direction toward artificial human intelligence, but they do not confirm AHI/AGI. The adult language, natural senses, open-world learning, and integrated beta gates remain open.
