# Technique Glossary

- **EWBR — Evidence-Weighted Belief Revision:** Revises beliefs using evidence quality, independence, provenance, and outcomes rather than raw repetition.
- **MEP — Minority-Evidence Preservation:** Keeps a low-frequency claim available when its evidence is strong or unresolved.
- **PAC — Provenance-Aware Curriculum:** Trains with source lineage and correction history preserved across data-quality variations.
- **NSC — Noise-Selective Consolidation:** Consolidates reusable structure without treating repetition or novelty alone as truth.
- **SCV — Source-Conditional Verification:** Keeps teacher/source claims provisional and tests them when justified.
- **REFS — Resource-Elastic Fiber Scheduling:** Lets TNN distribute owner-provided compute unevenly across fibers according to current work.
- **FMC — Fiber-to-Memory Consolidation:** Moves useful fiber discoveries into shared long-term memory before a fiber ends.
- **STS — Shared Tool State:** Makes exact tool invocations and outputs common brain state, preventing redundant or stale work.
- **PAMs — Peripheral Adaptive Microcircuits:** Local sensory neural fields that adapt/compress signals while sharing one identity, memory, and goals.
- **QIG — Query Intent Grounding:** Represents what uncertainty a question or search is intended to resolve.
- **SEA — Search Evidence Adjudication:** Evaluates search results by evidence, independence, provenance, and tests rather than result count.
- **SCD — State-Continuous Development:** Continues training from the accepted brain state with selective replay and exact state lineage.
