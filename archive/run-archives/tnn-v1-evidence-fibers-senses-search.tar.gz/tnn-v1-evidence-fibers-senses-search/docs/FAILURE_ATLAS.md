# Failure Atlas

## SCD replay efficiency failure

Initial selective replay did not beat the locked fresh-learning fraction by enough. The criterion was not weakened. Full replay, fixed replay, dependency-targeted replay, and hash-validated no-replay variants were compared. Targeted and unchanged-state variants closed the bounded gate.

## Extreme sensory corruption

At 45% corruption, central raw, separate mini-brains, and Peripheral Adaptive Microcircuits (PAMs) all collapsed. This remains an active sensory research failure.

## Separate sensory mini-brain fragmentation

Private modality codes produced severe fragmentation at moderate noise. The promoted direction keeps peripheral local adaptation but shares identity, memory, and goals.

## Unsafe shared tool cache

Caching only by project identity produced many stale results after source/version changes. Shared Tool State (STS) must include source state, tool version, and flags.

## Always-search first version

The first web/teacher policy searched authoritative sources for every case. Query Intent Grounding (QIG) was added so internal derivation, direct tests, teacher questions, search, and uncertainty can be selected contextually.

## Adult web-search gap

The suite can adjudicate structured search evidence but cannot yet understand arbitrary natural-language research requests. This is not relabeled as adult search.
