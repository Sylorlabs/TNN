# Wave 5 evidence snapshot, October 8, 2026

L3 = 0. No integrated general-intelligence result is claimed. This collection preserves narrow positives, negatives, defects and evidence gaps. Publication is not a new experiment or an independent scientific certification.

## Evidence states

- Stage A: NOT_RUN / ENVIRONMENT_UNSUPPORTED. The ledger reports an accepted design, but the design file is not held here. No host-level assurance is inferred.
- Learned evaluator: descriptive L1 prior counting, not learned cognitive-method construction. The final package reports both primary BF cells failed both preregistered gates. BF h4 cannot distinguish by margin, which is not equivalence. Earlier rev5-rev7 claims in the historical ledger retain their NOT-locally-received/replayed and reported-only qualifiers. Later package receipts/results are separately included; no global inherited certification.
- Birth v2: execution of 2,880 cells was reported complete at 17:16 PDT. The original raw is unavailable in this collection. The preserved chain starts at count 143 and ends at 2880, with the initial rows 0-142 outside its custody coverage. Recovery remains pending. See assay/STATUS.md. Not independently scored, not hostile-replicated, not promoted.
- Independent replay: 2,880 digest records are received. This is separate re-execution from frozen source, supporting determinism and honest reporting, not an original-versus-replay comparison or independent validation of the design. The reported assay has ten worlds and n<16, so it stays descriptive.

## Collection

- Historical pre-Wave-5 tree: docs/lab/hypothesis_tests/2026-10-07/, with original qualification limits. Its unchanged compressed archive is also retained in history/.
- result-ledger-v65-public-excerpt.csv: 72-entry historical index. Private coordination references and local working paths are trimmed. Qualifiers, negatives and pending states remain. See PUBLICATION_NOTES.md.
- evaluator/: exact frozen package, coverage errata, and an outer inventory of all archive members. Same-process guards are not isolation.
- integrity/: preserved chain/window records, complete replay digests and supplied replay tooling. Scripts need missing source/raw/manifest inputs and are not a standalone runnable assay. The included integrity summary is ledger-derived, not a primary RT record.
- history/: earlier qualification/inventory, exact insurance archives, partial replay and E identity-reconciliation report. Received identities do not imply the corresponding underlying files are included.
- protocol/: selected scientific excerpts and a verdict template. These are research material, not instructions or authorization records. The successor proposal is a proposal, not an executed result.

No compiled primary red-team report file is held. Red-team attributions in the historical ledger are secondhand coordination reports and are unverified there unless separately supported by bundled primary evidence. No original assay raw, recovered reproduction raw, complete custody chain from zero, or raw-versus-replay comparison result is yet included. Recovery additions must append with explicit evidence states.
