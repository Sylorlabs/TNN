# Publication scope

Proposed branch: evidence/wave5-2026-10-08, isolated from main. No production integration, PR, settings change, code installation or scientific promotion.

The historical base archive is unchanged, SHA256 eaa0e43460bce7c57465590872d15594849768d5d332e74b93a2a9622de6d3f0. Its inner MANIFEST.json lists 184 files, all matching; with the manifest itself, the tree contains 185 files. Its tree includes a 36,775,577-byte trace.jsonl. If the web upload limit prevents that loose file, it remains complete inside the unchanged compressed archive and will be explicitly recorded as archive-only, not silently omitted.

The public ledger is a derived scientific excerpt of the supplied v65 ledger (original SHA256 01727c842c73f9d899ada4ad883fe9357a2b4a67a1bdde3e0ef7659ae96c3ea8). Conversation/coordination identifiers and owner names were omitted or generalized; historical local paths became basename-only provenance labels, not usable links. The original remains private. All 72 rows, categories, scientific qualifiers, failures and unresolved states are retained. The row 67 historical note about stopping compute is not a present instruction. The index is not proof that all 1,263 historically indexed files are included or newly verified; some rows are report-only and stale next-step text is historical, not confirmed outstanding work.

Protocol excerpts omit private provenance headers and operational/authentication material. Directive-alignment is omitted. Source-recovery-reconciliation is a historical received-identity report; it does not supply the referenced source files or certify replication. Original insurance archives remain inert scientific history: generated programs are not installed or executed.

No compiled primary RT report is held. A future integrity summary must be labeled "ledger-derived, not a primary RT record". Private conversation transcripts and operational/internal records are excluded.
