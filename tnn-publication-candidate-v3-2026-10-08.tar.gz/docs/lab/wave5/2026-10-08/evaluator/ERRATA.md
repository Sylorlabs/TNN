# Evaluator package coverage and result limits

Exact E-rev7-lane-final.tgz SHA256:
f78d8c7db655809f1b77eb8ed070a786ab8aaf3a4ace71132fc1a17d356aea54

PACK_SHA256.txt inside the archive is a historical onboarding list, not package verification. MANIFEST.sha256 is the authoritative inner source manifest. All 30 listed entries were checked against the archive contents and match. The inner manifest does not list every final/pilot output or receipt. ARCHIVE_MEMBERS.json hashes every regular archive member, and the outer bundle manifest hashes the exact complete archive. Those byte checks do not certify scientific results or prospective freezing.

The supplied receipts/results report descriptive L1 prior counting, L3=0; both primary BF cells fail both preregistered gates. BF h4 cannot distinguish by margin, not equivalence. Round-two drops and false flags remain in the original summary. Same-process scan/audit guards are regression smoke checks, not leak-proof isolation; M13 is a disclosed limit. Pilot/final exact replay was reported by reviewers, not newly executed in this publication task. No stronger claim is inherited from earlier version signoffs.
