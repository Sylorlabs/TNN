# Birth v2 status: recovery pending

The original 2,880-cell execution was reported complete October 8, 2026, 17:16 PDT. Its final raw SHA256 is preserved:

dca5a2377ce74fd1a531f48eb1860f250901aba6980869a96dc1bac80e8580f4

Incident: the original execution workspace became unavailable before raw delivery and full closeout. The raw is not in this bundle. Preserved batch records span count 143 to 2880; their adjacent counts/hashes link and the last hash equals the recorded final raw hash. This does not recover or audit the missing initial chain-of-custody coverage for rows 0-142. Window logs survive but do not fill that gap. Full validation completion is not inferred from execution completion.

Two separate checks are pending:

1. F-2 reproduction: compare its final raw SHA256 with the preserved original SHA256. Only an exact match permits "recovered-by-reproduction" for raw byte identity. It does not independently score the science or establish acquired cognitive control.
2. RT3 digest comparison: compare recovered non-timing outputs against the received 2,880-row independent replay digest file. The replay was re-executed from frozen code and merged with no conflicting overlaps as reported; it was not compared with the unavailable original raw. Its scope is determinism and honest reporting, not independence of the design.

Status: not independently scored, not hostile-replicated, not promoted. Descriptive only: ten worlds, n<16. L3=0. No completed verified assay verdict is asserted.

Pending additions: reproduction raw identity, complete custody chain from zero, frozen source and delivery manifest, raw-derived scoring/accounting, explicit digest comparison and provenance verdict. The partial 2,659-row replay is kept only as incident history and is superseded by the complete digest file.
