# Read-only raw extraction, one reviewed manifest range at a time. No delete.
import sys,json,pathlib,gzip,hashlib,shutil,os,datetime,zlib
root=pathlib.Path('.')
if len(sys.argv)!=2:raise RuntimeError('ONE_SHARD_INDEX_REQUIRED')
if (root/'window-lock.json').exists() or (root/'validation-lock.json').exists() or (root/'packaging-lock.json').exists():raise RuntimeError('OTHER_PROCESS_LOCK')
if (root/'scientific-processfail.jsonl').exists():raise RuntimeError('PROCESSFAIL_VOID')
if shutil.disk_usage('.').free<=2_000_000_000+20_000_000:raise RuntimeError('DISK_FLOOR')
m=json.load(open('delivery/manifest.json'));s=m['shards'][int(sys.argv[1])]
if m['python_version']!=sys.version or m['zlib_runtime_version']!=zlib.ZLIB_RUNTIME_VERSION:raise RuntimeError('COMPRESSION_RUNTIME_CHANGED')
p=pathlib.Path(s['file'])
if p.exists():raise RuntimeError('SAMPLE_EXISTS_NO_OVERWRITE')
lock=pathlib.Path('sample-lock.json')
fd=os.open(str(lock),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump({'pid':os.getpid(),'index':int(sys.argv[1])},f)
h=hashlib.sha256();count=0;remaining=s['byte_end_exclusive']-s['byte_start']
with open('scientific-raw.jsonl','rb') as r,open(p,'xb') as fo:
 r.seek(s['byte_start'])
 with gzip.GzipFile(filename='',mode='wb',compresslevel=6,mtime=0,fileobj=fo) as g:
  while remaining:
   b=r.readline()
   if not b or not b.endswith(b'\n') or len(b)>remaining:raise RuntimeError('SHARD_LINE_BOUNDARY')
   x=json.loads(b);key=[x[k] for k in ['world','rep','cap','arm']]
   if not count:first=key
   last=key;h.update(b);g.write(b);g.flush();remaining-=len(b);count+=1
ch=hashlib.sha256()
with open(p,'rb') as f:
 for b in iter(lambda:f.read(1048576),b''):ch.update(b)
record={'timestamp':datetime.datetime.now().astimezone().isoformat(),'index':int(sys.argv[1]),'bytes':p.stat().st_size,'compressed_sha256':ch.hexdigest(),'uncompressed_sha256':h.hexdigest(),'rows':count,'first_key':first,'last_key':last,'free_bytes':shutil.disk_usage('.').free}
ok=record['bytes']==s['bytes'] and record['compressed_sha256']==s['sha256'] and record['uncompressed_sha256']==s['uncompressed_sha256'] and count==s['rows'] and record['free_bytes']>2_000_000_000
record['status']='READY_FOR_TRANSFER' if ok else 'MISMATCH_STOP_REVIEW'
with open('sample-regeneration-log.jsonl','a') as f:f.write(json.dumps(record)+'\n')
if not ok:raise RuntimeError('SAMPLE_MISMATCH_PRESERVED_STOP_REVIEW')
lock.unlink();print(json.dumps(record))
