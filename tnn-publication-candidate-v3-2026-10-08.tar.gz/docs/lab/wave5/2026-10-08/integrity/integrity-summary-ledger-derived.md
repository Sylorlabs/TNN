# Integrity summary

ledger-derived, not a primary RT record

Source: result-ledger.csv v65 (sha256 01727c842c73f9d899ada4ad883fe9357a2b4a67a1bdde3e0ef7659ae96c3ea8), 72 index entries. Primary red-team verdict records (RT1-RT90) are not bundled. This summary only repeats what the ledger records. No row is scientifically promoted. L3 = 0. Evidence-ladder fields not shown for a row are unknown, not passed.

## Category counts (a row can carry several)

- surviving narrowly: 60
- exploratory local evidence: 44
- reproducible source-backed result: 23
- killed: 22
- unverified claim: 10
- process failure: 9
- requiring independent replication: 8

## Per-row index (id, result, categories)

- 00 | Remote ownership/fast frontier audit | reproducible source-backed result; surviving narrowly; unverified claim
- 01 | Typed array allocation localization | reproducible source-backed result; surviving narrowly
- 02 | R2R mutation-sensitive ownership instrument | exploratory local evidence; surviving narrowly
- 03 | A active identifying world | reproducible source-backed result; surviving narrowly
- 04 | B first parity versions | reproducible source-backed result; killed; process failure
- 05 | B final acquired parity mask | reproducible source-backed result; surviving narrowly
- 06 | D passive/active procedure successor | exploratory local evidence; surviving narrowly
- 07 | H recursive induction | reproducible source-backed result; surviving narrowly; requiring independent replication
- 08 | H4 grammar ambiguity/abstention | reproducible source-backed result; surviving narrowly
- 09 | Final executable transplant | reproducible source-backed result; surviving narrowly; killed
- 10 | Transplant uniqueness diagnostic | reproducible source-backed result; surviving narrowly
- 11 | C semantic dedup rival to97 vs155 | reproducible source-backed result; surviving narrowly; killed
- 12 | C native procedure/policy/lazy rivals | reproducible source-backed result; surviving narrowly
- 13 | G causal intervention policy | exploratory local evidence; surviving narrowly; killed
- 14 | F initial quality policy | exploratory local evidence; surviving narrowly
- 15 | F GC2 original snapshots | exploratory local evidence; killed; process failure
- 16 | F GC2 corrected snapshots | exploratory local evidence; surviving narrowly
- 17 | D compound edit-object transplant | reproducible source-backed result; surviving narrowly
- 18 | D edit-order reward policy | reproducible source-backed result; surviving narrowly; killed
- 19 | A3 seven-query goal certificate | reproducible source-backed result; surviving narrowly
- 20 | recruit3 | reproducible source-backed result; surviving narrowly; killed
- 21 | E selective repair rev2 | exploratory local evidence; surviving narrowly; killed
- 22 | E selective repair rev3 | exploratory local evidence; surviving narrowly; requiring independent replication
- 23 | Shared-world v1 | reproducible source-backed result; surviving narrowly; killed
- 24 | Shared-world v2 | reproducible source-backed result; surviving narrowly
- 25 | Marginal inquiry reward diagnostic | exploratory local evidence; surviving narrowly; killed
- 26 | Prior continuity falsifier | reproducible source-backed result; exploratory local evidence; surviving narrowly
- 27 | All behavior-mask fixed certificate bounds | exploratory local evidence; surviving narrowly
- 28 | Later Wave4 learned next-action control | unverified claim; requiring independent replication
- 29 | Selective repair rev4 and full rev3 raw | unverified claim; requiring independent replication
- 30 | 240 formal near-miss invalid cases | unverified claim; requiring independent replication
- 31 | Adaptive Web lifetime/interference experiments | unverified claim; requiring independent replication
- 32 | Team B initial Adaptive Web vs flat | exploratory local evidence; surviving narrowly; killed; process failure
- 33 | Team B B3 adaptive split organization | exploratory local evidence; surviving narrowly; killed
- 34 | Team B B4v2 full-artifact fixed rival | exploratory local evidence; surviving narrowly
- 35 | Team F Wave4 flat primitive control | exploratory local evidence; surviving narrowly; killed
- 36 | Team F Wave4b blind prior relevance | exploratory local evidence; surviving narrowly; killed
- 37 | Team C macro reuse executable round | reproducible source-backed result; surviving narrowly; killed
- 38 | Team C shared-v2 rank-aware rival | reproducible source-backed result; surviving narrowly
- 39 | Team H formal induction 240 near-miss | reproducible source-backed result; surviving narrowly
- 40 | revise-real rev2/rev3/rev4 complete | exploratory local evidence; surviving narrowly; killed; unverified claim
- 41 | RT7 Phase1 memory+arm integrity | reproducible source-backed result; surviving narrowly; killed
- 42 | Team D Phase2 diagnosis (final) | exploratory local evidence; surviving narrowly
- 43 | Team D original next-action structural failure | exploratory local evidence; surviving narrowly
- 44 | Team H THEORY T1-T5 + C1-C3 | exploratory local evidence; surviving narrowly
- 45 | Team C transition-resumable rival | reproducible source-backed result; surviving narrowly; killed
- 46 | Team B B5 final VOID + successor design | exploratory local evidence; killed; process failure
- 47 | Team F Phase3A freeze + first result | exploratory local evidence; surviving narrowly; killed; process failure
- 48 | Phase6/9 ablation contract + validator | exploratory local evidence; surviving narrowly
- 49 | Team H T6 + PRESCREEN checklist | exploratory local evidence; surviving narrowly
- 50 | Method-invention outside-span probe | exploratory local evidence; surviving narrowly
- 51 | Transplantation prep contract v2 (supersedes v1) | exploratory local evidence; surviving narrowly
- 52 | RT2 REPORT6 routed replication/cap additions | unverified claim; requiring independent replication
- 53 | Team H amended THEORY + PRESCREEN W5-1 A1-A8 | exploratory local evidence; surviving narrowly
- 54 | Final THEORY A5a + constructor consumer contract | exploratory local evidence; surviving narrowly
- 55 | Method-invention corrected separate-process integrity/content | exploratory local evidence; surviving narrowly; process failure
- 56 | Team F Birth prereg and premature alias-contaminated run | exploratory local evidence; process failure; unverified claim
- 57 | Phase6/9 prep CONTRACT v3 supersedes v2 | exploratory local evidence; surviving narrowly
- 58 | CONTRACT v3a theory alignment + RT3 RT9 Birth bars | exploratory local evidence; surviving narrowly
- 59 | W5-2 theory/checklist and CONTRACT v3b | exploratory local evidence; surviving narrowly
- 60 | Team C W5-2 exact subset certificates (reported) | exploratory local evidence; surviving narrowly
- 61 | Phase6/9 CONTRACT v4 statistical/receipt closure | exploratory local evidence; surviving narrowly
- 62 | W5-2 cleanup+A15 and local supplied-oracle execution | exploratory local evidence; surviving narrowly
- 63 | Prep statistical structural holes + scoped G certification (reported) | unverified claim; requiring independent replication
- 64 | RT2 scratch replication scripts received + local tf/credit replay | exploratory local evidence; surviving narrowly
- 65 | CONTRACT v4c cluster-statistics replacement | exploratory local evidence; surviving narrowly
- 66 | Prep v4d/v4e and D CLEAN rev4a closure | exploratory local evidence; surviving narrowly
- 67 | Team E rev5 exploratory evaluator and self-ablation | exploratory local evidence; killed; process failure
- 68 | G generic harness self-caught fixture-path failure | exploratory local evidence; process failure; killed
- 69 | Prep v4f and E S4 prescreen claim | exploratory local evidence; surviving narrowly; unverified claim
- 70 | Prep CONTRACT v4g coherence amendment | exploratory local evidence; surviving narrowly
- 71 | Prep v4h minor contrast/stratum/cap refinement | exploratory local evidence; surviving narrowly