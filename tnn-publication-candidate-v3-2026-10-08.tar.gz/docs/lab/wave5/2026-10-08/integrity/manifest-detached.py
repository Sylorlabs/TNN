# Detached packaging lock; reviewed scientific manifest script unchanged.
import pathlib,os,json,subprocess,datetime,shutil
p=pathlib.Path('.')
for name in ['window-lock.json','validation-lock.json','sample-lock.json']:
 if (p/name).exists():raise RuntimeError('OTHER_LOCK_PRESENT')
if (p/'scientific-processfail.jsonl').exists():raise RuntimeError('PROCESSFAIL_VOID')
if shutil.disk_usage('.').free<=2_000_000_000:raise RuntimeError('DISK_FLOOR')
fd=os.open('packaging-lock.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump({'pid':os.getpid(),'started':datetime.datetime.now().astimezone().isoformat()},f)
subprocess.run(['sha256sum','-c','DELIVERY-SAMPLED-REVIEW.sha256'],check=True)
subprocess.run(['python3','delivery-manifest-sampled.py'],check=True)
if shutil.disk_usage('.').free<=2_000_000_000:raise RuntimeError('END_DISK_FLOOR')
pathlib.Path('packaging-lock.json').unlink();print('MANIFEST_COMPLETE',flush=True)
