# Scientific excerpt

This is a selected research document, not a verbatim conversation or an authorization record. Conversation identifiers, private operational provenance, and publishing/authentication instructions were omitted. Scientific text is historical; this publication does not retroactively freeze experiments.

Fixed goal-ID addresses and researcher-assigned cognitive slots are not the intended TNN architecture. Their generalization failures are useful negative controls, not the central architectural problem.

TNN should acquire and reorganize its own semantic structure through experience. The generic substrate may handle physical allocation and addressing, but the learner should determine relationships, organization, recruitment, and reuse.

Do not simply substitute a researcher-written semantic router, similarity metric, or fixed organization algorithm. Test whether useful organization and its modification can themselves be acquired.

Most importantly, do not interrupt or restart the 2,880-row assay. Finish it, complete hostile replication, and identify exactly which consequential decisions are learned versus source-authored.

Then prioritize experiments where learned organization changes how TNN constructs, investigates, and repairs future methods - not merely where it stores answers.

Preserve the evaluator's completed negative result. L3 remains zero until source-subtracted, learner-owned cognitive-method construction survives adversarial testing.
