# Assay compact verdict template
1. Survived, by exact scope and source identity.
2. Failed, including lost previously-correct cases and controls.
3. Actually learned, supported by experience/object/decision provenance.
4. Researcher-owned, including generative/search/recruitment/repair rules.
5. Ablations, actual interventions and limits.
6. Source subtraction: authored cognitive rules removed versus generic substrate preserved; strong source-only/facts rivals; acquired-control erase/transplant/permutation evidence. Unknowns explicit.
7. Architectural cause: representation/reachability/exploration/credit/interference/missing information/source ownership. Fixed goal-ID and assigned-slot failures are negative controls, not general architectural impossibility.
8. Immediate successor and hostile reviewer routing through parent; no constant sweep.
Scientific status and evidence ladder explicit. Margin indistinction is not equivalence. L3 zero until earned.
