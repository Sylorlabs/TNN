# Scientific excerpt

This is a selected research document, not a verbatim conversation or an authorization record. Conversation identifiers, private operational provenance, and publishing/authentication instructions were omitted. Scientific text is historical; this publication does not retroactively freeze experiments.

# Successor proposal v2
## Highest-information next outcome
A persistent acquired executable object must causally change future method construction, not merely execute a cached task program. Use one frozen low-level interface and at least two substantively different identifiable families. No source modifications between hidden objectives. Every consequential decision records source machinery versus acquired object reads/writes and action consequences.

## Proposed work packets when lanes close
1. Shared experiment/preregistration designer plus hostile identifiability reviewer: define common public observations/actions, budgets, scoring, hidden split and A-F evaluator-outcome sequence. Candidate families for review, not settled: interactive graph/environment rule discovery with delayed consequences; executable structured-data transformations under changed encodings and affordances. Prove useful information is reachable, include ambiguity requiring abstention. No complete cognitive instruction sequence is exposed to learner.
2. Three independent mechanism builders: 3A consequence-selected structural edits, 3B acquired executable transformations of programs, 3C acquired workspace organization. Generic local primitives only; their substrate must not contain the hidden method menu. Record exact source-owned search/credit/selection machinery. Choose strongest feasible versions, not knowingly weak demonstrations.
3. Independent hostile baseline builder: strong flat executable store and facts-only reconstruction with comparable information and full cost. Nested Web need not win. Oracle knowing complete theory is an upper-bound reference, not a required victory condition.
4. Integration engineer: smallest persistent executable learner, frozen goal/action/feedback interface, provenance and verified outcome or complete failure trace. Experimental Zag prototype is not automatically canonical TNN. Interface instrumentation may precede learner promotion, but integration claims require execution evidence.
5. Causal ablation reviewer on first plausible acquired-control carrier: Full; Fresh; facts/task objects retained with control erased; control retained with facts erased; control transplanted into fresh frozen executor; relevant/irrelevant/misleading history; facts-only reconstruction; control permutation; unfamiliar-family transfer. Confirm actual intervention effects through carrier identity, trajectory and read/write provenance. Facts/control nonseparability is an explicit design blocker, not a convenient relabeling.

## Held-out axes and architectural discrimination
Goal combinations, encodings, construction procedures, affordances, invalid prior procedures, misleading histories and changed rules. At least two genuinely different families, not many arithmetic/affine/parity variants. A-F are evaluator outcomes: acquire procedure, acquire another, construct unfamiliar composition, fail changed conditions, acquire useful transformation, transfer transformation to new family. Learner chooses intermediate activity.
For any negative, independently test representability, experience reachability and retention. Credit and interference work targets generic attribution across substructures, applicability, preservation and transfer beyond exact IDs. No human-named cognitive module grafts.

## Launch gate and handoff
Before costly acquisition: exact sources, source-ownedness card, observable-world identifiability, hidden splits, strong rivals, intervention feasibility, budgets and justified independent-unit analysis reviewed. Preserve all results including losses. No fixed universal confidence threshold.
F causal verdict chooses the mechanism emphasis, not a constant sweep. E counting-only verdict closes that lane. Parent assigns available strongest workers immediately after assay close; this proposal can be refined without interrupting execution.

## Architectural ownership amendment (original received-user evidence inspected)
Fixed goal-ID addresses and researcher-assigned cognitive slots are negative controls, not the intended architecture. Their failure cannot establish that learner-owned semantic organization is impossible. Generic substrate allocation/addressing is permitted; semantic relationships, organization, recruitment, reuse and their modification must be acquired.

No candidate may substitute a source-authored semantic router, similarity metric or fixed organization algorithm for that acquisition. A learned task selector over a researcher-complete method menu also fails this bar. Builders disclose and subtract each such source rule; if removing it makes the task unidentifiable or removes necessary generic operations, distinguish that from inability to learn an achievable behavior. The flat rival remains strong and fairly budgeted, not a forced loser.

All 3A/3B/3C candidates must show how experienced organization affects construction, investigation and repair of future methods, rather than answer storage alone. The A-F sequence is evaluator outcomes, not a source-level workflow. Structural changes without acquired semantic use are insufficient; executable transformations must include acquired applicability/recruitment rather than hidden authored routing; workspace layout must causally improve future methods and be learner-modifiable.

## Explicit hostile source-subtraction brief
Audit every consequential choice from goal receipt through observation selection, object recruitment, composition, action, revision and stopping. Record decision/event ID, source/binary identity, source rule, acquired object identity, experience producing it, observed permitted information, read/write trace, effect and intervention evidence. Mixed/unknown provenance is labeled, not rounded up to learned.
Attack semantic routers, authored similarity/ranking, fixed organization schedules, complete method menus, exact-ID dispatch, evaluator targets/labels and source-authored repair logic. Construct the strongest fair source-only and facts/cached-program rival. Erase or permute acquired control while retaining facts; subtract authored cognitive rules while preserving generic execution; transplant learned control to a fresh frozen executor. Neither state dependence nor failure after breaking an executor establishes acquired cognition.
Promotion requires source-subtracted learner-owned method construction surviving independent attacks. L3 remains zero. Source subtraction is not an instruction to silently rewrite the frozen current assay.

## F closeout accounting, without rerun or protocol change
Required analysis is an exact learned/source-authored consequential-decision accounting with artifact/trace support. Existing traces may establish it; if they do not, mark those decisions UNRESOLVED. RT3 replication should verify decision provenance as well as non-timing outputs. Current 2,880-cell execution and E negative remain unchanged.
