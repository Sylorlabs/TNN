# Scientific excerpt

This is a selected research document, not a verbatim conversation or an authorization record. Conversation identifiers, private operational provenance, and publishing/authentication instructions were omitted. Scientific text is historical; this publication does not retroactively freeze experiments.

Continue the existing Wave 5 research program. Do not restart the 50-family evidence inventory, redo completed experiments without a scientific reason, or interrupt the current 2,880-row learner assay.

The central goal remains unchanged:

The researcher specifies an outcome. TNN discovers what needs to happen between receiving that request and delivering a verified result.

TNN must eventually acquire the ability to construct, organize, select, execute, and repair useful cognitive procedures through experience.

No hardcoded cognitive-mode system, complete researcher-authored method menu, or disguised source-level workflow should be mistaken for this achievement.

L3 remains zero.

1. FINISH THE CURRENT LEARNER ASSAY

Team F's 2,880-row experiment is the immediate execution priority.

Finish all rows under the reviewed frozen protocol.
Preserve the original capacity-crash evidence and corrected implementation separately.
Have RT3 independently reproduce the complete result, not only sampled rows.
Compare source, binary, state, trajectory, and output hashes.
Confirm all arms use their intended state and receive identical permitted information.
Independently score results from raw actions and consequences.
Include total training, acquisition, verification, memory, and execution costs.
Report previously correct cases lost, not only improvements.
Check for hidden evaluator information or verification labels influencing candidate decisions.

Separate exploratory effects from confirmatory findings.

Where justified, use 16 or more independent learner initializations for confirmation. Cluster uncertainty estimates by genuinely independent worlds or experimental units, not repeated rows from the same world.

Do not use a 300-cluster zero-failure threshold as a universal standard for exploratory learning. Reserve appropriately justified high-confidence thresholds for specific safety claims. Mark unsupported claims unresolved rather than declaring success or impossibility.

Whatever the outcome, locate the causal reason.

If the learner fails, determine whether the blocker is representation, reachability, exploration, delayed credit, interference, missing information, or researcher ownership of the generative procedure.

Do not immediately tune constants and rerun.

2. PRESERVE THE INSTRUMENT VERDICTS

The execution gate reportedly passed after six review rounds and 22 killed mutants.

Preserve exactly what that demonstrates.

Stage A's host-dependent test remains NOT_RUN because a compatible kernel was unavailable. Do not relabel it as a pass or failure.

Keep its accepted test design for a compatible environment. Do not make unsupported host-level assurances.

The Birth v2 fixes must have their own exact source and verification record. Keep the approximately 15 accepted engineering defects traceable to individual repairs and regression tests.

Prioritize prevention of:

memory overlap from incorrect physical slot allocation;
persistent VM allocation leaks;
aliasing and mutable checkpoint corruption;
cross-arm state contamination;
hidden evaluator leakage;
duplicate controls;
stale binaries;
unreachable branches in claimed mutation tests;
labels presented as acquired evaluations;
generated verdicts that do not measure behavior.

All learner-facing inputs must come from the documented public interface, not private evaluator state.

If a repair changes the tested learner or environment, assign a new source identity and reproduce the result. Never silently inherit an earlier certification.

3. CLOSE THE EXPECTED-NULL EVALUATOR TEST

The strong hand-written Bayes enumerator is reportedly within approximately 0.01 AUC of the theoretical ceiling.

This is an important limitation on available improvement.

Complete the preregistered evaluator pilot and frozen evaluation without weakening that baseline.

If the learned evaluator only reproduces prior counting or verification-label lookup, classify the result accordingly and stop allocating substantial compute to it.

If an unexpected large improvement appears, give it to RT2 for immediate leakage, label-access, and scoring attacks.

The purpose is scientific discrimination, not finding an impressive headline where little headroom exists.

4. THE NEXT BIG EXPERIMENT MUST TEST LEARNING HOW TO CONSTRUCT COGNITION

The previous waves demonstrated bounded task-procedure reuse.

Now investigate something harder.

A learner experiences multiple unfamiliar problems and acquires a persistent executable structure that affects how it constructs future methods.

This is not merely a learned task program.

It is a learned way of generating, transforming, recruiting, or revising other learned programs.

Build the strongest feasible version of this hypothesis using generic primitives.

One possible sequence:

Experience A: TNN acquires a useful executable procedure.
Experience B: TNN encounters a different construction problem and acquires another procedure.
Experience C: an unfamiliar objective requires a new method or composition not explicitly demonstrated.
Experience D: previous construction behavior fails under changed conditions.
Experience E: TNN acquires or uses a persistent transformation that improves future construction.
Experience F: that transformation is useful on a genuinely new problem family.

Do not supply the learner with a completed sequence of cognitive instructions.

The stages describe evaluator outcomes; the learner should determine its intermediate activity.

Require identifiable tasks: useful information must be available through permitted observations or actions. Distinguish uncertainty caused by unavailable information from actual learning failure.

5. HAVE 3A, 3B, AND 3C COMPETE DIRECTLY

Preserve the competing-mechanism program:

3A - Structural plasticity

Can consequences drive useful structural changes that alter future computation, rather than merely storing or reweighting facts?

3B - Executable transformations

Can TNN acquire reusable executable transformations from successful and failed experience, then apply them to unfamiliar constructions?

3C - Self-organizing workspace

Can learner-created organizations causally improve the construction, applicability, or revision of cognitive methods?

All three must eventually attempt the same frozen objective set under comparable information and resource budgets.

Add a strong flat executable-store competitor.

Do not require the nested Web to win.

If its organization provides no unique causal advantage, retain the simpler substrate and focus on the learning mechanism.

Organization is not cognition unless it changes what the learner can productively discover or do.

6. THE MOST IMPORTANT ABLATION: ERASE CONTROL, KEEP KNOWLEDGE

The Phase 6 battery should be used on the first plausible learned-control mechanism.

Require:

Full experienced learner.
Fresh learner.
Experienced facts and task objects retained, learned control erased.
Learned control retained, task facts erased.
Learned control transplanted into a fresh frozen executor.
Relevant versus irrelevant versus misleading experience.
A strong facts-only executable reconstruction baseline.
Full-control structural permutation and unfamiliar goal-family transfer.

Confirm that each arm really changes what it claims to change.

Inspect action trajectories, learned objects, and write/read provenance.

The critical question is:

Does the acquired control structure change future method construction or investigation beyond what facts, cached programs, and fixed source rules already explain?

Do not equate state dependence with learner-created cognitive organization.

A complete researcher-defined algorithm with learned parameters may be useful L1/L2, but it is not automatically L3.

7. PRIORITIZE TRUE UNFAMILIARITY

Avoid generating many examples of the same small arithmetic, affine, parity, or fixed grammar family and calling them distinct intelligence tasks.

Use at least two substantively different identifiable problem families.

Include held-out:

goal combinations;
structural encodings;
construction procedures;
action affordances;
partially invalid prior methods;
relevant and misleading experience;
changed environmental rules.

Require sufficient evidence for the goals to be achievable.

Do not give the learner the correct method through a hidden source feature, exact likelihood tensor, evaluator-supplied repair target, or prewritten inquiry schedule.

A learner may correctly abstain when available evidence cannot determine an outcome.

If an optimal fixed solver already knows the complete mathematical class, treat it as an upper-bound reference. TNN does not need to outperform an oracle that was given the correct theory.

TNN does need to show that it can acquire useful competence without having that theory's complete cognitive procedure supplied in its source.

8. INVESTIGATE CREDIT AND RETENTION AS ARCHITECTURAL PROBLEMS

The three-step credit diagnostic and the long-lifetime interference results identify genuine research directions.

The next mechanisms should address:

delayed consequences across executable structures;
attribution of success or failure to reusable substructures;
acquisition of applicability conditions;
structural modifications that preserve valid old knowledge;
transfer without exact state-ID matching;
learner-created transformations that modify future learning.

Do not graft a fixed collection of human-named cognitive modules onto TNN.

Try to find generic local operations and experience-dependent structures from which these abilities can arise.

For negative results, determine whether the useful behavior was representable, whether experience could reach it, and whether the learning rule could retain it.

Distinguish all three failure classes.

9. INTEGRATE WITHOUT CLAIMING SUCCESS PREMATURELY

The next substantial engineering deliverable should be the smallest working persistent learner that receives a goal, acts on its environment, constructs useful executable structures, learns from feedback, and produces a verified result.

Use one frozen low-level learner interface across multiple tasks.

No source changes between hidden objectives.

No manually written task-specific plan.

No evaluator-chosen next step.

Every consequential choice should have provenance showing whether it came from source machinery or acquired learner state.

It is acceptable for the first version to fail badly.

A genuine integrated failure with a complete trace is more useful than another isolated synthetic success that cannot run inside TNN.

Do not call an experimental prototype canonical TNN merely because it compiles in Zag.

10. EVIDENCE AND RED-TEAM COORDINATION

The Phase 0 inventory lists 50 families and 1,026 hashed files. Preserve it as the historical record.

Some earlier entries were marked unavailable but later entries contain recovered versions. Reconcile these statuses by exact hash and source identity.

Distinguish:

received;
located;
compile-reproduced;
independently scored;
hostile-replicated;
integrated;
scientifically promoted.

Give red teams exact sources and preregistrations whenever possible before their conclusions are revealed.

Let hostile reviewers build strong baseline alternatives, not only corrupt the existing system.



11. AFTER THE 2,880-ROW RUN

Do not stop at its completion.

Produce a compact verdict:

What survived?
What failed?
What was actually learned?
What remained researcher-owned?
What did the ablations establish?
Which architectural explanation is still plausible?

Then immediately assign the strongest available workers to the highest-information successor.

If the outcome is another L1/L2 bounded improvement, preserve it and continue.

If every candidate collapses, determine the shared architectural cause rather than launching another large parameter sweep.

If a potential L3 candidate survives, freeze its sources and make independent hostile replication the priority before any claim.

FINAL DIRECTION

The objective is not to maximize how many experiments pass.

It is to discover a learning architecture capable of acquiring increasingly complex competence without the researcher writing each new cognitive method.

A researcher requests an unfamiliar outcome.

TNN should determine what information is needed, acquire it, construct useful methods, execute them, recognize failures, revise its own structures, and deliver the result.

Researcher supplies WHAT. TNN learns HOW.

Finish the current experiment, preserve scientific integrity, and concentrate the next research effort on learner-owned procedural construction, structural generalization, and integrated autonomous goal completion.

