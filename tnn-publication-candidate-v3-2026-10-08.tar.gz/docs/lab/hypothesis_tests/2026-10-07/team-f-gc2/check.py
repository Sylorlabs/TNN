import json,random,subprocess,sys,csv
from pathlib import Path
p=Path(__file__).parent;scope={'__file__':str(p/'run.py')};s=(p/'run.py').read_text();exec(s[:s.index('rows=[];traces=[]')],scope)
inputs=[];expected=[]
for snap in json.loads((p/'states.json').read_text()):
 state=snap['state']
 if state['arm'] not in ['mean','ewma','history','fresh','permuted']:continue
 seed=snap['seed'];index=snap['world']+30;cards=scope['world'](seed,index,seed%4)[1];pol=scope['Policy'](state['arm']);pol.sum=state['sum'];pol.n=state['n'];pol.value=state['value'];pol.history=state['history'];rng=seed*100+index
 expected.append(pol.select(cards,random.Random(rng))[0]);inputs.append({'state':state,'cards':cards,'rng':rng})
out=subprocess.run([sys.executable,str(p/'transplant.py'),'child'],input=json.dumps(inputs),text=True,capture_output=True,check=True);got=json.loads(out.stdout);assert len(got)==len(expected)
result={'fresh_process_transplants':len(got),'mismatches':sum(list(a)!=b for a,b in zip(expected,got))}
# Strong generic active baseline: rank untested descriptor categories ahead of tested until informative card found.
# Researcher explicitly owns novelty-priority and resolution threshold. Exactly 4 observations per world.
counts={};raw=[]
for seed in range(128):
 for index in range(16,24):
  secret=seed%4 if index<20 else (seed+2)%4;names,cards,part,target=scope['world'](seed,index,secret);post=set(names);used=set();known=None;first=0
  for t in range(4):
   rng=random.Random(seed*1000000+index*10+t)
   preferred=[c for c in cards if c[1]==known] if known is not None else [c for c in cards if c[1] not in used]
   cid,d=rng.choice(preferred or cards);used.add(d);members=[h for h in names if part[cid][h]==part[cid][target]];post.intersection_update(members)
   if len(members)==1:known=d
   if t==0:first=int(len(post)==1)
   cards=[c for c in cards if c[0]!=cid]
  raw.append({'seed':seed,'world':index,'first':first,'final':int(len(post)==1),'queries':4})
result['distinct_category_active_baseline']={name:{k:sum(r[k] for r in raw if lo<=r['world']<hi)/512 for k in ['first','final','queries']} for name,lo,hi in [('target',16,20),('shift',20,24)]}
with(p/'active_baseline.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=raw[0]);w.writeheader();w.writerows(raw)
(p/'verification.json').write_text(json.dumps(result,indent=2));print(result)
