import json,random,sys
# Standalone process loads serial policy only, no original generator/learner code import.
if len(sys.argv)>1:
 inp=json.load(sys.stdin);out=[]
 for row in inp:
  state=row['state'];scores=[]
  for j in range(4):
   if state['arm']=='ewma':v=state['value'][j];scores.append(4.5 if v is None else v)
   elif state['arm']=='history':v=state['history'][j];scores.append(sum(v)/len(v) if v else 4.5)
   else:scores.append(state['sum'][j]/state['n'][j] if state['n'][j] else 4.5)
  cards=row['cards'];m=max(scores[d] for c,d in cards);chosen=random.Random(row['rng']).choice([c for c in cards if abs(scores[c[1]]-m)<1e-10]);out.append(chosen)
 json.dump(out,sys.stdout)
