import random,math,json,csv,hashlib,subprocess,sys
from pathlib import Path
P=Path(__file__).parent
ARMS=['mean','ewma','fresh','permuted','explore','history','oracle']
class Policy:
 def __init__(self,arm):self.arm=arm;self.sum=[0.]*4;self.n=[0]*4;self.value=[None]*4;self.history=[[] for _ in range(4)]
 def scores(self):
  if self.arm=='ewma':return [4.5 if x is None else x for x in self.value]
  if self.arm=='history':return [sum(x)/len(x) if x else 4.5 for x in self.history]
  return [self.sum[j]/self.n[j] if self.n[j] else 4.5 for j in range(4)]
 def select(self,cards,rng,secret=None):
  if self.arm=='oracle':avail=[c for c in cards if c[1]==secret];return rng.choice(avail or cards),'evaluator_oracle'
  if self.arm=='explore' and rng.random()<.25:return rng.choice(cards),'researcher_exploration_rule'
  s=self.scores();m=max(s[d] for _,d in cards);return rng.choice([c for c in cards if abs(s[c[1]]-m)<1e-10]),'learner_policy_state_with_researcher_argmax'
 def update(self,d,r):
  self.sum[d]+=r;self.n[d]+=1;self.value[d]=r if self.value[d] is None else .5*r+.5*self.value[d];self.history[d].append(r)
 def wire(self):return {'arm':self.arm,'sum':self.sum[:],'n':self.n[:],'value':self.value[:],'history':[x[:] for x in self.history]}
def world(seed,index,secret):
 rng=random.Random(seed*100000+index);code=list(range(16));rng.shuffle(code);names=[f'{index}-h-{rng.getrandbits(64):x}' for _ in range(16)]
 cards=[];part={}
 for d in range(4):
  for k in range(4):
   cid=f'{index}-q-{rng.getrandbits(64):x}';cards.append((cid,d));part[cid]={h:str(code[j] if d==secret else (code[j]>>k)&1) for j,h in enumerate(names)}
 rng.shuffle(cards);target=rng.choice(names)
 assert len({tuple(part[c][h] for c,_ in cards) for h in names})==16
 return names,cards,part,target
rows=[];traces=[];ret=[];snapshots=[]
for seed in range(128):
 wanted=seed%4
 for prior in ['relevant','irrelevant','misleading']:
  for arm in ARMS:
   p=Policy(arm);old=[];before=[]
   for wi in range(24):
    secret=(wanted if prior=='relevant' else ((wanted+1)%4 if prior=='misleading' else (seed*7+wi*3)%4)) if wi<16 else (wanted if wi<20 else (wanted+2)%4)
    if arm=='fresh':p=Policy(arm)
    if wi==16 and arm=='permuted':p.sum=p.sum[1:]+p.sum[:1];p.n=p.n[1:]+p.n[:1]
    names,cards,part,target=world(seed,wi,secret);post=set(names);first=0;invalid=0
    for t in range(4):
     score=p.scores();card,owner=p.select(cards,random.Random(seed*1000000+wi*10+t),secret);cid,d=card;members=[h for h in names if part[cid][h]==part[cid][target]];post.intersection_update(members)
     if t==0:first=int(len(post)==1)
     if not post or target not in post:invalid+=1
     reward=math.log2(16/len(members))-.05;p.update(d,reward);cards=[c for c in cards if c[0]!=cid]
     if wi>=16:traces.append({'seed':seed,'prior':prior,'arm':arm,'world':wi,'step':t,'card':cid,'feature':d,'scores_before':score,'reward':reward,'remaining':len(post),'decision_owner':owner,'candidate_filter_owner':'researcher_generic_evidence_intersection','update_owner':'researcher_fixed_'+arm,'hidden_target_used_by_policy':arm=='oracle'})
    rows.append({'seed':seed,'prior':prior,'arm':arm,'world':wi,'first':first,'final':int(len(post)==1),'queries':4,'invalid':invalid})
    old.append((wi,secret,world(seed,wi,secret)[1]))
    if wi in (15,19,23):
     for ow,os,oc in old:
      (cid,d),owner=p.select(oc,random.Random(seed*1000000+ow*10),os)
      ret.append({'seed':seed,'prior':prior,'arm':arm,'checkpoint':wi,'old_world':ow,'old_success':int(d==os)})
     snapshots.append({'seed':seed,'prior':prior,'world':wi,'state':p.wire()})
with(P/'raw.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
with(P/'retention.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=ret[0]);w.writeheader();w.writerows(ret)
(P/'trace.jsonl').write_text(''.join(json.dumps(t)+'\n' for t in traces));(P/'states.json').write_text(json.dumps(snapshots))
summary={}
for prior in ['relevant','irrelevant','misleading']:
 summary[prior]={}
 for arm in ARMS:
  rr=[r for r in rows if r['prior']==prior and r['arm']==arm];summary[prior][arm]={}
  for name,lo,hi in [('target',16,20),('shift',20,24)]:
   block=[r for r in rr if lo<=r['world']<hi];summary[prior][arm][name]={k:sum(r[k] for r in block)/len(block) for k in ['first','final','queries']}
  summary[prior][arm]['first_curve']=[sum(r['first'] for r in rr if r['world']==i)/128 for i in range(16,24)]
  old=[r for r in ret if r['prior']==prior and r['arm']==arm and r['checkpoint']==23 and r['old_world']<16]
  summary[prior][arm]['old16_frozen_first']=sum(r['old_success'] for r in old)/len(old)
# parity, all world/action aggregate rows identical for mean vs independent history representation
parity=0
for seed in range(128):
 for prior in ['relevant','irrelevant','misleading']:
  a=[r for r in rows if r['seed']==seed and r['prior']==prior and r['arm']=='mean'];b=[r for r in rows if r['seed']==seed and r['prior']==prior and r['arm']=='history'];parity+=sum(any(x[k]!=y[k] for k in ['first','final','queries','invalid']) for x,y in zip(a,b))
(P/'results.json').write_text(json.dumps({'summary':summary,'rows':len(rows),'trace_rows':len(traces),'retention_rows':len(ret),'invalid':sum(r['invalid'] for r in rows),'history_parity_mismatches':parity},indent=2));print(json.dumps(summary,indent=2));print('parity',parity)
