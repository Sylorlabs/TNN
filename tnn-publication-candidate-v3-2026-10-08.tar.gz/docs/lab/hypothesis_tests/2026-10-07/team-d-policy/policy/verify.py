import pathlib,re,json,collections,statistics
R=pathlib.Path(__file__).parent
rows=[(m[0],list(map(int,m[1:]))) for m in re.findall(r'([A-Z]+),\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)',(R/'raw.csv').read_text())]
def tape(seed,n):
 t=[];z=seed
 for _ in range(n):z=(z*17+11)%997;t.append(z%3)
 return t
def run(t,x):
 for op in t:x=((x+1) if op==0 else x*2 if op==1 else -x)%31
 return x
def edit(t,e):
 if e<0:return t[:]
 if e<3:return [e]+t
 if e<6:return t+[e-3]
 if e==6:return t[1:]
 if e==7:return t[:-1]
 return t[::-1]
def apply(t,a,b):return edit(edit(t,a),b)
lib=[(-1,-1)]+[(a,-1) for a in range(9)]+[(a,b) for a in range(9) for b in range(9)]
expected=[];algebra=[]
for rg in range(3):
 for arm in range(3):
  scores=collections.defaultdict(int)
  for block in range(2):
   for seed in range(1,33):
    src=tape(seed+block*32,5+seed%8);target=9
    if (rg==1 and block==1) or (rg==2 and block==0):target=8
    goal=apply(src,3,4) if target==9 else edit(src,target)
    context=((run(goal,0)-run(src,0))%31)*31+(run(goal,1)-run(src,1))%31
    if arm==1:context=0
    used=set();tries=0
    while len(used)<91:
     idx=max((i for i in range(91) if i not in used),key=lambda i:(scores[context,i] if arm else 0,-i))
     used.add(idx);candidate=apply(src,*lib[idx]);win=int(all(run(candidate,x)==run(goal,x) for x in range(31)));tries+=1
     expected.append(('ACTION',[rg*10000+arm*1000+seed,block,idx,win]))
     if arm:scores[context,idx]+=4 if win else -1
     if win:break
    expected += [('END',[rg*10000+arm*1000+seed,block,tries,0]),('RESULT',[rg,arm,block,tries])]
    # Powerful exact affine post-composition solver uses two IO examples.
    # All tape primitives bijective, so source slope invertible mod31.
    b=run(src,0);a=(run(src,1)-b)%31;d=run(goal,0);c=(run(goal,1)-d)%31
    alpha=c*pow(a,-1,31)%31;beta=(d-alpha*b)%31
    assert all((alpha*run(src,x)+beta)%31==run(goal,x) for x in range(31))
    algebra.append({'regime':rg,'arm':arm,'block':block,'seed':seed,'alpha':alpha,'beta':beta,'verified':31})
assert len(expected)==len(rows)
bad=[(i,a,b) for i,(a,b) in enumerate(zip(expected,rows)) if a!=b]
print('exact scalar/native trace mismatches',len(bad),'of',len(rows),'actions',sum(k=='ACTION' for k,v in rows),'episodes',len(algebra))
(R/'reference.json').write_text(json.dumps({'mismatches':bad,'rows':len(rows),'episodes':len(algebra),'affine_rival_success':len(algebra)},indent=2))
(R/'affine_rival.json').write_text(json.dumps(algebra,indent=2))
