# TNN research evidence, October 7, 2026

Collection of supplied research reports, sources and raw results. See [publication notes](PUBLICATION_NOTES.md) for scope and exclusions, and [manifest](MANIFEST.json) for file hashes. No integrated general-intelligence result is claimed. Historical failures, negative controls and corrected findings remain in the collection.

## Reports

- [architecture-transplantation](reports/architecture-transplantation.md)
- [executable-reuse-successor](reports/executable-reuse-successor.md)
- [frontier-ownership-audit](reports/frontier-ownership-audit.md)
- [task-procedure-transfer-successor](reports/task-procedure-transfer-successor.md)
- [team-a-identifiability-successor](reports/team-a-identifiability-successor.md)
- [team-a-learnability](reports/team-a-learnability.md)
- [team-b-adaptive-web](reports/team-b-adaptive-web.md)
- [team-b-b3-corrected](reports/team-b-b3-corrected.md)
- [team-d-generative-machinery](reports/team-d-generative-machinery.md)
- [team-g-causal-inquiry](reports/team-g-causal-inquiry.md)
- [team-g-noisy-identification-successor](reports/team-g-noisy-identification-successor.md)
- [team-h-formal-induction](reports/team-h-formal-induction.md)

## Source and raw evidence

- [Team C hostile competition](team-c/report.md): Zag sources, compile/run logs, original hash inventory and preregistrations. Generated binaries and compiler caches excluded.
- [Team F lifetime policy-state transfer](team-f/report.md): original and corrected Python source, preregistrations, raw CSV, JSON outputs and logs. Original negative result retained.

The report-only findings are not complete runnable packages. Files were collected after experiments; local preregistrations are not retroactively upstream preregistrations.

## Later evidence

- [Team F GC2 checkpoint correction](reports/team-f-gc2-corrected.md), with original flawed and repaired evidence under team-f-gc2/.
- [Team D edit transformation](reports/team-d-transform.md) and [proposal dynamics](reports/team-d-policy-dynamics.md), with source/logs under team-d-transform/ and team-d-policy/.
- [Team A goal qualification](reports/team-a-goal-qualification.md), with source/logs under team-a-goal/.
- Team H4 ambiguity source/stdout under team-h4/.
