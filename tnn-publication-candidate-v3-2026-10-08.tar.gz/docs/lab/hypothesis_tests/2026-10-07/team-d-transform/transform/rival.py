# Independent full-power semantic repair rival. Shares world definition only via scalar reference.
import pathlib,json,statistics
R=pathlib.Path(__file__).parent
ns={'__file__':str(R/'compound_analyze.py')};exec((R/'compound_analyze.py').read_text().split('bestpair=')[0],ns)
tape,run,edit,apply,edits=map(ns.get,['tape','run','edit','apply','edits'])
results=[]
for seed in range(4,36):
 t=tape(seed,5+seed%8)
 for task,target in enumerate([9,1,8,3]):
  goal=apply(t,3,4) if target==9 else edit(t,target)
  expected=tuple(run(goal,x) for x in range(31));seen=set();generated=0;tested=0;matched=None
  for e in edits:
   generated+=1;c=apply(t,*e);sig=tuple(run(c,x) for x in range(31))
   if sig in seen:continue
   seen.add(sig);tested+=1
   if sig==expected:matched=e;break
  assert matched is not None
  results.append({'seed':seed,'task':task,'generated':generated,'distinct_verified':tested,'scalar_effects':generated*31,'edit':matched})
(R/'rival_results.json').write_text(json.dumps(results,indent=2))
for task in range(4):
 rr=[x for x in results if x['task']==task]
 print(task,'distinct verified',statistics.mean(x['distinct_verified'] for x in rr),'generated',statistics.mean(x['generated'] for x in rr),'scalar effects',statistics.mean(x['scalar_effects'] for x in rr))
