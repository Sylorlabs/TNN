import pathlib,json,subprocess,statistics,itertools
R=pathlib.Path(__file__).parent

def tape(seed,n):
 out=[];z=seed
 for _ in range(n):z=(z*17+11)%997;out.append(z%3)
 return out

def run(t,x):
 for op in t:
  if op==0:x=(x+1)%31
  elif op==1:x=x*2%31
  elif op==2:x=-x%31
 return x

def edit(t,e):
 if e<0:return t[:]
 if e<3:return [e]+t
 if e<6:return t+[e-3]
 if e==6:return t[1:]
 if e==7:return t[:-1]
 return t[::-1]

edits=[(-1,-1)]+[(a,-1) for a in range(9)]+[(a,b) for a in range(9) for b in range(9)]

def equal(a,b):return all(run(a,x)==run(b,x) for x in range(31))
def apply(t,a,b):return edit(edit(t,a),b)
def train(a,b):return all(equal(apply(tape(s,9 if s==4 else s+1),a,b),apply(tape(s,9 if s==4 else s+1),3,4)) for s in range(1,5))
surv=[e for e in edits if train(*e)]
bestpair=next(e for e in edits if train(*e));best=bestpair[0];(R/'learned_state.json').write_text(json.dumps({'edit_tape':bestpair,'training_tapes':0}))

# Fresh native processes use only saved edit operand, no training gate in transplant mode.
for name,operand in [('transplant',bestpair),('erase',(-1,-1)),('wrong_prior',(1,1)),('reverse',bestpair[::-1])]:
 # '-' means erasure (outside0..8), never resynthesized in native mode.
 arg=''.join(str(x) if x>=0 else '-' for x in operand)
 p=subprocess.run([str(R/'compound'),arg],capture_output=True,text=True,check=True)
 (R/f'{name}.csv').write_text(p.stdout)

import re
def parsed(path):
 return [(m[0],list(map(int,m[1:]))) for m in re.findall(r'([A-Z]+),\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)',path.read_text())]
rows={};costs={};mismatch=[];ids=[];pres={}
for k,v in parsed(R/'compound_raw.csv'):
 if k=='ROW':rows[tuple(v[:2])]=v[2:]
 if k=='COST':costs[tuple(v[:2])]=v[2:]
 if k=='IDENT':ids.append(v)
 if k=='PRESERVE':pres[tuple(v[:2])]=v[2:]
for (seed,task),(valid,c) in rows.items():
 t=tape(seed,5+seed%8);target=[9,1,8,3][task];goal=apply(t,3,4) if target==9 else edit(t,target)
 expect=equal(apply(t,*bestpair),goal)
 first=next(i+1 for i,e in enumerate(edits) if equal(apply(t,*e),goal))
 prior=1 if expect else 1+first
 if [int(expect),first]!=[valid,c] or costs[seed,task][0]!=prior:mismatch.append((seed,task))
summary={'learned_edit':bestpair,'version_space':surv,'reference_mismatches':mismatch,'tasks':[]}
for task in range(4):
 rr=[v for (s,t),v in rows.items() if t==task];cc=[v[0] for (s,t),v in costs.items() if t==task];ss=[v for v in ids if v[1]==task]
 tr=[]
 for name in ['transplant','erase','wrong_prior','reverse']:
  xx=[v for k,v in parsed(R/f'{name}.csv') if k=='ROW']
  tr.append((name,sum(v[2] for v in xx if v[1]==task)))
 summary['tasks'].append({'task':task,'n':len(rr),'prior_only_correct':sum(v[0] for v in rr),'plain_mean_tests':statistics.mean(v[1] for v in rr),'prior_mean_tests':statistics.mean(cc),'survivor_disagreements':sum(v[3]==0 for v in ss),'transplant_controls':tr,'slot_preservation':sum(v[0] for (s,t),v in pres.items() if t==task),'slot_total':sum(v[1] for (s,t),v in pres.items() if t==task)})
(R/'compound_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
