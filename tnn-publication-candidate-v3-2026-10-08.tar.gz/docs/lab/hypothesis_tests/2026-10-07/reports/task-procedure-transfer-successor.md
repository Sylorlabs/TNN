# Successor: anonymous executable procedure transfer
October7,2026. This is a NEW Python research prototype, not canonical TNN, not revise-real, and not a reproduction of missing sources. Local prospective prereg files precede their respective implementations/runs. Upstream unchanged.

## Result
A generic frozen executor can run compound procedure state selected from anonymous IO examples, including recursion to depth32 from training inputs no longer than5. Fresh-process procedure-only transplant gets50/50, with no training examples in its state. This survives as a modest demonstration of learned executable *task procedure* selection and transfer. It does not demonstrate discovery of how to learn, organize cognition, invent new operations, or expand the source-defined search language. Full-power fixed-library and facts-only synthesis both50/50. Procedure erasure only hurts if resynthesis is disabled. Thus any claim that this establishes a special architecture or learned cognitive-method advantage is killed on these tasks; the broad objective remains unresolved.

## Source ownership
The researcher defines the entire interpreter, five operations, their recursive implementation, exhaustive search order, length cap3, training selection strategy, version-space query method, and success metric. Experience selects a compound instruction sequence, not the search/organization method. In particular recursive duplication exists as a primitive; the learner does not discover its recursion implementation. There are no named domain routers or PLAN/INVENT modes, but the fixed instruction vocabulary limits search to156 programs. This is substrate plus fixed synthesis, not a method-learning architecture.

## Method
DSL: reverse, rotate-left-one, duplicate each element via fuel-bounded recursion, take every other element, swap adjacent pairs. All156 programs of length0..3 are legal for all competing syntheses. Training anonymous token examples initially lengths2,3,4; heldout inputs lengths1,5,8,16,32 with two disjoint symbol alphabets (10 cases/task). Target procedures DL, RE, LDS, SL, DER. Evaluation knows targets; the learner only sees example/consequence pairs.

A passive identifiability gate rejected SL and DER: multiple training-consistent hypotheses disagree on longer inputs. SL's first consistent program LR scored2/10, but that is NOT evidence against learning. A prospectively recorded generic active query rule picks the shortest length with the most distinct version-space output partitions from lengths1..12, at most3 queries. One query at length5 repairs each ambiguous world. All remaining hypotheses agree on the10-case heldout battery and on all distinct-token inputs lengths1..64. This is finite-class/finite-length extensional agreement, not a global proof over arbitrary lengths, repeated tokens, or richer transformations.

Note: two repaired worlds have seen length5 with a different alphabet. Their length5 tests are symbol-transfer, not unseen-length tests; lengths8/16/32 remain unseen.

Procedure state is serialized then read by separate fresh Python processes using the same frozen executor, never the target program or expected output. Full control contains program plus examples. Transplant contains only program. Every control uses exactly512 serialized bytes, padded with whitespace; meaningful payload bytes are reported separately. This matches file budget, not heap/runtime memory or total compute.

## Raw results

| target | selected | active queries | consistent programs | synth candidate tests | training interpreter steps |
|---|---|---:|---:|---:|---:|
|DL|DL|0|2|18|123|
|RE|RE|0|1|10|59|
|LDS|LD|0|3|14|95|
|SL|SL|1 (length5)|1|28|282|
|DER|R|1 (length5)|8|2|18|

LDS and DER simplify within this language. That is not invented new structure. Query discovery scans the full version space and its cost is additional; candidate-test counts above cover only final first-consistent synthesis, NOT active-search computation or total runtime.

| arm |DL|RE|LDS|SL|DER|total|
|---|---:|---:|---:|---:|---:|---:|
|full procedure|10|10|10|10|10|50/50|
|procedure removed, inactive executor|0|0|0|0|0|0/50|
|procedure removed, active facts resynthesis|10|10|10|10|10|50/50|
|instruction order reversed|2|4|2|2|10|20/50|
|inconsistent prior program|0|2|0|2|2|6/50|
|fresh process, procedure only|10|10|10|10|10|50/50|
|fixed full-library selector|10|10|10|10|10|50/50|
|facts-only complete enumeration|10|10|10|10|10|50/50|
|nearest-example sequence transduction|0|2|0|2|2|6/50|
|learned index-copy sequence program|10|10|10|10|10|50/50|

The index-copy sequence competitor is another representation of the same complete synthesis, not an independently trained neural system. It receives the full library. Nearest-example transduction is a simple baseline; its defeat cannot support superiority over capable sequence learners. No neural sequence-model run was attempted, and that requested comparison remains unfulfilled. This explicit limitation is preferable to pretending the baseline class is fully covered.

Full/transplant target execution steps over10 probes: DL402, RE268, LDS278, SL268, DER134. Total1350. Maximum recursive depth32 for DL/LDS,0 elsewhere. Same4096-step fuel per execution, same156-candidate cap per synthesis, identical examples and active answers for capable baselines. Padding achieves the same512-byte serialized-state allowance, not real memory parity. Full meaningful payload167..285bytes; transplant18..23bytes. Active resynthesis pays training costs again; execution-only erasure is therefore not a fair negative baseline.

## Verdict discipline
- Procedure selection and fresh-process reuse: SURVIVED narrowly.
- Passive SL/DER conclusions: VOID due identifiability failure, not learning failure.
- Active repair: SURVIVED within this enumerated class and length1..64 test range.
- Unique method/architecture advantage over facts plus unrestricted synthesis: KILLED on this world.
- Learning to discover how to organize cognition: UNRESOLVED. The learning/search method never changes.
- Full neural sequence competitor, independent red-team implementation, native TNN integration, repeated-token/richer-composition evaluation, true total-compute matching: NOT RUN.

Next informative move is not another easy procedure-selection world. Put the proposal policy or organization policy itself in a mutable executable state, retain all IO facts and discovered objects during its erasure, and compare adaptation cost under a fixed primitive evaluator and complete baseline. Independently adversarially check whether cached enumeration or a flat executable store explains any positive. This prototype establishes an assay interface, not the final architecture.
