# Team A: learnability before method ownership
October 7, 2026. Read-only first-wave finding.

## Answer
The published queue supports a class-relative selection result for program-lossy, not open method invention. Join-underdet explicitly leaves multiple training-consistent rules with different heldout predictions, and neither documented arithmetic rule matches the actual holdout labels. Holdout-uncacheable removes exact cache hits but does not by itself make its hidden law identifiable. These are not architectural failures: the information question must be settled first.

Verdict: UNRESOLVED for exact named-world learnability because their drivers and train/query/feedback traces were not found in the three inspected branch trees. KILLED: any inference that disjoint lookup misses alone establish identifiable method invention. SURVIVED: a bounded mathematical demonstration that teaching evidence can identify reusable behavior within an explicitly declared class.

## Current evidence and source ownership
Pinned remote heads, rechecked at closeout:
- lane/ownership: d1ed7f15f60a3314896c2935d7057b72e55ea3bb.
- fast/method-identifiability: 6fa4fd4c7735cc12374c6f3339fa46edfb8b2a45.
- main: 27a4271f208247a1e9c24cca35468c298b6cd29d.

The ownership FRONTIER_QUEUE.md reports:
- join-underdet: F1-add and F2-mul each 2/2 train, each 0/2 hold, disagree on both holdouts; learner empty. Therefore one cannot select either rule and call it the hidden truth. The queue's later joinown2 row confirms arithmetic forms are not enough to settle the intended ownership claim.
- holdout-uncacheable: facts 0/8 hold, increment oracle 8/8, fresh 0; learner empty. These certify a lookup-miss diagnostic only. No observed train list or information-flow boundary was recovered.
- program-lossy: compact (form,k) 4/4 hold versus facts 0/4; unique XOR-5; removing XOR-k leaves 0/4. This is selection within a researcher-supplied complete-form menu according to the queue, not a novel acquired method.
- inc-own successor: searches x+k for k in 0..7, picks 1, 8/8 hold; deleting k=1 gives 0/8. Again the complete transform family is supplied.

The fast report already says alternative fitting data is not wrong because a researcher secretly intended another law, and requests a same-information facts-only method baseline. The research goals T06 ask for one distinguishing observation in join-underdet. That is a proposed discriminating setup, not proof the current driver exposes such an observation.

Named-world source limitation: searches for exact world names and output markers across ownership, fast and main did not locate the associated drivers. Their queue rows are historical claims, not replicated raw measurements. Other Zag experiments are present. No claim that the entire repository lacks these worlds or that no older commit can contain them.

## Paper result: what can training identify?
Let E be the full learner-visible transcript, including input labels, costs, ordering, timing, action consequences, failures, metadata and prior state. If two possible worlds produce the same distribution of E for every permitted training action, but require different answers at an evaluation point, no learner using only E can be uniformly correct there. Under an equiprobable two-world prior, expected exact prediction at a disagreement point is at most 1/2. On agreement points this bound does not apply. Any advantage comes from an extra prior assumption, a distinguishing query, leakage, or luck.

For deterministic training, the relevant object is the version space H(E). Behavior is identifiable on evaluation set Q precisely when all surviving hypotheses agree on Q. Unique source syntax is unnecessary: observationally equivalent programs can implement the same method. Conversely, finite observations never identify an arbitrary unrestricted function on unseen inputs. A declared structural prior or permitted further inquiry is necessary.

Identifiability is necessary, not sufficient, for bounded-compute learning. A distinguishing transcript can exist but be unreachable at the allowed query budget, or recovering its behavior can exceed the search budget. A representable oracle alone proves neither.

## Independent tiny runs
New standalone pure-Zag witness, preregistered locally before source creation. NOT TNN runs and NOT reproduction of the named-world fixtures. Two fresh compilations and executions, both exit 0, identical binaries and output. No non-Zag interpreter used for scientific computation.

1. Join witness: train (0,0),(2,2) makes addition and multiplication agree; hold (1,2),(2,3) makes them disagree. All four deterministic policies choosing either answer independently at each hold point score exactly 2/4 aggregated over the two equiprobable worlds. One query at (1,2) separates them. This witnesses the theorem, not the real queue fixture.
2. Uncacheable witness: domain 0..15, train 0..7, hold 8..15. Increment-mod16 has exactly one surviving translation among 16 translations. Yet 256 alternative binary-perturbation completions fit the same training. Fixed increment scores 1024 correct across 2048 heldout predictions under uniform completions, or 4/8; exactly one of 256 completions matches its entire heldout vector. Disjointness and identifiability are different properties.
3. Program witness: enumerate all 1,048,576 affine four-bit GF(2) maps. Training x={0,1,2,4}, y=x XOR 5 leaves 16 maps; adding x=8 leaves one. The recovered behavior solves 11/11 never-seen points. Algebraically, observing zero identifies the offset and four basis vectors identify all four columns, so the count has a separate hand-derived check. Unrestricted maps still have 16^11 heldout completions.

The third result is explicitly a diagnostic with a complete affine hypothesis class. It does NOT meet the user's no-complete-form-menu target. Its purpose is to qualify an informative world before testing a more general learner.

Raw rows, source and hashes accompany this report. Source SHA256: 6175e563acfbfa075c3c3460ad96d046097c93105914058c62c79e7fd52ea369. Binary SHA256 both builds: 801f12f07f37a4b325de2ee6f824a4e02494d5b33e5151c4100b635e9e4817f7. Output SHA256 both runs: 43d2a04858b95b2332f4e42d7d7d5e7166c1f85e0f4817b776a2d242f96ff886. Determinism is not independent replication.

## Strongest non-learning explanations for positives
- program-lossy/inc-own: parameter fitting or finite menu selection, followed by a researcher-coded interpreter. The queue's deletion results support this explanation directly.
- uncacheable positive: source supplies increment/generalization; removing lookup merely rewards the built-in formula. Broaden facts-only from a deliberately blind key-value cache to equally informed exact inference/search.
- join positive without a witness: fixed tie-breaking or a task-correlated prior; if the average stays above chance under balanced law swaps, audit information flow before attributing learning.
- a persistent executable object improves latency: compiled/cached search output, not changed generative machinery. A cold baseline that reruns the same inference can be slower while matching capability. Report amortization honestly and include acquisition cost.
- affine witness: exhaustive search in a supplied function family. It is intentionally the strongest simple explanation, not an architectural discovery.

## Proposed preregistered successor (not implemented or committed)
Question: after genuinely distinguishing experience, can a fixed generic construction substrate retain an executable object that reduces cost on unseen cases beyond strong equally informed reconstruction?

Stage 0, qualification only:
1. Recover and freeze the actual world sources, dataset, allowed inquiry API, learner/evaluator boundary and prior state. Preserve original histories unchanged.
2. Define the complete bounded program semantics and observation protocol. Distinguish the evaluator's hidden target from the learner's visible primitives; no complete target-form enum, task router or new source changes across target laws.
3. An independent oracle enumerates observational equivalence classes on a small finite domain. Before learner evaluation, compute surviving class counts after each teaching observation and the predictions on all never-taught inputs. Use a distinguishing teaching sequence that leaves one behavioral class, plus a paired ambiguous prefix that deliberately leaves at least two disagreeing classes.
4. Include target programs absent as whole forms from source, random balanced target laws, renamed/permuted encodings and at least one composite target requiring greater depth than demonstrated. If full identification is infeasible, preregister the exact risk/disagreement bound rather than pretending uniqueness.

Stage 1, retained-method test:
Freeze 32 balanced independently seeded targets before runs. Train on qualified informative traces, query never-taught inputs, then test related representation transfer and partial law invalidation. Compare intact object, object erased/facts kept, facts erased/object kept, fresh, irrelevant and misleading prior, matched same-information generic search, and a strong flat facts-plus-inference rival. State fingerprints must prove which object each arm actually executes. Count total training/inquiry/construction plus evaluation operations and memory, not wall time alone.

Frozen falsifiers:
- No claimed information gain on ambiguous prefixes; uncertainty/abstention or chance-calibrated predictions count as correct behavior.
- Informative teaching traces must yield agreement of the qualified version space on evaluation queries before architectural interpretation.
- Equal disclosed data, primitives, compute and memory budgets in all inference rivals; exact key lookup is only a weak secondary baseline.
- Erasing the retained object must change execution and remove its measured cost advantage; sham erasure must not. Capability and cost are separate endpoints.
- Transfer accuracy at least 90% on each frozen qualified target; at least 20% reduction in total lifetime operation count relative to the strongest same-information rival on the preregistered evaluation horizon. Paired target-level uncertainty intervals must exclude zero improvement. No claim if the horizon is chosen after seeing results.
- No extra target-form implementation, hidden task dispatch, answer leakage or compilation failure. Compile failure is PROCESS-FAIL, not architectural failure.

The complete generic primitive set remains researcher-owned. A positive here supports experience-conditioned executable reuse under a declared model class. Open method invention additionally requires showing retained structure changes practical future construction, not merely inference/ranking within supplied methods; this successor does not silently grant that stronger conclusion.

## Source notes
Observed and verified repository URL: https://github.com/Sylorlabs/TNN
Internal file provenance at the pinned commits above:
- docs/lab/research-lead/FRONTIER_QUEUE.md (live integration read at ownership pin, local source read at both branches).
- docs/lab/research-lead/RESEARCH_GOALS_AND_TESTS.md (fast pin, T05/T06/T12).
- docs/lab/research-lead/CURRENT_EVIDENCE_NOTES.md (fast pin).
- docs/lab/research-lead/overnight-20260928/fast_goals_20261006/REPORT.md and PREREG.md (fast pin).
- tools/zbuild.sh and included Zag compiler help (build gate/availability only).
Only the repository root URL was observed as a usable web link; file paths and commit hashes are provenance, not invented content URLs.

No commit, push, branch update, repo source edit, canonical learner run, named-world replay or capability promotion. Scratch files and independent local test binaries only.
