# Team D: experience-built generative machinery

October 7, 2026. Repository https://github.com/Sylorlabs/TNN, fresh checkout commit `27a4271f208247a1e9c24cca35468c298b6cd29d`. No commits, pushes, or upstream edits.

## Answer and verdict

**The tested B-alpha candidate learns sensory material and low-order construction statistics, but not a reusable generative program.** Three source-defined scenes use learned timing/transition state for fill. A fourth ignores it completely. Scene construction, operation families, semantic roles, and routing remain researcher-owned. This kills the claim that these particular programs already demonstrate learner-owned reusable generative machinery. It does not kill the possibility that another learner could do so. For the full TNN/L3 proposal, the verdict is **unresolved**, with a **process-fail** for presenting the R33 continuing-life infrastructure as a runnable integrated scientific learner: its `learn` branch explicitly refuses execution.

A small positive survives: experience-derived statistics can change future generated event counts and timings without source edits. That is stronger than one enable bit, but weaker than experience constructing an interpreter-executed rewrite, recursive transformation, macro, or constraint program.

## Candidate selection and source ownership

The fresh repository was inspected across `src/experiments`, `docs/program`, current R33 engineering paths, and `docs/lab`. Relevant candidates:

- `docs/lab/imagination_discovery/aud/b_alpha/src/study.zag`: segments sensory recordings, computes six descriptors, uses source-fixed duration/ZCR rules for four classes, runs fixed k=4 clustering, learns 16 class bigrams and 12 gap quantiles, and stores source waveform atoms.
- `.../src/render.zag`: four explicit `kids/planet/ocean/alien` routers. Source owns literal beat schedules, playback-rate/gain choices, event placement, repeat exclusion, class interpretation, fixed seeds, hash selection, and interpolation. `score_kids` uses transition/gap state; planet and ocean consult gaps but choose classes by hash; alien contains literal beats and no grammar-fill loop.
- `.../src/common.zag`: researcher-defined data layout, audio arithmetic and output format.
- `docs/lab/cognition_ws/ws2l/learn.zag` and `MECHANISM.md`: relation facts learned using four frozen surface matchers; transitive closure fixed in source. This is learned lookup state, not a learned procedural transformation. Its import `lib.zag` is absent from its directory, so a fresh native build failed; archived 69/69 is not a rerun result.
- `docs/lab/bytegen/par_dive/contender_d/formation/expand_motif.py`: compact motif expands through hardcoded SEMIS/DELTAS and arithmetic. The producer wrote the motif; no experience-learning step exists there.
- `docs/generations/R33/runs/R33_CONTINUING_LIFE_V1/driver.zag`: `learn` returns65 with a pending-runtime refusal. Archived current entry point states scientific exposure0 and learner authority false; those are repository claims, not newly executed scientific runs.

None of the inspected candidates supplied a trained, persisted, executable learned program plus a generic evaluator through which it changes available construction procedures. This is scoped inspection, not a proof of absence across every historical artifact.

## Fresh native experiment

Unmodified `study.zag` and `render.zag` both built successfully. A deterministic nonsemantic sensory fixture used two 12-second mono PCM16 streams with repeated short low-ZCR, short high-ZCR, and long low-ZCR events. This fixture diagnoses state dependence, not perceptual realism or scene success. Source segmentation retained 24 atoms, zero textures; its fixed classifier found 12 class0 and 12 class2 atoms, no class1. Fallback selection therefore matters in these counts. Catalog size was360,948 bytes. Fresh repeated study produced byte-identical catalogs. Reversing experience order changed catalog bytes.

Catalog transition counts were `(0,0,10,0; 0,0,0,0; 12,0,0,0; 0,0,0,0)`. Gap triples in milliseconds were `(1590,1590,1590; 0,0,0; 410,410,410; 0,0,0)`.

Six catalog variants preserve every sensory atom, sample, descriptor, and catalog length except intentional atom ordering or class renaming. Same renderer, scene inputs, output duration, and 8-second run cap:

1. Learned catalog, unchanged.
2. Facts-only-neutral: transition counts erased, all gaps set to1000ms. Neutral positive gaps avoid a known no-progress loop; this is not a literal state reset.
3. Misleading prior: all transition mass to class3, all gaps5000ms. This is an externally imposed wrong prior, not evidence that learning corrected it.
4. Fixed-uniform construction control: uniform transition mass, gap triples410/1000/1590ms, using the empirical gap range. This is a fixed statistical control, **not** a sufficient strong baseline for a capability comparison.
5. Reverse atom storage order, retaining grammar.
6. Class0/class2 renaming, with consistent grammar and quantile permutation. Source-fixed semantic routing is deliberately untouched.

An observational local copy logs successful event placements; it never changes selection or construction. Its WAV SHA-256 matched the unmodified renderer in24/24 paired runs. Raw traces and hashes are in `results.json`; build and run logs are retained.

### Number of successfully placed events

| State | kids | planet | ocean | alien |
|---|---:|---:|---:|---:|
| learned |66|36|50|24|
| facts-only-neutral |65|32|43|24|
| misleading |45|25|25|24|
| fixed-uniform |58|31|42|24|
| reverse atom order |69|35|47|23|
| class rename, grammar consistent |70|38|50|23|

All24 variants exited0. Counts measure construction changes, not quality or success. Higher is not better.

Across learned versus facts-only-neutral, misleading, and fixed-uniform, the first45 kids placements, first23 planet placements, and first21 ocean placements are **exactly identical** in time, requested class, selected atom, and stream index. Learned statistics affect only subsequent fill. Alien's24 placements and entire WAV are byte-identical under all three grammar interventions. Atom order and class labels affect selected material and repeat exclusion; they are not equivariant learned transformations.

Unknown scene input `novel` exits32. New experience cannot install a new router through this catalog format.

### Literal reset failure

A second ablation truly erases all112 grammar bytes. Under a2-second cap, kids, planet, and ocean time out; alien exits0. An earlier kids attempt timed out after40 seconds. Source inspection explains the failure: `cur += gap` has no positive lower bound. Zero gaps prevent progress forever; the same issue arises with an empty learned state. This is an operational process failure, not zero accuracy and not a fair baseline victory. It must be fixed before zero-state or corrupted-state capability comparisons count.

## Literal computability versus practical generative reachability

The implementation language can express recursion, loops, and transformations. That establishes expressibility of researcher-authored algorithms, not reachability by this learner. The catalog carries waveform atoms and a fixed-width transition/quantile table. It contains no instruction tree, rewrite-rule body, recursion operator, control-flow graph, variable binding, executable macro, or learned constraint language. The four renderer procedure bodies do not emerge from training. Experience changes reachable output trajectories inside those bodies; it does not install a new body or grow a procedure family.

Even a finite primitive grammar that includes a target program would not settle practical reachability: under a fixed operation, memory, and experience budget one must show that training state changes whether the target construction is found or executed. This experiment does not claim such a result.

## What could and could not be run

Ran fresh native study, fresh deterministic repeat and reversed-experience study,24 trace renders,24 byte-equivalent unmodified renders, four zero-grammar probes, and one unknown-scene probe. No upstream mutation.

Could not reproduce the archived B-alpha realism/no-copy claims: its original study recordings/catalogs are explicitly local-only and absent. Artificial fixtures are disclosed rather than substituted silently. No blind listening panel was run. No held-out construction-success metric exists for this candidate. WS2-L fresh build fails because `lib.zag` is missing. R33 `learn` is source-refused, so no full scientific training campaign or strong-baseline contest was run. Platform-specific archived qualification binaries were not misrepresented as fresh scientific experiments.

Did **not** run an external program-synthesis baseline or invent a new learner to make the comparison appear complete. A facts-only exhaustive/beam enumerator with the same generic primitives, a properly trained sequence model, and a fixed-library control remain necessary. Fixed-uniform above is only a mechanistic control. Resource matching here holds input atoms, catalog bytes, procedure, durations, and caps constant, not a claim that total training FLOPs or memory peaks were measured equally across algorithms.

## Failure analysis

1. Construction ownership remains in scene-specific source, including forbidden-for-the-target domain routing.
2. Learned low-order statistics change fills but do not encode reusable programs.
3. Alien grammar ablations have no effect at all: a useful falsification of generic 'learned grammar constructs the scene' wording.
4. Storage-order dependence and source-fixed class meanings fail stronger permutation/renaming expectations.
5. Zero-state nontermination invalidates naive ablation scoring and practical reachability under a finite budget.
6. Archived procedural-learning/quality numbers cannot fill missing runnable entry points or missing sensory inputs.

## Next highest-information experiment

Before a large tournament, require **one learned program transplant** into a frozen generic executor. Use a single generic term/sequence evaluator with anonymous operations (match, bind, compose, substitute, recur with fuel, reject). No PLAN/INVENT/scene modes, named semantic classes, or domain router. Train from input-output-consequence examples of an unknown compositional transformation. Freeze source before exposure. The procedure must be serialized as learner state with experience provenance, then transferred to a fresh process sharing the generic executor but none of the original episode store.

Compare full state, procedure removed with facts retained, shuffled procedure, wrong learned procedure, and transplanted procedure. Test longer recursive depth, unseen symbol permutation, new atom names, and held-out compositions. Match operation count, training examples, state bytes, and fuel. Baselines must retain full capability: a fixed-library method with the same generic operations, facts-only beam/enumerative synthesis allowed the entire fuel budget, and a trained sequence learner with disclosed size/cost. Score exact output correctness and constraint satisfaction, program-size/depth, generated-candidate count, cost to first valid construction, nontermination/refusal, and old-task regression. A full-state advantage that vanishes only when procedural state is removed and returns under transplant would locate method ownership in state. A source mode bit, ranker, or supplied task-specific macro fails the claim.

This is the next proposed experiment, not an implemented or completed result.
