# Team F Grand Challenge II: lifetime policy dynamics and ownership
October7,2026. NEW local synthetic extension, not TNN/revise-real reproduction. All earlier negative and positive evidence preserved. Context only: https://github.com/Sylorlabs/TNN.

## Verdict
Policy-state transfer under relevant priors SURVIVED exact lifetime-exposure matching and genuine fresh-process transplantation. Adaptation to shifted descriptor meaning FAILED for the tested mean and EWMA policies. Fixed-policy architectural advantage KILLED by exact history-counter parity. Learned cognitive-workflow ownership remains UNRESOLVED and is not demonstrated: source still owns learning rule, descriptor representation, permitted actions and optimization. Do not infer architectural impossibility from this fixed-family failure.

## Experiment
128seeds x3prior types x7arms x24worlds =64,512world rows. All arms get exactly4observations/world,96lifetime observations, even after target identity known. Targetworlds16..19 share one descriptor utility; worlds20..23 shift to a different descriptor. Earlier worlds are relevant, misleading or varying-category irrelevant. All task/card identities are disjoint perworld, facts clear everyworld. 16hypotheses and16query cards: four anonymous descriptor categories; one category yields singleton membership witnesses, others binary partitions. Exhaustive complete-card signatures distinguish all16hypotheses. This is identifying within the declared world family, but identifiability does not force a learner to query useful witnesses.

Policy arms: empirical mean, EWMA withalpha0.5, fresh/reset, METHOD coordinates permuted afterprior block, mean with25%random exploration, separately written history-list mean representation, evaluator oracle bound. No new cognitive mode, planner or subsystem is added. This is not an integrated request-understanding learner: the outcome criterion and state updates remain source-authored.

64,512rows;86,016target action traces;161,280frozen old-world policy probes;0invalid posteriors; history/mean aggregate parity0mismatches across9,216paired worlds. 5,760serialized METHOD snapshots loaded by a separate Python process and replayed on new card layouts give0choice mismatches. Unlike preceding same-process JSON test, this is fresh-process replay. This test still uses same fixed policy semantics, not transplantation into a new learned executor.

## Primary results
First-query identification percentages, target/shift. Every mean/EWMA/history/fresh/permuted arm ultimately identifies100%by4queries. Each gets exactly4charged observations regardless.

| Prior | Mean target | Mean shift | EWMA target/shift | Fresh target/shift | Exploration target/shift |
|---|---:|---:|---:|---:|---:|
| Relevant |100%|0%|100%/0%|26.5625%/23.8281%|82.8125%/5.6641%|
| Irrelevant |50%|50%|50%/50%|26.5625%/23.8281%|46.0938%/19.9219%|
| Misleading |0%|0%|0%/0%|26.5625%/23.8281%|7.4219%/5.6641%|

Exploration final identification target/shift: relevant100%/72.2656%; irrelevant79.4922%/74.6094%; misleading72.2656%/72.6563%. Exploration thus loses terminal outcomes, despite occasionally reaching the useful category. Pure policy chooses four distinct binary-bit cards of one category and can identify target byquery4 without discovering that another category would be faster. Repeated small information gains sustain its inherited category preference. EWMA changes observation weighting but not experience selection, so it does not repair this failure. This is a concrete coupling failure between credit and inquiry selection, not lack of distinguishability.

Permuting METHOD coordinates yields relevant0%target and misleading100%target, both0%aftershift. This reverses prior alignment, consistent with preference calibration rather than acquired general acquisition procedure. Exact history-list counter matches mean on every pairedworld. It is a representation-parity competitor sharing worlds, not wholly independent science.

## Pointwise earlier behavior retention
Afterworld23, frozen-state first-query potential on allprior16cardlayouts (no updates during probes): relevant mean/EWMA/history100%, fresh0%, permuted0%, exploration82.3730%; irrelevant mean/EWMA/history/fresh/permuted25%, exploration25.0488%; misleading mean/EWMA/history100%, fresh0%, permuted0%, exploration81.9336%. Oracle100%. These are policy probes, not append-only evidence rechecks. Holding old behavior while failing to adapt is not lifetime-learning success. Probes use an outcome-specific oldworld criterion; no old identity is passed to nonoracle policy. Rawpointwise rows are included; averages do not erase individual losses.

## Strong active comparator and limits
Post-primary-run separately frozen generic active policy visits untested descriptor categories until it sees singleton membership, then exploits that category. It reaches100%final target andshift, firstquery26.5625%/23.8281%, at identical4observations. This noncrippled source-defined competitor demonstrates that useful inquiry exists without hindsight oracle. It does not confer method-discovery status: novelty-priority and informative-witness detection are researcher rules. All query costsconstant0.05; no variable-cost test. Equal observations and state descriptor capacity do not imply equal CPU/storage: historycounter keeps lists, scalarpolicy compact means, and trace overhead is not charged as learnercompute. Allsources are Python, no native integrated TNN.

## Consequential-choice ownership
Trace records every target action's prechoice policy scores, card identity/feature, witnessedreward, remainingcandidate count and owner:
- Researcher: defines desired result (unique target), anonymous descriptor categories, availablequery cards, update equations, optimism, fixed exploration probability, candidate intersection, argmax and termination horizon. The environment supplies consequences; evaluator alone chooses hidden target and checks success.
- Learner state: observed category quality changes ranking and hence selectedcard. It does NOT create categories, an update rule, investigation procedure, stopping procedure or workflow. There is no PLAN/RESEARCH/INVENT router.
- Oracle: explicitly labeled evaluator-owned actionupperbound, excluded from learned claims.

No fabricated success: unresolved episodes in exploration arms reportfinal0. Identifying world is not labeled impossible because a particular policy fails. Earlier fixed-kernel and failedquery evidence remain intact.

## Next highest-information experiment
Permit a serialized executable inquiry/credit-assignment procedure to be learnerstate, not only four qualitymeans. Freeze a generic action/evidence interpreter; let learnerproposals change what is sampled, how witnesses affect persistent structures and when to stop, with actual charged proposal/execution costs. Use distinct consequence rules requiring discrimination of redundancy versus discovery and adaptive credit, plus hidden shifts. Compare full procedure, retainedfacts/procedureerased, procedureonly/newfacts, wrongprocedure, transplant and strong full-power active competitors. The decisive bar is state-created selection/update behavior improving unseen-world acquisition under matching fuel AND preserving pointwise old capabilities. Simply adding source EWMA or exploration fixes remains researcher ownership. Learning to choose those rules from a predefined menu is also narrower than discovering procedurestructure and must be labeled.

## Red-team checkpoint alias correction, October7 20:37
Original wire() returned live arrays; earlier queued snapshots could reflect later updates. The original 5,760 transplant replay result is FLAWED for checkpoint validity and is withdrawn. Original flawed states, source and verification are preserved. Repair copies allflat arrays and eachnestedhistory at capture. Full64,512worldrun was rerun; raw.csv, retention.csv and trace.jsonl hashes are byte-identical before/after, so reported primary behavioral and pointwise numbers are unchanged. 4,608of8,064serialized snapshots changed underrepair. Independent checkpoint countcheck now finds0invalidsnapshots: cumulative observations64/80/96 atworld15/19/23, except fresh4atallcheckpoints. Corrected standalone process replay:5,760transplants,0mismatches. This corrected count replaces rather than retroactively validates the flawed claim. Redteam sourcebug was real even though replaycount stayedsame.
