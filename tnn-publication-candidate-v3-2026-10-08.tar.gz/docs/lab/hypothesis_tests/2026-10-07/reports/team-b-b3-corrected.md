# B3: adaptive organization under an ownership trace
2026-10-07, new standalone exploratory Zag experiment, not canonical TNN or a reproduction. No upstream writes. Prior negative results preserved.

## Result
All 256 consequence-table worlds pass: adaptive routing tree, flat policy and consistently renamed routing each 128/128, totaling32,768/32,768 per arm. Consequence shift makes stale policy64/128 in every world (16,384/32,768 total); full rebuilt tree recovers128/128 in every world. Constant-policy readout erasure totals16,384/32,768 by independent truth equations. Learned tree sizes vary with experience:5,9,11,13,15,17,19,21,23,27 nodes. Read raw result rows for per-world sizes. Any stronger optimizer/memory benefit is untested.

## Mechanism and ownership
Observation supplies two input/output examples per context. The learner infers which order of two affine primitive objects fits both. It recursively allocates context regions, selecting the context bit minimizing the sum of minority-label counts in child subsets, and stops when leaf consequences are uniform. Region membership, split choices and node count vary with observed outcomes. A flat store receives the exact same inferred consequences. All16 contexts are trained; only numeric inputs40..47 and macro operands change at test. This is not unseen-context generalization.

Ownership trace emits every candidate split score and selected split for the first four worlds. Evidence determines split data; researcher defines the four-bit feature basis, greedy impurity objective, tie break by bit order, stopping rule, object semantics, truth family, full rebuild after drift, and harness sequence acquisition->build->query->drift->rebuild. Learner does not decide what to investigate, how to fit, when to repair, or how to organize a workflow. This is an adaptive organization algorithm, not a learner that discovers organization cognition. Substrate remains a tree with disjoint leaves, not overlapping cross-region recruitment. It would be false to rename it a fully learned Adaptive Web.

## Controls and epistemic realism
Flat matches every prediction, so Web/tree-specific capability is KILLED on this task even though adaptive boundaries are genuinely consequence-dependent. Renaming jointly maps context bits and membership, not just labels. Shift toggles order only for bit0=1; recovery is full fresh rebuilding, not selective persistent repair. No source-level cognitive modes appear, but the harness still prescribes the workflow.

A separate witness constructs two arbitrary consequence tables agreeing on contexts0..14 but disagreeing at15. With that context unobserved, prediction is unidentifiable. It is an epistemic impossibility under unrestricted tables, not evidence against method learning. Our restricted256-table family has correlations, so this witness is explicitly not claimed as ambiguity within that family.

## Verification
Typed arrays allocate n*8 and pass duplicate72-element sentinels. Compiles succeed; two runs and a fresh compilation after binary removal produce byte-identical outputs. Independent scalar Zag scorer proves macro orders stay noncommutative for every test input and counts32,768 queries,16,384 zero-order cases and16,384 changed consequences. This verifies expected totals, not an independent implementation of greedy splitting. Frozen plan and source were sent for internal adversarial review before running. Local prereg uncommitted, no qualifying prereg-commit claim. Source/binary/output hashes and raw rows preserved.

## Verdict and next experiment
SURVIVED narrowly: observed consequences determine different useful adaptive boundary trees; intact trees transfer chosen ordering to new numeric inputs and operands. KILLED: representation-specific prediction advantage over flat information. UNRESOLVED: learner-discovered organization/update procedure, overlapping recruitment, selective structural repair, autonomous Researcher-to-Result cognition and general intelligence.

Next: retain current facts/macros/memberships, and learn an executable proposal/rewrite procedure that changes what can be constructed under a fixed proposal budget. Compare identical procedure and budgets in flat/tree/graph stores. Withhold context combinations but provide a distinguishing action, so active information acquisition can resolve real uncertainty. Do not claim an architecture win until the procedure, not merely membership data, is causally learned and transfers.
