# Team G: causal intervention selection audit
Date: October 7, 2026

## Verdict
**TNN causal-method ownership: unresolved. Reproduction: process-fail.** The experiment environment and reference controls ran, but no TNN causal chooser ran. Missing source prevents testing whether causal experiment selection is learned, rather than written by the researcher. This is not a killed capability claim. The reference results show why beating random is insufficient: a strong fixed policy tied information gain exactly.

## Repository evidence
Source: https://github.com/Sylorlabs/TNN . Fresh checkout: `27a4271f208247a1e9c24cca35468c298b6cd29d`. Local checkout was not changed; no commit, push, or upstream mutation.

Relevant packet: `docs/generations/R48/runs/R48_INTEGRATED_CAPABILITY_PACKET_20260918/`.

- `R48_RESULTS.json` reports resolved=1 over 30 worlds, mean interventions=1.2666666666666666, random mean=2.3666666666666667, random resolved=0.6333333333333333, scrambled resolved=0.03333333333333333, update-disabled resolved=0.
- `R48_RESULT.md` labels the causal result C4 / I4 experiment selection. These are archived claims, not reproduced results.
- `SOURCE_FREEZE.sha256` names `r48_packet.py` with SHA256 `a128a6f7a52929754fa14a99fb7b3e31f065161e878dfba28c8c21436ffb490d`. That file is absent from ordinary checkout files and from readable member listings of the 30 checked `.zip`, `.tar.gz` and `.tar.xz` bundles. Two bundles could not be listed (one corrupt, one empty), so absence from those is unverified. Encoded `.b64` transport fragments were not reconstructed.
- `LEARNED_STATE.json` has exactly three top-level keys: basis_counts, memory_policy, train_refs. No separately identified causal experiment policy/method is serialized there. This does not prove source ownership; it prevents demonstrating state ownership.
- `training_sources/generated_causal_worlds.jsonl` contains 40 nonce/sample_id/source_family records. No causal observations or intervention outcomes are in those records. They may be generation identifiers; without the generator they are not a training replay.
- Sample traces keep researcher-named alternatives A, B, AND, OR, XOR, NOT_A, narrow them on correlated observations, then probe `(1,0)` and `(0,1)`. Exact control logic remains unauditable without source.

## New environment and controls actually run
This is a separately written reference test, **not TNN**. File `causal_controls.py`, results `results.json`.

Six visible binary variables: two are an observationally identical pair; four are independent distractors. Three competing structural causal models are forward copy, reverse copy and latent common cause. Exact enumeration over 32 latent assignments gives identical observational joint distributions across all three models. Setting a variable breaks the copy versus latent relation, so interventions distinguish the explanations.

All 30 ordered placements of the active pair, all 3 mechanisms, 10 random-policy replicates: 900 worlds. Observation equality is asserted in every world. Variable indices vary; there is no fixed intervene-on-B. The fixed baseline discovers the correlated pair from observations, tests its first member, then its second if still ambiguous. The greedy baseline chooses the action with maximum expected information gain over the current version space.

Each non-oracle baseline receives identical candidate predictions, action menu (12 single-variable/value interventions), and cap of 2 interventions. An intervention returns an exact enumerated distribution, not a noisy single observation. This generous observation packet is explicit and identical across controls. Oracle additionally gets evaluator truth.

| Control | Resolved worlds | Accuracy* | Mean interventions |
|---|---:|---:|---:|
| Observation-only | 0/900 | 33.333% | 0 |
| Random, without repeating an action | 209/900 | 54.926% | 1.877778 |
| Greedy information gain | 900/900 | 100% | 1.666667 |
| Strong fixed, observation-derived pair | 900/900 | 100% | 1.666667 |
| Evaluator-truth oracle | 900/900 | 100% | 1.333333 |
| Irrelevant prior | 900/900 | 100% | 1.666667 |
| Misleading 99:1:1 prior favoring wrong model | 900/900 | 100% | 1.833333 |
| Facts-only, uniform candidate mass | 900/900 | 100% | 1.666667 |
| Wipe outcome state after every intervention | 0/900 | 33.333% | 2 |

*Unresolved ties are scored by expected uniform tie-breaking, not by sampled answers. Resolution means exactly one compatible model.

The first random probe targets an active variable in 323/900 worlds. Greedy and fixed target it in all 900.

Independent truth-table check resembling the archived R48 traces: A, B, AND and OR all agree on `(0,0)` and `(1,1)`. The two off-diagonal inputs identify all 4 exactly. A strong fixed two-probe policy and information gain therefore both solve 4/4; exact enumeration of uniform two distinct input probes resolves only 8/48 world/probe combinations. No R48 reproduction is implied.

## Ownership and limits
The researcher wrote every part of the reference cognitive method: candidate SCM family, intervention semantics, exact-distribution representation, compatibility filter, entropy objective, candidate predictions, stopping rule, fixed baseline, tie-breaking and budget. Mutable state contains posterior mass and accumulated outcomes, not an acquired selection algorithm. State-reset failure proves evidence matters to this hand-written solver, not that the learner invented a method. Facts-only success and its tie with greedy mean no method-transfer claim is earned.

The irrelevant-prior control is weak by design: irrelevant metadata has no role in the solver. It does not demonstrate learned relevance filtering. Misleading-prior recovery is easy with deterministic zero-likelihood exclusion; it does not establish robustness under noise. Only variable-index permutation was tested, not natural-language renaming, unseen graph families, intervention costs, hidden confounders beyond this family, or finite-sample uncertainty. R48 source ownership, mode/router absence, full-state/facts-only method transplantation and native fresh-process behavior remain untested.

## Next highest-information experiment
First obtain the source matching the archived hash and the actual causal learner state. Freeze that source. Plug only raw observations, available actions, costs and outcomes into one generic interface, with no causal mode or causal-specific action router. Use noisier observation-equivalent worlds with unequal action costs and graph-family transfer so a two-probe fixed policy is no longer sufficient.

Paired fresh evaluation must compare: full learned state, facts-only state, method-only state, no-update, state-reset, shuffled/transplanted method state, greedy-information, a tuned strong fixed policy, random, and oracle at equal observation/action/compute budgets. Require a causal-method field to survive serialization and unrelated tasks; swapping that field must change intervention choice while keeping facts fixed. This isolates ownership far better than another random-policy win.
