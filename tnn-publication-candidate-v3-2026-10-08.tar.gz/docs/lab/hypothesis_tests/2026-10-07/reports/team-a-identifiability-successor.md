# Team A successor: identifiable information before learner testing
October 7, 2026. Exploratory local diagnostic. No upstream edits.

## Finding
A new explicit observation contract removes ambiguity within a declared structural prior. Across 64 active runs, a fixed greedy-information baseline identifies a unique behavior after11 output-only queries and correctly predicts all5 never-observed inputs. This qualifies training information for a small follow-up learner test. It does not establish learner-owned inquiry, method acquisition or broad TNN capability, and is not a replacement reproduction of missing named-world drivers.

## Redesigned world
Input: four Boolean coordinates (16 inputs). Output: one Boolean consequence. Hidden target: multilinear GF(2) polynomial of degree at most2. There are11 free coefficients and2048 behaviorally different functions. Candidate space is a disclosed diagnostic prior, not an architectural claim. The evaluation target implementation is separate from the fixed inquiry selector; selector receives only candidate membership, prior observed labels, and input label mapping. It does not receive hidden coefficients. A requested input costs one observation and returns only its consequence.

Training can query any input. The active diagnostic chooses the input maximizing the smaller predicted-label partition, with deterministic label-order tie breaking. It is explicitly researcher-owned greedy information acquisition, a strong baseline rather than a learned policy. Training never accesses heldout labels except for the input it explicitly requests, and those queried points are then excluded from unseen evaluation.

## Identifiability proof
Write f(x)=b XOR SUM(ci*xi) XOR SUM(cij*xi*xj), over GF(2).
- f(0) determines b.
- f(ei) determines ci=f(ei) XOR b.
- f(ei+ej) determines cij=f(ei+ej) XOR b XOR ci XOR cj.
These are one zero, four singletons and six pair inputs:11 observations. All remaining five inputs follow uniquely under the degree-two assumption. Removing one pair observation leaves its coefficient unconstrained, so two distinct behaviors remain and disagree somewhere.

Every output-only observation supplies at most one bit about the2048 equiprobable laws, so exact uniform identification requires at least11 observations. In a surviving affine subspace, a query is either constant or divides candidates equally. The diagnostic greedily chooses a splitting query until singleton and therefore attains this11-query lower bound.

Important hostile implication: this qualified world CANNOT show query-count superiority over the strong fixed greedy baseline. Its uniform prior is already optimal, and its teaching information can be solved by a source-defined linear interpolation procedure. A purported learned inquiry advantage here would indicate a mismatched baseline, nonuniform prior, leakage or accounting error. Varying query costs alone admits a strong minimum-weight linear-basis rival; do not cripple that rival to produce a policy win.

## Frozen and executed checks
Local prereg saved before implementation; no remote commit because scope is read-only. Source scientific computation entirely in Zag. Two fresh builds and executions exit0 and match binary/output hashes. Uses only byte-slice allocation, not the typed-i32 path reported elsewhere.

32 frozen targets=(61*t+17)mod2048, t=0..31; each tested with identity input labels and consistent XOR-9 label permutation. All64 runs:
- queries11;
- classes before last witness2;
- classes after last witness1;
- never-observed inputs5;
- never-observed correct5.

Hostile control counts:
- no feedback2048;
- only x=01024;
- ten basis observations, one pair omitted2;
- full11-observation basis1;
- out-of-class cubic x0*x1*x2, all16 labels0;
- erased candidate evidence2048.

A separate straight algebraic reconstruction check covers ALL2048 coefficient codes and recovers2048/2048 exactly. It does not invoke the greedy selector or candidate enumeration. This is implementation-independent arithmetic checking by the same worker, not independent human review. It also is not a separate empirical reproduction of the64 active-policy runs.

## Verdicts and strongest alternatives
SURVIVED narrowly: training becomes behaviorally identifiable in a declared degree-two model after discriminating observations; zero/partial information behaves as predicted. Out-of-class data can falsify the prior instead of being forcibly fitted.
KILLED by analysis on THIS fixture: scope to show fewer-than11-query learner-owned policy superiority over the optimal same-information rival. Do not interpret this as architectural impossibility.
UNRESOLVED: generic learner discovers how to construct or organize executable cognition. No such learner has been implemented/tested here.
NOT AUDITED: original join-underdet, holdout-uncacheable, program-lossy exact drivers. This redesign changes their information contract conceptually, but does not pretend to reproduce them.
Strongest positive explanation: finite model fitting/interpolation inside researcher-owned polynomial prior, then caching/compiling the result. Retained-method erasure collapse could prove state use without proving learner-owned organization or changed practical generative reachability.

## Proposed learner test, after qualification
This is a design, not an executed claim. Freeze the generic primitive set, interpreter, candidate proposal process and state layout before target selection. Use generic Boolean logic/composition and byte-addressed executable structures, not an enum of2048 complete formulas, named polynomial transforms, or task-specific cognitive dispatch. The diagnostic model class may live in a separate qualification oracle; do not silently pass its candidate table, hidden coefficients or interpolation algorithm to the tested learner.

Phase1: behavior recovery.
Feed the learner the exact qualified transcripts. Require a retained executable object with correct predictions on all never-taught inputs across the32 frozen laws and input renamings. Candidate exact implementation syntax need not be unique; require behavioral equivalence. Record every failed construction attempt and total primitive execution, instruction storage and observation cost. Copying the qualification oracle into learner source disqualifies the ownership claim, even if accuracy passes.

Phase2: causal method use and strong reconstruction rival.
Compare intact object; object erased/facts kept; facts erased/object kept; sham erasure; fresh learner given the SAME entire transcript; misleading object with matched facts; and a strong facts-plus-linear-interpolation baseline. Source interpolation is permitted in the rival and disclosed, not smuggled into tested learner. Count acquisition plus all evaluation work. Predefine evaluation horizon before seeing results so caching break-even is not selected afterward. A stored object beating reconstruction only after many repeated queries is amortization, not discovery of an acquisition procedure.

Phase3: learning how to organize cognition, the actual objective.
Use an A->B sequence on larger Boolean inputs under the SAME source. A trains a reusable construction/rewrite proposal procedure. B requires a new executable body with a composition not explicitly demonstrated as a whole in A. Preserve raw A examples and existing executable objects while selectively erasing ONLY the retained construction/proposal procedure. Compare a strong flat executable store with identical primitives/data/budgets, plus fresh generic enumeration and facts-only reconstruction. The relevant causal endpoint is the cost and success of constructing B's new method, not only executing an already built A object. If there is no separately identifiable procedural carrier, the test is UNRESOLVED, not a pass.

Freeze target distribution and program-size ceilings before B. Qualified model/world assumptions must be specified; an unrestricted function remains impossible to identify from finite samples. Use conditional behavior classes instead of claiming uniqueness of arbitrary source programs. Include relevant/irrelevant/misleading procedures, renamed surfaces, a partial consequence shift and unchanged-use retention. Selective revision must change invalid applicability/internal steps while preserving known valid behavior; clear-all/rebuild is a separate baseline.

Frozen proposed fail criteria:
- no qualified target agreement after informative teaching: information-qualification fail, not architectural failure;
- any source-level complete target forms, task router, target coefficients or hidden evaluator trace entering learner: ownership/leakage fail;
- procedural erasure has no effect on B construction at equal total resources: causal procedural-learning claim killed for this implementation;
- object erasure affects only execution but not future construction: classify as executable reuse, not learned construction;
- strong flat/facts-plus-inference rival ties: organization necessity not established;
- prior resets, unused arm state, missing integrity assertion, stale/failed compile: process-fail;
- target-level transfer and selective-revision performance do not meet precommitted bars: negative for this bounded mechanism only.

Practical prereg recommendation: separate capability recovery, amortized execution efficiency, learned construction efficiency and learned inquiry into different endpoints. The current qualified fixture addresses the first two only. For learned inquiry use an expressly nonuniform structured world where adaptive query choice can matter, qualify the distinguishing-action budget first, and retain strong greedy, exact finite-horizon dynamic-programming, random, fixed and oracle rivals. No such richer inquiry experiment has been run here.

## Provenance
Official observed repository URL: https://github.com/Sylorlabs/TNN . Remote heads rechecked unchanged: lane/ownership d1ed7f15f60a3314896c2935d7057b72e55ea3bb; fast/method-identifiability6fa4fd4c7735cc12374c6f3339fa46edfb8b2a45. Historical source context in previous Team A report. Newly authored standalone PREREG.md, active.zag, independent-check.zag, raw outputs, compile logs and SHA256 ledger accompany this handoff. No repo source changes, commit, push, canonical runtime run or architecture promotion. No infrastructure specifications included.
