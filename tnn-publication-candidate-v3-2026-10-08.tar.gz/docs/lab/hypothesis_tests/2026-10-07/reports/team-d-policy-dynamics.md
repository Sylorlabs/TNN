# Proposal dynamics successor on executable repair substrate
October7,2026. New native assay continuing the edit-transformation experiment. Not canonical TNN, not integrated R2R, not L3. Exact sources/prereg/raw ownership trajectories retained.

## Result
Simple consequence counts learn a useful candidate order within a fixed91-edit grammar and recover from misleading history. Global counts outperform the more elaborate residual-conditioned organization on this deterministic sequence. Facts ledger reconstructs every count exactly, so the positive is L1 acquired parameters, not a discovered learning procedure. A two-example affine algebra rival solves every episode without search. This kills any architecture or general-learning advantage claim on this world. It does not establish impossibility outside this affine family.

Three histories over64 episodes (32 prior,32 target), three arms,576 episodes total. All finish within91 trial cap. Exact independently written scalar interpreter reproduced every native selected candidate, win flag, terminal counter and zero ledger mismatches. Cold rebuild matches native stdout byte-for-byte. No typed []i32 storage.

## Raw candidate-test means

| history | arm | prior32 | target32 | target first8 | target last8 |
|---|---|---:|---:|---:|---:|
|related append-add-double -> same|fixed|35.34375|37.5625|42|35.875|
|related|global counts|2.28125|1|1|1|
|related|residual-context counts|34.0625|30.65625|31.75|29|
|unrelated append-add-double -> reverse|fixed|35.34375|7.21875|6.625|8.875|
|unrelated|global counts|2.28125|3.65625|9.25|1.375|
|unrelated|residual-context counts|34.0625|4.9375|4.375|3.25|
|misleading reverse -> append-add-double|fixed|7.40625|37.5625|42|35.875|
|misleading|global counts|1.3125|2.8125|6.125|1.125|
|misleading|residual-context counts|6|35|42|35.875|

Counters include failed candidates, not just adoption, but omit ranking scans, copy/allocation, ledger reconstruction and total arithmetic/CPU. Evidence dose differs per failed attempt because every attempted candidate receives verifier outcomes; no claim of equal feedback-count or equal total compute. All arms share same available action grammar, same hidden worlds, same episode cap and verification oracle.

A learned global order recovers after misleading prior: first8 target6.125 tests -> last8 1.125. The residual-conditioned store fragments this helpful generality. This diagnoses one poor source-chosen context representation, not an impossibility for adaptive organization.

## Strong competitor
Independent scalar post-composition solver observes source IO at0,1 and desired IO at0,1, obtains affine slopes/intercepts, and sets post-transform alpha=c/a and beta=d-alpha*b modulo31. Full31-input check passes576/576. Every primitive in this environment is an invertible affine map, so these two consequences fully identify the required effect. That is a special mathematical degeneracy. The rival is more powerful than the restricted91-edit primitive grammar, so this is a WORLD-TRIVIALITY control, not a matched-representation timing victory. It makes broad architecture conclusions unjustified. Complete fixed91-edit search also succeeds576/576. Facts-only reconstruction exactly equals the learned-score decision process; ledger disagreement is0 after every episode.

## What was learned and who decides next
Goal supplied: repair artifact to match desired outcomes. Machine primitives: arithmetic execution and generic edits. Learner state: positive/negative consequence counts over generated edit candidates, optionally residual indexed. Learner choice: candidate selected by learned count, ties fixed index. Learner-created artifact: repaired executable tape. External consequence: full-domain correctness after candidate construction. Researcher source:91-candidate grammar, score representation, residual map, -1/+4 update, max-score selection, stopping rule, trial budget, four repair causes and affine family. It is a fixed learner with acquired score state, NOT a learner that invents its own acquisition policy. Candidate values are not available to ranker before selection, but full31-value verifier feedback is unusually generous and should be weakened in a non-affine successor.

No source-level named cognitive modes appear. Nevertheless there is a researcher-authored repair loop, so this does not meet the user's no-intermediate-workflow objective. Immutable search/update remain the primary unsolved issue.

## Scope and missing controls
Arm0 is an unlearned fixed order across all episodes, NOT reset-per-target active learning. Prereg wording 'reset arm starts empty per target' was not implemented as a learning reset arm. Do not attribute comparison to continuous-vs-fresh learning. Learned counts are never erased/permuted here; those controls remain needed for a stronger causal proposal-policy study. Global-vs-context differs information partitioning, not substrate identity. This assay has two task laws and no broad heterogeneous world suite. No learned applicability gate, no persistent task/goal discovery, no source-independent high-level order, no neural competitor, no independent red-team replication yet.

Next successor should reject this affine degeneracy before learning: anonymous nonlinear primitives with hidden consequence laws, partial affordable tests, genuine hypothesis ambiguity and available active witnesses. Need same frozen mechanism across mixed direct/experiment/repair goals, discovered applicability rather than a residual table prescribed by us. Integrative ownership audit must precede merging this local mechanism.
