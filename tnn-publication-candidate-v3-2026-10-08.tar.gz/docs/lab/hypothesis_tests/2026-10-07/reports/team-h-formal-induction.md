# TEAM H — P6 LIMITS: structural induction, exact membership, representation transfer

Date 2026-10-07. Read-only research slice. Repo: https://github.com/Sylorlabs/TNN
(fresh checkout; no upstream writes, no commits, no pushes). Branches read:
main 27a4271f, lane/ownership d1ed7f15, fast/method-identifiability 6fa4fd4c.
Toolchain: vendored znc_linux_x86_64_abed8aa1 (src/tools/toolchain/). All runs
compile-gated (rm -f first), 3/3 byte-identical stdout. House zbuild.sh/lane.sh
not used (macOS-hardcoded paths); equivalent determinism checks done in bash.
No claim IDs minted (ledger untouched). Everything local: /home/sandbox/teamh-work/th/.

Read in full before designing: p6struct/PREREG+REPORT, fast_membership_order/
PREREG+REPORT, p6_formal_induce/PREREG+REPORT+amendments, FRONTIER_QUEUE.md,
docs/ops/ZAG_LANGUAGE_AND_WORKER_BRIEF.md.

## COLD REPRODUCTIONS (before any new work)
- p6struct/original_precond.zag: fresh compile, output BYTE-IDENTICAL to committed
  original_run.txt (340 tested, 3 derivable).
- fast_membership_order/probe.zag: BYTE-IDENTICAL to committed run1.txt (greedy
  matcher defect signature reproduced: order0 root_FN=1 union_FN=1; order1 root_FN=1).
Both existing artifacts reproduce cold on an independent (Linux x86_64) host.

## H1 — SCORER QUALIFICATION (attacks queue item P6-scorer-qualification, OPEN)
Mechanism: memoized endpoint-set (chart) matcher (exact for epsilon-free,
unit-cycle-free tables) + independent BFS bounded generator as second algorithm;
every cell checked against hand-derived expected sets frozen in PREREG.md.
Raw numbers (th_scorer, all cells chart vs greedy legacy):
- FX1 original fixture: chart root_acc=1 union_acc=3 exp_mm=0 gen_mm=0 (340 strings); greedy agrees here (fixture cannot expose the defect).
- FX2 audit fixture, 4 cells (2 alternative orders x 2 terminal renamings):
  chart root_acc=2 union_acc=3, exp_mm=0 un_mm=0 gen_mm=0 in EVERY cell.
  Greedy in same binary: root_acc=1 union_acc=2 (order0) / root_acc=1 union_acc=3
  (order1), exp_mm=1 — the audit's order-dependence reproduced and repaired.
- FX3 true recursion S->pSq|pq: chart 3/5460 accepted exactly {pq,ppqq,pppqqq},
  renamed cell identical; gen==chart on all 5460.
- FX4 composition S->AB, A/B recursive: exactly {pqrs,ppqqrs,pqrrss} = 3/5460, gen==chart.
- FX0 empty table: 0 accepted (S4-style ablation sane).
VERDICT H1: SCORER QUALIFIED. Forward generation and backward acceptance from ONE
table, order-invariant and rename-invariant, with two independent algorithms agreeing
on every swept string. This removes the queue's blocker for general induction verdicts.

## H2 — INDUCTION LIMITS (th_induce; world W1 nested wrappers, truth = stack parser
independent of the chart matcher; corpus: 4 same-pair valids depth<=2 + 92 near-miss
invalids; cross-pair compositions and all depth>=3 strings NEVER shown)
- LEARN induces exactly: A0 -> x1 y1 | x2 y2 | x1 A0 y1 | x2 A0 y2 (2 base + 2
  RECURSIVE productions, contents fully corpus-derived; fit 4/4).
- Sweep <=7 over the 6-token inventory (335,922 strings): LEARN acc=14 fp=0 fn=0;
  generation-vs-acceptance mismatches 0. Oracle cross-check chart(true grammar) vs
  stack-truth: fp=0 fn=0.
- RECURSION BEYOND TRAINING DEPTH: depth-3 unseen-valid 8/8, depth-4 16/16.
  MEMO (facts-only) 0/8 and 0/16.
- COMPOSITION: cross-pair <=depth3 (never in corpus): LEARN 8/8.
- UNSEEN INVALID: 240/240 near-miss depth-3 invalids rejected.
- GENERATION: BFS <=8 yields exactly 30 strings, 0 truth-invalid, 26 unseen-valid;
  MEMO generates its 4 stored; RAW 20000 uniform proposals -> 0 distinct unseen-valid.
- ABLATIONS: ABL-NOREC acc=2 (depth-1 only, fp=0); ABL-ALL acc=0; erasing the
  recursive productions destroys exactly the depth>1 capability, nothing else.
- MISLEADING PRIOR: seeding A0 -> y1 A0 x1 survives near-miss negative-consistency
  (its bad products are not near-misses of the corpus): fp=12 on sweep. A generic
  load-bearing prune (drop any production no valid training string depends on)
  removes it: PRIOR-BAD-FILTERED fp=0 fn=0, final table identical to LEARN.
- RENAMING: full metric vector identical across independent token re-derivations
  (seeds 1009 vs 2027): SIG lines byte-equal.
VERDICT H2: ALL FROZEN BARS MET. Bounded structural induction survives every
Team H attack inside this family: depth transfer, fwd/bwd consistency, unseen
valid generation, unseen invalid rejection, renaming, composition.

## H3 — ONE LEARNER-OWNED STRUCTURE ACROSS TWO ENCODINGS (th_transfer)
Substrate-vs-learner separation measured explicitly (user steering 2026-10-07):
- W2 = bijective token re-encoding of W1. Discovered map (position-wise alignment
  of the two minimal valids + byte-order leftovers; contents learner-owned, the
  ALIGNMENT PROTOCOL researcher-owned): W1 table + map on W2 sweep <=6:
  acc=14 fp=0 fn=0. Correct acceptances at len 4/6 (12/14) are beyond the discovery
  evidence — depth generalization comes from the learner-owned structure.
  Controls: wrong map fp=14 fn=14; random deranged map fp=14 fn=14;
  facts-only memorizer on the same W2 corpus acc=4 fn=10.
- W3 = suffix-wrapping (post-order) re-encoding, same trees, regular surface.
  W1 table + best discovered map: only 2/14 correct (fp=12 fn=12). DIRECT
  STRUCTURE TRANSFER FAILS: the induced table is encoding-bound.
  The SAME generic induction procedure re-run on a W3 corpus recovers W3 exactly
  (right-recursive rules; sweep fp=0 fn=0).
- Prereg amendment H3-1 disclosed: original bar "W3 direct acc==2" miscounted
  incidental overlaps (mapped W1-valid len>=4 strings are W3-invalid);
  amended bars fp=12/fn=12/correct=2 measured as amended.
VERDICT H3: SPLIT. "One learner-owned structure across differently encoded worlds
without a family switch" SURVIVES only for symbol-bijective re-encodings (via a
learner-discovered map whose contents are load-bearing: every map corruption arm
collapses). It is KILLED for structural re-encodings: what crosses that boundary
is the researcher-owned induction procedure, not the learner-owned representation.
This pins exactly what must move into learner state next: a learned transducer
between encodings.

## SOURCE OWNERSHIP (what the researcher still defines)
The chart matcher, BFS generator, wrap-induction procedure (base-alternative +
embedding/right-recursive splits + negative-consistency + load-bearing prune),
the world family and corpus construction, the map-alignment protocol, the consult
policy (W4 remains researcher-owned, exactly as p6_formal_induce pre-committed),
and all evaluation oracles. Learner-owned: production table CONTENTS (H2/H3) and
symbol-map CONTENTS (H3). No source constant equals any induced production; tables
reconstructible from the corpora (auditable in the run logs).

## FAILURE ANALYSIS / HONEST BOUNDARIES
- Instrument defect found and disclosed: truth_w1 first admitted inner forests
  (full Dyck-2) while the preregistered language is single-root nesting; caught by
  the chart-vs-stack oracle cross-check (fn=8), fixed, everything rerun. Follows
  the lane's standing rule: independent checks catch instruments.
- The nested-wrapper family is near the simplest recursive family; the wrap inducer
  is well matched to it. No claim beyond this family. Architectural-impossibility
  conclusions are NOT licensed by any failure here (per user steering).
- Supervision is near-miss-only negatives; PRIOR-BAD shows a misleading production
  whose badness is invisible to near-misses survives negative-consistency and is
  only removed by the load-bearing prune. A bad prior that IS load-bearing for some
  valid string would survive both guards — untested, stated as an open hole.
- Map discovery is thin (works because both encodings share unit arity/position
  signature). Richer misalignment breaks it — by design of the successor test.
- Sibling audit (2026-10-07) found this compiler indexes []i32 with 8-byte stride;
  all Team H state is []u8 arenas with byte-level get32/set32, so that defect does
  not apply, but no typed-i32 integrity test was run here.
- Same model wrote experiments and checks; no independent human review.

## VERDICTS (per Team H charter questions)
1. Recursive rules beyond training depth: SURVIVED (bounded, exact).
2. Consistent forward generation + backward acceptance from one table: SURVIVED
   (after scorer repair; the legacy greedy matcher FAILED this and is now qualified out).
3. Unseen valid generation: SURVIVED (26/26 within bound, 0 invalid).
4. Unseen invalid rejection: SURVIVED (240/240 near-miss; sweep fp=0).
5. Renaming robustness: SURVIVED (pipeline-invariant).
6. Composition of acquired productions: SURVIVED (8/8 never-shown compositions).
7. One structure across differently encoded worlds: SPLIT — bijective SURVIVED,
   structural re-encoding KILLED; procedure (researcher-owned) is what transfers.

## SUCCESSOR (highest information first)
1. Learned transducer between structurally different encodings (the exact gap H3
   pinned): learner acquires a serialization map W1<->W3 from paired experience;
   kill bar: no researcher-authored alignment rule, transfer must survive a
   load-bearing-prune and a misleading-prior seed.
2. Port the qualified scorer + wrap induction onto p6_formal_induce's FL7 staged
   ladder (typing/scope/global modular constraint, seeds 1009/2027 frozen there):
   the real target where the learner was never finished; run ZD-1/2/3 as frozen.
3. Adversarial-prior hole: seed a misleading production that IS load-bearing for a
   valid training string; neither current guard convicts it. Measure, then design
   the guard that does (or prove none exists under near-miss supervision).
