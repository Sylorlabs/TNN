# Team B: minimal Adaptive Web substrate
Date: 2026-10-07

## Answer
A dynamically constructed overlapping nested organization can carry useful acquired offsets into unseen inputs. Erasing its membership destroys its own query path. That does not establish a Web-specific capability: an equal-information flat table and facts-only reconstruction both answer every heldout query, using fewer counted query operations. The Web-specific advantage is KILLED on this narrow additive task. The wider Adaptive Web hypothesis, learner-owned invention, and canonical integrated TNN remain UNRESOLVED.

## Frozen question and mechanism
24 opaque labels, three observation views, two examples (x=2,5) for each pair. Heldout inputs 40..47 are never demonstrated. All arms infer an additive offset y-x from the same examples and require both examples to agree. Teacher: offset=(5*label+3*view)%7.

A generic expression store contains leaf structures and union structures referencing earlier structures. Consequence-equivalent leaves are dynamically recruited into regions. The same leaf belongs to regions in three views, producing overlapping membership; unions contain unions, producing nesting. No cognitive folder types or domain-mode dispatch exist. Region construction operates on already constructed structures. This is researcher-written structural construction, not an experience-acquired executable construction policy.

## Raw outputs
| Arm | Correct / total | Counted query operations | Live expression nodes |
|---|---:|---:|---:|
| Web | 576/576 | 22,896 | 75 |
| Erase regions, keep training evidence | 0/576 | 0 | 75 allocated, roots erased |
| Consistent identity rename | 576/576 | 22,896 | 75 |
| Membership scramble | 0/576 | 22,896 | 75 |
| Recombine all regions in each view | 0/576 | 113,736 | 93 |
| Misleading prior after consequence shift | 528/576 | 22,896 | 75 |
| Rebuild after new consequence evidence | 576/576 | 22,896 | 75 |
| Flat indexed | 576/576 | 576 | 75 in shared fixture |
| Facts-only reconstruction | 576/576 | 2,304 | 75 in shared fixture |

Changed consequence: increment offset modulo seven for six label/view pairs, each with eight heldout inputs, so exactly 48 of 576 old predictions must become wrong. A separate scalar Zag scorer independently obtains 528 unchanged, 48 changed, and zero membership-scramble-equivalent predictions. It checks teacher expectations, not the complete Web evaluator.

All arms use the same training opportunities, arrays, and task count. The baseline arms deliberately retain the fixture's unnecessary Web allocations so they have no privileged extra storage or information. They do not need those nodes. Operation counters are not matched total execution budgets: membership inspections, flat reads, and facts-only reconstruction have different costs. No runtime, total-compute superiority, memory superiority, or asymptotic claim is supported.

## Controls and reproduction
The consistent rename uses (7*label+5)%24, a bijection. This preserves membership rather than scrambling it. Membership scramble shifts labels by one while keeping consequence attachments unchanged. Recombination destroys unique consequence association; the evaluator abstains if more than one region matches. Misleading prior is genuinely wrong on 48 queries. Repair consists of two new examples per pair and researcher-written regrouping, not learned selective repair.

Corrected binary runs three times byte-identically; removing the binary, recompiling from source, and rerunning also gives byte-identical output. Source, binary, preregistration, output, scorer, and scorer-output SHA-256 hashes are preserved in hashes.sha256. The preregistration was saved before implementation but NOT committed; upstream write target remains unresolved. Consequently this is an exploratory local experiment, not a fully qualifying preregistered-commit result.

The first versions compiled but failed at runtime (segmentation fault or bounds panic). A standalone typed-array fixture using n*4 allocation showed 13 reread mismatches; changing to conservative n*8 allocation removed them. The corrected fixture uses n*8 plus packed state and iterative membership evaluation. Initial outputs are VOID / PROCESS-FAIL and preserved. Exact compiler/ABI cause is unresolved; no stale binaries were used after a failed compile.

## Source ownership and failure analysis
Researcher still defines additive hypothesis class, grouping by measured offset, view addresses, union construction and traversal, truth function, validity test, query ambiguity behavior, and consequence-triggered rebuilding. The learner changes memberships and structure allocation, not the evaluator, constructor, repair policy, or possibility space. A task-specific constructor is still task-specific even if its data structures lack folder names.

Erase proves installed organization is used by the installed Web query path. It cannot prove necessity beyond that path. Facts-only reconstruction passes, falsifying the stronger claim that facts cannot recover the same behavior. Flat indexed storage passes and is the simplest sufficient representation. These controls prevent a misleading conclusion from the impressive-looking erase collapse.

Fresh learner/irrelevant-prior lifetime arms were not implemented. Graph, tape, and sparse associative competitors were not implemented by this slice; Team C owns broader competition. No invented-method, genuine learning-to-learn, active inquiry, nonadditive transfer, or integrated TNN execution occurred.

## Repository context
Source inspected from https://github.com/Sylorlabs/TNN, ownership commit d1ed7f15f60a3314896c2935d7057b72e55ea3bb and method-identifiability commit 6fa4fd4c7735cc12374c6f3339fa46edfb8b2a45. ADAPTIVE_WORKSPACE_FINDINGS.md at the latter explicitly distinguishes representable-but-inert hand-built nesting and experience-built macro reuse; it reports a flat executable library tying the learned-object result. Our test is a new standalone exploration, not a reproduction of those historical claims.

## Architectural implication and successor
On this task, regions are an alternative index over learned facts. No reason to prefer Web organization over a flat table, and no L3 increment.

Next highest-information experiment: use generic leaf/union/rewrite primitives with an equal proposal and instruction budget in every substrate; train the proposal/rewrite structures from consequences, then require unseen nonadditive compositions. Erase only learned construction policy while retaining all examples, macro objects, and memberships; test whether future construction gets worse. A flat store must receive the identical executable library and search policy. This isolates learner-owned generation from mere lookup topology. Freeze the evaluator and independent scorer before running.
