# Section 5: architectural transplantation and compression
2026-10-07

## Answer
Replay-preserving instruction deletion is a useful, causally demonstrated compression principle in one existing TNN experimental interpreter. It removes five instructions and reduces revision search compared with selection-only parsimony. It does not beat the simpler original on acquisition cost or accuracy, and it remains dependent on researcher-authored successful bodies in the tested budget. Content-dependent learned affinity loses to counting on the tested fixture. None of these results establishes L3, an integrated common TNN substrate, or a transplant of all nine families.

## Scope and provenance
Fresh local clone; no upstream commits, pushes, issue changes, or queue edits. Inspected current ownership and fast/method-identifiability heads. Sources/binaries were freshly built with the repository's vendored compiler; build failures would have blocked execution. Original pp and s9 outputs match their archived hashes exactly in three runs each. Changes below are local, pure-Zag, one-factor exploratory interventions. A written local plan precedes each intervention, but no preregistration was committed. No independent hostile implementation or qualifying matched-resource battery was completed. Do not promote generated verdict strings.

## Raw evidence
All pp arms receive the same environment RNG seed and 700 episodes. Relevant late pre/post N3 tests have 19/23 examples. Trials are adopted-search counts, not total cost; failed searches can report zero. Replay calls include repeated offline scoring and are not VM step counts.

| Variant / arm | Pre N3 | Post N3 | Final instructions | Create trials | Revise trials | Replay calls |
|---|---:|---:|---:|---:|---:|---:|
| Original pp full |19/19|22/23|6|212|188|446|
| Original pp selection-only |19/19|23/23|10|212|368|593|
| Original pp no pressure |19/19|23/23|11|92|68|173|
| Full with compressor deleted |19/19|23/23|10|212|368|not instrumented|
| Full with immediate first-passer stop |19/19|23/23|6|92|236|377|
| Selection-only with immediate stop |19/19|23/23|11|92|68|173|
| Full with whole-body graft disabled |0/19|0/23|0|0*|0*|978|
| Selection-only with graft disabled |0/19|0/23|0|0*|0*|978|
| No pressure with graft disabled |0/19|0/23|0|0*|0*|978|
| Full without graded partial credit |19/19|23/23|6|176|308|530|
| Selection-only without graded credit |19/19|0/23|10|176|0*|917|
| No pressure without graded credit |19/19|23/23|11|56|128|557|

*Zero denotes no adoption, not zero effort. This is a measurement-reporting hazard.

s9 exact replication: TYPE 0/4; success frequency 4/4; learned affinity 1/4; held-out repurposing bar false. One increment program, composed with itself, solves all cases. Thus affinity's advantage over frequency is killed on this fixture; repurposing is void because the world never requires it. This does not falsify content routing as a family.

## Causal interpretation and failures
- Greedy compression is causal: deleting only its function body takes full from 6 to 10 instructions and 188 to 368 revision trials, matching selection-only. Live post accuracy rises from 22/23 to 23/23, so there is no accuracy gain.
- Extra ten-generation refinement is not necessary for six instructions here: early-stop full still reaches six, but revision becomes 236 rather than 188 trials. The archived revision-cheaper-than-creation claim fails in this control (236 > 92).
- Removing graded partial success does not kill full compression's solution, but makes revision more expensive. Removing whole-body graft kills all arms under the tested search opportunities. Policy seeding from successful innate bodies remains in this graft ablation, so the result specifically implicates whole-body transplant rather than removing all prior information.
- Matching episode count is not matching computation: 446 vs 173 replay calls, and compression trials were omitted from the archived search-trial headline. Total executed VM work and memory accounting still need instrumentation.
- The six-instruction result performs SET relation, MATCH outgoing edge, SET field, READF value, SET answered status, YIELD value. This manually explains correctness on the fixture's one-edge N3 world. It is a relation-immediate edit plus dead-code removal of the gather scaffold, not demonstrated invention of a new method family.
- A byte-different body is insufficient novelty. A source-supplied gather body already encodes the useful wiring; the graft operator copies it.
- The hand program is frozen with pre-shift relation 5 and is never allowed to update. Its post-shift loss cannot establish an advantage against a strong adaptive hand-program rival.
- All exploratory interventions use one RNG seed. Three byte-identical reruns demonstrate determinism, not independent samples or statistical power.

## Ownership and scaffolding audit
Counting scope: executable learner interpreter and constructor in pp.zag, excluding world generation, printing and experimental arm switches. Counts are structural, not a proof of genericity.

| Category | Count / finding |
|---|---|
| Interpreter opcodes | 8: SET/COPY/ADD/EQ/JNZ/MATCH/READF/YIELD |
| Innate complete executable bodies | 5: gather, follow, complete, predict, shift |
| Additional hand comparator | 1 complete six-instruction N3 solution, replay-only |
| Named evolutionary operators | 8: slot mutation, targeted mutation, append, insert, delete, crossover, whole-body graft, experience crossover |
| Named source-level cognitive-mode dispatcher | 0 in inspected interpreter |
| Permanent role-to-role bridge | 0 explicit bridges in inspected interpreter |
| Latent fixed-form menus | Unexecuted menu_adopt/menu_trigger and enum-search helpers remain in source; active arm reports zero enum events |
| Context/role scaffolding | Fixed applicability/composition matrices, context buckets, fixed slot-5 create/revise path, 5 innate bodies, constructor/revision thresholds and phase gate |
| Compression scaffold | Fixed post-adopt three-pass deletion routine and replay-nondecrease acceptance |
| Other researcher choices | graded reward tiers, immediate-frequency bias, population 8, offspring 12, length cap 16, mutation schedule, PLEN=3, ten-generation extension, fixed shift/test timing |

'Zero modes' is not 'zero supplied cognition'. The learner changes body bytes, policy counts, retained variants and accepted deletions; it does not invent the interpreter, selector, operators, replay objective, scaffolds, or acquisition procedure. Compression deletes instructions in a program, not researcher-owned source machinery. No source-level scaffolding-removal success is established.

## Nine principles, minimal proposed transplantation and falsifier
These are recommendations grounded in the cited literature, not measured TNN positives.

| Family | Isolated principle | Common-substrate form to test | What must be removed / strongest cheap falsifier |
|---|---|---|---|
| Local plasticity | Update from local activity and consequence/residual | Weighted relation records with eligibility traces | No separate plasticity module; freeze only learned updates and compare to count table at equal work |
| Attractor dynamics | Recurrent associative settling | Same records iterated with a declared convergence objective | No separate Hopfield role; compare one-step attention/nearest-neighbor and iteration-matched baseline; count all settling work |
| Content routing | Input-dependent recruitment | Learned affinities on executable records | Remove domain IDs, router manager and family labels; strong frequency/flat index controls; s9 already fails the frequency test |
| Sparse distributed computation | Select only a small active subset | Generic worklist/top-k on the same records | Remove role partitions; compare equal active-work dense and flat-index rivals; report routing/index cost and starvation |
| Graph rewriting | Local match-replace of structure | Executable replacement objects stored as ordinary records | Remove bespoke rewrite engine/semantic rules; compare equivalent tape edits and permute node IDs |
| Program synthesis | Learned abstractions change reachable search under budget | Reusable executable macros plus learned proposal weights | Remove complete successful innate bodies; compare facts-only retaining identical search operations; whole-body-graft removal currently kills pp |
| Evolutionary structural search | Consequence-based variant retention including neutral moves | Same executable objects edited by generic operations | Remove task-targeted schedules and role seeds; equal replay/VM-work random, enumerative and adaptive-hand rivals |
| Active inference | Act to reduce decision-relevant uncertainty | Belief/prediction records plus action consequences | No CAUSAL_MODE; random, greedy information and strong fixed-policy controls; prove observations alone cannot identify the answer |
| Predictive-error adaptation | Revision driven by residual, locally attributed | Residual stored beside predictions and dependencies | Remove answer-proximity graded oracle and task repair probes; compare selective repair vs clear-all and invalidation-only |

Modern Hopfield/attention equivalence warns against double-counting two named modules as two capabilities. Predictive-coding graphs support common local updates on multiple topologies, but their reported topology is still an architectural choice. DreamCoder is the closest source principle for changing practical generative reachability through learned program abstractions; it is not evidence that a transplanted TNN implementation inherits its result. No literature headline numbers are used as TNN measurements.

## Verdict
- Replay-preserving instruction deletion: SURVIVED narrow causal replication for size and revision effort relative to selection-only, not superiority over the simpler original.
- Resource-efficiency win versus the original: KILLED on this fixture at the measured search/replay-call level.
- Freedom from whole-body scaffold: KILLED under the tested budget; family-level conclusion unresolved.
- Learned affinity beats counting: KILLED on s9; repurposing VOID.
- Learner-owned method invention / L3, integrated nine-family transplant, source-scaffolding deletion: UNRESOLVED.
- Scientific qualification: UNRESOLVED, not a qualifying result. Missing committed prereg, independent scorer, renaming/permutation, state-erasure, misleading-prior/facts-only, unseen representation transfer, multiple seeds and matched-total-work controls.

## Next highest-information experiment
Use the existing eight-op interpreter, one persistent state and one fixed implementation across several hidden randomized relation-chain worlds. Prove an oracle program is reachable before search. Eliminate the five complete innate bodies, permit only generic record edits and reusable learned program objects. Give equal observations, storage and executed-op budgets to full learned macros, erased macros retaining all facts, irrelevant/misleading macros, facts-only with identical fresh synthesis, adaptive six-instruction baseline, and strong enumerative/random search. Add two-edge chains and compositions that cannot be solved by changing one relation immediate. Randomize node IDs, relation labels and register names; invalidation should preserve still-valid uses. Remove any standalone compressor and store deletion/rewrite procedures as executable objects in the same substrate. Require a transferred macro to reduce total future construction work, collapse under its selective erasure, and be revised rather than globally cleared. If the flat/indexed rival ties, credit learned executable reuse rather than Web topology. Freeze falsifiers before implementation and use a separately implemented scorer.

Sources: see accompanying sources.md for ten observed URLs and scope of page inspection.
