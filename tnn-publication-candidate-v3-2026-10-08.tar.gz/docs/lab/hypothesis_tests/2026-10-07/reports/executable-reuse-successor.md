# Scaffold-free executable reuse successor
2026-10-07

## Verdict
SURVIVED narrowly: an acquired two-instruction path program, transplanted after complete erasure of its original graph facts, reduces edge-reading search work to construct the repeated four-hop composition. KILLED for a general acquisition-speed benefit: unrelated tasks cost more than strong facts-only synthesis. No Web-specific advantage: flattened identical macro ties pointwise. UNRESOLVED for equal-total-compute advantage and learner-discovered organization of cognition; this harness fixes proposal ordering, macro recruitment and synthesis machinery in researcher source.

Standalone exploratory pure-Zag experiment, not an existing integrated TNN reproduction. No upstream changes. Local written prereg precedes implementation, but no committed prereg or independent hostile implementation. An independent backward-recurrence scorer lives in the same binary: internal alternate scoring, not independent-agent confirmation.

## Mechanism and worlds
The only primitive executor is FOLLOW a relation in a directed graph. No innate multi-op programs. A generic enumerative learner builds the shortest path program from five IO examples. Across 64 seeds A has a unique two-instruction solution among all two-hop paths; shorter candidates are checked by learner before adoption. A's complete graph/examples are overwritten after learning, leaving only two serialized integers. Related B repeats the acquired path twice in fresh random graphs. Unrelated C uses a fresh four-hop path. Relabeled B consistently permutes nodes and rotates relations; all arms receive the same explicit translation. Translation discovery is not claimed.

Each task has five training graphs and twelve held-out graphs, 23 nodes, four relation labels. All learners have the same depth cap four and edge-query cap 12000. Original facts-only and erased-macro arms share target examples exactly. Wrong and reversed macros do not prevent primitives from being used. The expanded/flattened macro arm changes no order or bytes, testing representation rather than a separate algorithm.

## Measurements
All arms get 768/768 heldout correct for each task (64 x 12). Zero candidate/truth mismatches against backward recurrence across 2304 arm rows. Three independent cold compilations after binary deletion produce identical binary and output hashes; these are determinism checks, not extra seeds.

Mean A acquisition cost: 29.9375 edge reads. Table reports target search edge reads only.

| Arm | Related B | Unrelated C | Relabeled B |
|---|---:|---:|---:|
| Learned macro |26.5781|819.9844|26.8281|
| Facts-only / erased macro |797.5781|760.7500|723.1875|
| Strong lazy prefix DFS |337.6406|327.6094|311.7500|
| Wrong macro |1031.7344|883.6563|957.9531|
| Reversed macro |228.9688|839.4063|696.0000|
| Irrelevant macro |794.2031|886.5000|671.0938|
| Flattened same macro |26.5781|819.9844|26.8281|
| Raw-label unchanged macro |26.5781|819.9844|677.4219|
| Full path intersection |1700|1700|1700|
| Five-example prefix DFS |1394.3750|1328.0469|1275.6250|
| Oracle truth |0 search|0 search|0 search|

Macro vs strongest measured rival, paired mean difference and SE over seed:
- Related: -311.0625 +/- 15.3223 SE, 64 wins, 0 ties/losses.
- Unrelated: +492.3750 +/- 44.8042 SE, 11 wins, 53 losses.
- Relabeled: -284.9219 +/- 17.3018 SE, 64 wins, 0 ties/losses.
These are seed-design summaries, not a population-general theorem. A+B macro lifetime cost is 56.5156 edge reads versus fresh B-only strong rival 337.6406. If both learn A too, add their actual A costs; do not blindly add macro's A cost to every baseline and call lifetime matched. Summary file's meanAplusWork is common A acquisition plus target, descriptive rather than qualification.

## Causal interpretation
Selective macro erasure preserves target facts but removes work benefit; fact erasure before target does not remove it. Program bytes thus carry useful reusable executable information, not cached graph answers. A composition unavailable as an innate complete form is constructed from reusable pieces. However, researcher source explicitly installs the macro as first token in the enumeration alphabet. The learner discovers operand bytes, not when or how to make macros, recruit them or revise the acquisition strategy. The task intentionally makes B the repetition of A, so prior relevance is strong by world design. Unrelated tasks reveal the cost of this fixed proposal bias. Wrong and shuffled priors remain correct but costly, not selectively repaired.

Erasure removes advantage relative to the same learner; the stronger prefix-sharing baseline improves fresh search substantially. Renaming with supplied mapping supports interpreter equivariance, not representation discovery. Reversed macro can coincide with original when operands equal; it is not a universally destructive shuffle and should not be described as one.

## Ownership and compression counts
One generic FOLLOW primitive; zero source-level cognitive/domain mode dispatch in learner; zero innate complete multi-op bodies; zero named role-to-role bridges; finite depth-four candidate space made by composing four relation operands plus one acquired macro. The two-op program is experience-owned, but grammar, alphabet, search depth/order, macro-first recruitment, IO objective, fuel and serialization are source-owned. Researcher scenario switches exist only in the world harness (related/unrelated/renamed), not learner dispatch. No learned rewrite or update procedure. No compression pass, router, or special two-hop solver in learner. Separate strong reference solvers are benchmark arms, not permanently grafted learner modules.

## Remaining gaps
Equal edge cap and example budgets are not equal total computational work: decoding, allocations, comparisons, enumeration, DFS recursion, uniqueness checking and alternate scoring have unequal costs. Uniqueness audit and independent scoring are outside learner cost. No source/binary step instrumentation or wall-time qualification, no selective repair, no recursive-depth generalization beyond cap four, no retained lifetime improvements, no correspondence learning, no integrated TNN kernel. Thus the requested equal-total-work criterion remains unresolved, not silently satisfied. This should be attacked by a hostile worker before any major promotion.

## Next experiment
Replace fixed macro-first alphabet with a serialized learned proposal program and frozen generic executor. Same facts and macro objects for every arm; erase only proposal program; allow strong lazy prefix synthesis and adaptive recruitment to compete under an instruction-counted VM including decoding and validation. Include related/unrelated/misleading mixtures with costs; require learned policy to reduce unnecessary macro attempts, preserve useful macro composition, and selectively revise invalid relations. Prove learnability and oracle reachability before results. Do not add a permanent 'reuse mode'.

## Process evidence
All storage is byte arrays with explicit get/put32, avoiding typed-i32 allocation assumptions. 256-value byte roundtrip integrity test passes. Output SHA256 9a1a8cf3b1b4746768761a30edd5d750b651657245d50803727aa94d040056d1. Binary SHA256 b6966c1491e7b42f5773d78c1b7a4575f358b5d415127eb49894a876900176e1. Original codebase/compiler provenance: https://github.com/Sylorlabs/TNN . Raw CSV, full local source, all negative arms and compile logs accompany report.
