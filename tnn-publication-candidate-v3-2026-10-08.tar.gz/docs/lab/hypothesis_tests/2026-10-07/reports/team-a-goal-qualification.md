# Team A: identify the requested result, not necessarily the whole world
October7,2026. New goal-relative information diagnostic, not TNN or named-world reproduction.

## Result
A Researcher-to-Result benchmark can be information-sufficient for a requested output even while the hidden system remains ambiguous. In the existing degree-two Boolean diagnostic,7 well-chosen non-goal observations certify the requested output while16 distinct laws remain. Identifying the entire law would require11 observations. Conversely, if available actions expose only an uninformative half of the domain, even exhaustive permitted inquiry leaves the requested output split8/8. The appropriate result then is uncertainty or asking for new access, not fabricated success.

This is a qualified WORLD CONTRACT and fixed baseline. No adaptive learner or integrated TNN capability was run. Every consequential next-step choice here is researcher-authored and disclosed.

## World and exact finite proof
Prior: all2048 multilinear degree<=2 GF(2) polynomials on four Boolean inputs. Goal: return f(q). Observation action: choose x!=q and receive f(x). Direct reading of the requested output is forbidden, otherwise task degenerates to one lookup. A degree-two model prior is researcher-supplied diagnostic scaffolding, not learner-acquired representation.

Represent each input x by its11 constant/linear/pair monomial evaluation bits. A goal is identified from noiseless labels iff its evaluation row belongs to the span of observed rows. If not, some nonzero coefficient difference annihilates every observed row while changing the goal. Thus two training-consistent worlds disagree at the goal, and exact certification is impossible without extra assumptions/actions.

Exhaustively enumerated16 goals x32768 subsets of their15 allowed query inputs. Every goal:
- minimum sufficient observations7;
- exactly15 distinct minimal seven-input witness sets;
- each minimal set rank7;
- remaining laws16;
- requested output unanimous.
For one chosen witness per goal, a six-query prefix leaves32 laws, goal outputs split16/16. This is an exact bounded computational proof over the declared class; it is not an unrestricted program-learnability theorem.

Independent algebraic route: an affine three-dimensional hyperplane has8 points. Summing any degree<=2 polynomial over those points in GF(2) gives0, because every monomial restricted to three coordinates has degree<=2 and even parity across the cube. Therefore querying the seven other points in a hyperplane containing q recovers f(q) by XOR. There are15 nonzero hyperplane normals, each defines one containing q, yielding15 such witness sets. The exhaustive rank proof establishes there are no smaller witness sets or extra seven-point sets.

A second Zag implementation independently checks491520 identities (16goals x15normals x2048laws), with0 failures. It uses direct separate polynomial evaluation rather than the first implementation's row-rank reduction.

## Action availability and calibration negative
If the goal is f(0) but available queries are only x=8..15, all8 answers leave16 laws consistent with target37, goal split8/8. Asking more queries within that same set cannot help. Algebraically, adding1 XOR x3 to any candidate leaves all permitted outputs unchanged and flips f(0), so this ambiguity is genuine. Return 'not identified from permitted observations' or request an action exposing the missing distinction. Failure to guess the hidden bit is not a learning failure.

Under a uniform posterior on the declared noiseless version space, six-query goal confidence is exactly1/2. Following a sufficient seven-set, confidence is1. These are oracle/model-relative values, not learned calibration or robustness to model misspecification. Prior active-diagnostic cubic control already falsified degree<=2 when all16labels were supplied; this successor does not assume all unseen laws belong to the class in real deployment.

## Random-search and fixed-heuristic competitors
There are C(15,7)=6435 possible distinct seven-query sets; only15 qualify, so a uniform random seven-set succeeds1/429. This is exact success probability for result IDENTIFICATION, not raw lucky label guessing. Any guessed bit can still match half of unqualified target cases by luck. Score certificates separately from raw correctness.

A source-written hyperplane/XOR procedure achieves7 queries, so it is a strong fixed rival. A generic span/enumeration rival also succeeds under the same information. Random success is not vanishingly impossible and repeated search can find witness sets; charge every enumeration/failed attempt, not only successful actions. Optimal7query information efficiency leaves no room for a learner beating this rival in observation count. Any advantage must be acquisition/construction cost, representational reuse, task diversity or a changed information prior, with appropriate accounting.

## Ownership trace
- Requested goal q: researcher-supplied structured goal, not natural-language understanding.
- Allowed QUERY(x) and forbidden q: environment action contract.
- Polynomial features, hypothesis class: researcher diagnostic prior.
- Finding witness subset: source-authored exhaustive rank search or fixed hyperplane construction.
- Choosing next x: source-authored baseline, NOT learner discovered.
- Returned y: synthetic environment consequence.
- XOR/result certificate and completion recognition: source-authored verifier.
- Intermediate basis/version space: derived data under researcher-written update machinery, not learned organization or cognitive workflow.
- Persistent acquired procedural object: NONE.

The independent trace prints the actual baseline path for q0, queries1..7, outputs XOR to result1 and explicitly labels every decision source. It is NOT evidence a learner owned those intermediate steps. The current direct function evaluator is a local simulation, not a deployed autonomous tool boundary.

## Integration contract for the next learner experiment
Deliver only structured goal, generic observation action interface, initial evidence, budget and consequence feedback. Keep hidden coefficients, witness-set enumeration, model oracle and certification evaluator outside the tested learner. Freeze learner before target revelation.

Scoring should maintain two distinct objects:
1. World qualification manifest: whether goal success is identifiable under available actions/resources, plus an explicit witness outside learner access.
2. Learner trajectory: what it actually chose, saw, constructed, executed, retained and revised, with ownership tags for every choice.

Use at least these varying goal conditions without task-mode labels:
- goal already identified from initial evidence (0new queries);
- informative7query goal with direct read blocked;
- same goal under unavailable distinctions (honest uncertainty/resource request);
- noisy/conflicting evidence, separately qualified under a declared noise/source model;
- changed consequences invalidating only some earlier uses;
- related new goals where retained procedure can change construction cost.

Do not send goal-specific witness rows, hyperplane rule, ordered subtasks or researcher-derived next actions to the learner. A learner could construct a generic executable procedure from consequences; that positive needs its own source audit and facts/procedure-separated erasure, and cannot inherit ownership from the external world qualification proof.

Target endpoint: after A, retained executable construction/recruitment dynamics reduce NEW B method acquisition under counted total work, preserving examples and task methods when the learning-procedure carrier alone is erased. The benchmark's fixed span/XOR competitor must remain strong. A lookup-only facts rival is inadequate; allow facts plus same-information inference. A flat executable store matching the advantage kills Web-specific necessity, not method acquisition in general.

Expected classification: these diagnostics are researcher-owned qualification tools, not L3. A future successful learner may be L2 or L3 candidate depending on who authored executable form and future construction dynamics. No architectural impossibility follows from one negative representation.

## Gates and provenance
Local PREREG.md saved before goal.zag; all frozen bars pass. Two fresh pure-Zag builds/runs identical; only raw byte slices with explicit byte get/put, no typed-i32 allocation. Main output0failures. Source e74a1f874db9451eed186129d2981f8f1c985657e91323e63b3700147dfffe7e; binary977338c7ded71f79ae514542e514b7d74649200e8d8dd7b5a62243da8646bfbb; output261d6063127764ff3801c289dd346cfa392f52d3a2cd3d618f2089775247c76c. Independent checker is a post-primary frozen-check extension, not newly preregistered learner success. Same-worker separate implementation, not independent human review. Local prereg was not committed; exploratory until approved commit and hostile cold replication.

No pushes, commits, repository edits, missing-world replacement reproduction or canonical TNN run. Previous negative findings preserved. Source context from official observed repo URL https://github.com/Sylorlabs/TNN . New code and evidence attached; no invented content links or infrastructure details.
