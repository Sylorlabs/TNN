# Team G successor: finite noisy active identification and METHOD state
October 7, 2026. New exploratory local prototype. Not canonical TNN or R48 reproduction.

## Verdict
Bounded serializable intervention-policy state: SURVIVED. General learned causal reasoning: UNRESOLVED. Superiority at original cost regime: NOT ESTABLISHED. A lower-cost graph-transfer advantage is promising but exploratory and still needs an independent adversary with broader stopping-policy tuning.

Observation-only causal worlds are rigorously unidentifiable, not a learner failure. The evaluator asserts that all three mechanisms have identical observational distributions, and that permitted interventions distinguish them. Learner inference receives individual noisy outcomes, never the exact evaluator distribution packet. Response noise independently flips each visible bit with probability .12-.28.

Four visible binary variables, anonymized through permutation. Training family: two active nodes with forward-copy/reverse-copy/common confounder. Heldout family: three-node forward chain/reverse chain/common confounder. Independent variable/value costs vary .04-.22. Every competitor has a .7 spend cap and eight-probe cap; stopping is free to choose. Twelve initial observational samples carry no candidate-distinguishing information. Eight actions set one variable to 0 or 1.

METHOD is a JSON file containing six action-score coefficients and two stop coefficients. FACTS are per-world posterior and outcome histories, erased between worlds. Forty-eight sampled methods are evaluated against120 training worlds on utility = correct - .45 * actual intervention cost; the best method is serialized. Greedy's cost exponent/stopping threshold and a cost-ranking fixed policy each get48 candidate evaluations on the same120 worlds. No learner source changes happen during execution.

## Fresh heldout numbers, 600 worlds
| Arm | Utility | Accuracy | Mean actual cost | Mean probes |
|---|---:|---:|---:|---:|
| Full METHOD | .591208 |79.833%|.460279|6.605|
| Fresh-process METHOD transplant |.591208|79.833%|.460279|6.605|
| Remove METHOD / facts-only birth policy |.371549|58.167%|.466928|7.851667|
| Reverse coefficient order |.333333|33.333%|0|0|
| Misleading9:1 wrong hypothesis prior |.299758|46%|.356092|5.398333|
| Irrelevant unused metadata |.591208|79.833%|.460279|6.605|
| Tuned greedy |.589833|69.167%|.226297|3.183333|
| Tuned cost-ranking fixed |.522155|65.667%|.298914|4.175|

Full minus greedy paired utility difference .001375, SE .017092. Higher full accuracy consumes twice the cost; claiming superiority on accuracy alone would be wrong. Removing METHOD changes action traces in471/600 worlds. Fresh-process deserialization reproduces full statistics exactly. Shuffling leads to immediate stopping, so that collapse diagnoses coefficient dependence, not a useful acquired algorithmic structure.

The truth-aware KL heuristic in results.json is NOT an optimal oracle; it can perform worse than a nonoracle. A separately labeled clairvoyant-answer upper bound has accuracy/utility1 with zero cost. Do not treat KL as the upper bound.

## Low-cost transfer and self-adversarial checks
Costs multiplied by .4, new heldout seeds, no METHOD re-training. Full utility .701343 versus original-regime greedy .624005. After equally budgeted120-world lower-cost training, greedy improves to .659906; the apparent gap narrows to .041438, paired SE .014450.

Six lower-cost heldout600-world seeds against this retuned greedy yield full-minus-greedy gaps .041438, .021828, .021048, .033821, .009213, .009414, each SE around .014. Positive average across seeds, but only the first looks individually clear. This is not a replicated general superiority verdict.

Self-red-team widened stopping options to include .99 and1.01 (continue to budget), keeping48 candidates. The new training-selected greedy is .599286 at original costs, beating full .591208 by .008078 (SE .018169), again no clear difference. At lower costs its chosen threshold .65 creates positive gaps .058884,.047021,.043483,.041983,.017058,.007396. The expanded grid changes which thresholds are available; broad stopping tuning remains a real adversarial target. No post-hoc baseline uses heldout reward to choose its policy.

## Source ownership
Researcher supplies candidate SCM families, their exact likelihoods, observation/intervention semantics, Bayesian posterior update, mutual-information features, linear scoring grammar, policy proposal distribution, training objective and stop executor. METHOD learning selects coefficients in that grammar; it does not discover Bayes, causal graphs or information gain. This is a substrate with acquired bounded policy parameters, not a learner that discovers how to organize cognition at L3.

The posterior prior control is genuinely difficult under noise: misleading prior accuracy46%, not trivially recovered. Irrelevant-prior control is weak: metadata is ignored by construction. Initial observational facts are unused because identical likelihoods provide no discrimination. Computational budgets are matched by candidate/world/probe caps, NOT total instruction counts; linear METHOD and MI/cost baselines share predictive model/MI calculation but instruction-by-instruction costs were not counted. Costs represent experiment expense, not measured runtime.

A random-policy implementation originally seeded its RNG with evaluator truth and active-node identities. Audited and removed before final report: random seed now derives only from observed cost sum and fixed seed. No method/fixed/greedy scores use those hidden identities. Final random figures are in results.json. The local source freeze preceded main run, then baseline-grid and random-seed audits were explicit amendments; this is exploratory evidence, not untouched preregistered confirmation.

## Next high-information attack
Independent competitor should tune a stronger posterior-risk stopping policy with the same48 candidate x120-world budget and permit continue-to-budget, then evaluate frozen policies on independent noisy families/costs. Add an unseen four-node fan-out versus chain/confounder family, outcome-likelihood misspecification, and larger action cost differences. Erase source-supplied MI features while keeping raw facts and general computation primitives; require an acquired serialized program to implement experiment selection. Only then is acquisition of causal method rather than coefficient selection directly tested.
