# Learned edit transformations: native mechanism assay
October7,2026. NEW bounded prototype, not canonical TNN, revise-real, or R2R integration. Prior procedure-transfer evidence retained. Native sources compiled before execution using the repository's pinned compiler; byte arenas only. No upstream changes.

## Findings
A learned two-instruction edit tape transfers to32 longer unseen executable tapes: append add1, then append double. Fresh-process persisted edit-only transplant32/32, erased0/32, reversed edit order0/32, wrong compound0/32. The transformation preserves all272 preexisting tape slots and appends two. This is L2: acquired reusable executable structure within source-authored machinery, NOT learned construction policy or L3. Every decision about search, next experiment and stopping is still researcher code. The main ownership problem remains unsolved.

Initial atomic training was unidentifiable: three examples retained3 repairs disagreeing on longer tapes. A fourth faulty tape/consequence witness eliminates alternatives. A first search-order bug interleaved two-step edits ahead of remaining one-step edits, contradicting breadth-first prereg; its raw results remain but those counters are PROCESS-FAIL, not promoted. Corrected atomic assay selects one supplied atomic edit (L1). Its success motivated the compound successor, not an architectural claim.

## Environment and executor
Executable tapes contain add1, double and negate modulo31. Generic edit primitives prepend/append an atomic instruction, delete first/last, reverse. Empty/single/double edit tapes form91 candidates. No named cognitive modes. Target generation is evaluator-only. Training gives faulty tape plus outcomes for inputs0,1,3,7 across four tapes; native learner tests candidate modifications on these consequences. At prime31 these distinguish affine output functions, though different source tapes can be semantically equivalent. Heldout32 tapes length5..12, seeds4..35. Training lengths2,3,4,9, so transfer includes unseen content and longer length12, not arbitrary recursion.

Four repair causes: related append-add-double, unrelated prepend-double, reverse, append-add. Learner acquires a first-consistent edit tape from train examples then tries it first on future failures. Source owns prior-first scheduling and complete fallback enumeration. This is a repair-template prior, not a learned acquisition policy. Training repair law and related hidden repair law intentionally match; correlated task-family reuse is the claim scope.

## Identification, replication and controls
Compound training has exactlyONE consistent edit in the full91-candidate class, (append-add,append-double), and zero conflicting survivors on related heldout tapes. All full-domain validity checks span31 inputs. Independent Python scalar interpreter checked128 native rows and native candidate counters with0 mismatches. Cold native compile with earlier binary removed reproduced stdout byte-identically. Separate two-buffer128-byte integrity probe gives0 mismatches; no typed []i32 allocations. This is internal verification, not independent human review.

Persistent state `learned_state.json` holds two edit operands and training_tapes0. Fresh native processes receive only those operands; native transplant mode skips train_ok and version-space scan. The evaluator in those processes still holds target outcomes for scoring and fallback, which must not be confused with execution-only prior correctness.

| repair cause | N | learned prior alone correct | full fresh mean candidate tests | prior+full fallback mean tests |
|---|---:|---:|---:|---:|
|append-add-double related|32|32|35.34375|1|
|prepend-double|32|1|3|3.90625|
|reverse|32|0|7.6875|8.6875|
|append-add|32|0|4.71875|5.71875|

Learned acquisition takes42 candidate trials, then32 related target probes =74 total candidates versus1131 fresh target candidates. These counters omit per-candidate training exposure, early failures, byte copying, allocation and verifier work; they are not matched CPU/memory or total-effects advantage. Training has extra examples; target rivals receive the same target verification oracle. Amortization is descriptive, not a fair general intelligence win.

Erasure plus complete fallback succeeds32/32 in every cause. Wrong prior is not intrinsically wrong across all worlds: e.g. prepending double is the correct unrelated repair. Reversing the compound destroys related prior correctness. Shuffle of a two-op sequence has only one nonidentity order, not a large random corruption battery. Slot-preservation values are causal for the related append case only; unchanged original slots on an incorrect unrelated repaired tape do NOT demonstrate retention or successful selective repair.

## Ownership trace
- Researcher-supplied goal: match observed IO consequences of faulty artifact.
- Machine primitives: arithmetic executor and atomic edits.
- External feedback: example outputs and final full-domain verifier.
- Learner-created object: discovered compound edit tape (3,4), persisted and used on unseen contents.
- Learned prior: the edit tape, not next-action/search policy.
- Researcher decisions: enumerate in length order, test examples in order, stop on first consistent candidate, try learned edit first, invoke complete fallback, choose fourth discriminating witness during prototype diagnosis, author correlated repair family.

No source-level workflow labels exist, but absence of labels does not make fixed search autonomous cognition. This assay is openly a fixed search experiment. Unknown-system discovery, self-initiated inquiry, method-policy acquisition, source-free applicability, and autonomous R2R order are NOT demonstrated.

## Strong rival and remaining limits
Complete breadth-first executable repair search is uncrippled and solves all tasks. A separate semantic-deduplicating competitor computes every candidate's full31-output signature, skips duplicate verification but charges all generated effect computations. It may reduce distinct verified candidates while not reducing generation. No neural sequence rival or arbitrary dynamic-substrate comparison ran. Do not present this as a flat/Web contest.

Next high-information successor: retain all facts, procedures and edit objects but learn a mutable *proposal policy* from delayed repair outcomes across diverse causes; cross-validate on withheld causes and misleading history. Erase only policy and permit baseline full repair search. Need matched total effect evaluation, discovered applicability, active distinguishing queries chosen by learner state, and ownership trace. Until that interface exists, procedure-template reuse cannot satisfy the user's north star.
