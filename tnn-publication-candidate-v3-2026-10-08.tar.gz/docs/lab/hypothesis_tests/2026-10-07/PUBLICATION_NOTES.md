# Publication notes

Collected research reports and supplied evidence, October 7, 2026. These reports preserve their original local-only status statements, historical negatives, exploratory deviations and qualification limits. Publishing them later does not retroactively make preregistrations upstream-frozen before experiments.

Reports are researcher-provided findings, not new independent verification by this publication step. Team C and F include supplied source and raw logs. Other reports may refer to source, logs or private working paths not included here; this collection is not a complete reproducibility claim. Team C compiled executables and transient compiler caches were excluded; source, compile/run logs and the original supplied hash inventory are retained. Team F original and corrected results are both retained. No code is installed into the runtime, no README claim is promoted and no production branch is changed.

Excluded Team C generated files:
- team-c/build/.zag-cache/zagd/semantic.record
- team-c/build/.zagd.semantic-ready
- team-c/build/arrays_corrected
- team-c/build/arrays_fixture
- team-c/build/b_competitors
- team-c/build/b_corrected
- team-c/build/b_facts_only
- team-c/build/b_original
- team-c/build/competitors
- team-c/build/flat_null
- team-c/build/flat_null_minimal
- team-c/build/flat_null_permuted
- team-c/build/flat_null_permuted_minimal
- team-c/build/raw_integrity
- team-c/build/reproduce
- team-c/build/tnn_accuracy

## Later evidence additions

Team F GC2 includes both flawed-alias checkpoint evidence and repaired snapshots/source. The original transplant checkpoint result is withdrawn as flawed, not validated by the repaired replay count. See team-f-gc2/alias-repair.md and reports/team-f-gc2-corrected.md. This is separate from the earlier Team F fixed-policy successor. Team D transform/policy source, raw results and reports, Team A goal-qualification source/raw/report and Team H4 ambiguity source/raw are included. Generated binaries and compiler caches from new archives were excluded. H4 has source and stdout but no separately supplied report.
