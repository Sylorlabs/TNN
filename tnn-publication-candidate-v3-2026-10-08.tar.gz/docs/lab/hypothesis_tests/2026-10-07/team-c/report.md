# Team C: hostile storage competition, October 7, 2026

## Answer
The current raw-byte Adaptive Web result is reproducible but does not distinguish a Web from ordinary flat fact storage. Its unchanged scorer passes a flat facts buffer with no executable methods and no live edges. Merely permuting those same rows removes the material-witness pass. On the report's seen-facts query task, six conventional store realizations and the original TNN code all score 40/40. Organization is noncausal for accuracy on that task. Web-specific method ownership remains unresolved, not disproved for all tasks.

## Frozen inputs and provenance
Read-only fresh checkout: lane/ownership d1ed7f15f60a3314896c2935d7057b72e55ea3bb; isolated detached fast/method-identifiability 6fa4fd4c7735cc12374c6f3339fa46edfb8b2a45. Source: https://github.com/Sylorlabs/TNN (live GitHub repository metadata and remote refs verified). Read FRONTIER_QUEUE.md, RAW_DISCOVERY_HYPOTHESIS.md, rawmatter_prefix.txt, rawmatter_realws.zag, and runA.txt at the fast tip. No upstream changes or commits. Local PREREG.md was frozen before null implementation. The upstream-committed prereg requirement is not met; no full-contract survivor is claimed.

## Raw-byte replication and hostile null
All computation and scores are pure Zag. Compilation succeeds before each new binary runs. Source, binary, output hashes are preserved. A second execution is byte-identical.

| Measure | original reproduction | ordinary flat rows | same flat rows permuted |
|---|---:|---:|---:|
| Total bytes |110656|110656|110656|
| Nonzero bytes |17550|16883|16883|
| Node-section fingerprint |2713070|1675098|1674460|
| Edge-section fingerprint |510334840|526244265|526244265|
| Log-section fingerprint |2833871|0|0|
| Sample uniqueness |57/64|64/64|64/64|
| Even/odd average fingerprint delta |174/232|44/70|1091/1739|
| Even/odd summed absolute deviation |0/0|0/0|2701/4213|
| A/B/C pass |1/1/1|1/1/1|1/1/0|

Null contains 100 fact triples in fixed-width records, reserved unused space, and -1 empty-index sentinels. It has no live edges, learned scopes, methods, or optimizer. Minimal null sources remove all TNN execution/learning code while preserving exact classifier/layout helpers; outputs remain identical to nulls originally concatenated with the repo prefix. Two interleaved affine input value sequences create the fingerprint gradients. These are ordinary record ordering effects, not learned organization.

A's shift predicate `(b >> 1) != b` is equivalent to `b != 0` for unsigned bytes. It checks zero/nonzero density, not relationships or sparse cross-region packing. B's node/edge/log boundaries are researcher-fixed offsets. C samples those known fields, then treats low even/odd delta deviation as material. It never queries a causal contribution of a region. The variable called variance is summed absolute deviation, not statistical variance. B also permits unequal byte diversity to set its distinct flag even when fingerprints do not satisfy its first distinctness check.

Verdict: KILLED as Web-specific evidence; SURVIVED only as the narrow structured/nonrandom-byte observation.

## Matched-capacity competitors
100 facts: subjects 0..49, two opaque relation identifiers, values `3s+7` and `5s+13`. Evaluation: 40 previously taught keys, answer not passed to retrieval. All arms have 110656-byte persistent arena and 512 examined-record ceiling per query. No query invokes the value formula; formula is only generator/scorer. Controls: 0 baseline; 1 reverse insertion; 2 bijective subject/relation renaming; 3 erased facts; 4 100 irrelevant prior rows; 5 100 wrong prior rows followed by correct evidence. Raw results in competitors.run.csv.

| arm | accuracy baseline | query probes baseline | construction probes | construction integer writes |
|---|---:|---:|---:|---:|
| flat indexed |40/40|40|100|400|
| sorted relation table |40/40|234|4950|300|
| chained graph |40/40|40|0|500|
| sequence |40/40|3220|0|300|
| sparse exact-key association |40/40|40|100|400|
| executable predicate/return tape |40/40|3220|0|500|

Every arm scores 40/40 under reverse insertion, renaming, irrelevant prior, and corrected misleading prior; erased facts scores 0/40. Original TNN ev_teach/ev_query, independently compiled and scored, also returns 40/40.

Limitations: capacity and per-query record ceiling are matched, not equal actual occupied memory or equal CPU cycles. Probe metric counts visited records/index slots, not every integer load, branch or TNN edge scan. TNN's query compute was not instrumented, so no matched-compute speed claim versus original TNN is justified. Sparse association uses same exact-key semantics as flat hash storage; not an independent semantic mechanism. Executable store executes only predicate/return retrieval, not unrestricted program synthesis. Strong alternatives for this lookup task do not establish adequate baselines for invention. Sequence is not given a free index; adding one would turn its retrieval cost into that of indexed storage. Source supplies all keying, index construction, update rules and tape semantics. Learner state contains facts and ordinary derived indexes only. No L3 result.

Architectural implication: known-fact accuracy and raw byte regularity cannot justify Adaptive Web causality. New tests must equate fact information, executable semantics, and resource costs, then ablate learned organization without erasing its facts or otherwise disabling competitors.

Successor: apply independently implemented flat offset table, relation rows, generic graph and executable affine tapes to Team B's consequence-equivalent overlapping/nested regions on unseen values. Match discovered offsets, training opportunities, search work, update work, and representation capacity. Test changed consequences requiring selective updates; compare rebuilding regions versus direct table update. Awaiting B's frozen API/source through coordinator.

## Follow-up: independent Team B heldout task
Team B's frozen prereg/source was supplied by coordinator after first results. B defines 24 labels, 3 views, 2 examples at x=2/5, and tests 576 unseen x=40..47 cases. Teacher-only law is `(5*label+3*view)%7`, with six label/view pairs shifted by one modulo seven. Learner receives only examples. C independently implemented learner difference verification and six stores, freezing B_PREREG.md first. No region construction code is copied into C stores. A separate facts-only implementation retains raw y examples and reconstructs offsets per query.

| store | baseline correct | renamed/reverse/irrelevant | misleading changed-world | revised after 12 new examples | erased offsets | baseline query probes |
|---|---:|---:|---:|---:|---:|---:|
| flat indexed |576/576|576/576|528/576|576/576|0/576|576|
| relation table |576/576|576/576|528/576|576/576|0/576|3072|
| chained graph |576/576|576/576|528/576|576/576|0/576|576|
| sequence |576/576|576/576|528/576|576/576|0/576|21024|
| sparse exact-key association |576/576|576/576|528/576|576/576|0/576|576|
| predicate/return tape |576/576|576/576|528/576|576/576|0/576|21024|

Flat baseline: 144 teacher examples, 72 construction probes, 288 integer writes. Revision: 156 total examples, 78 construction probes, 294 integer writes. Raw construction counts for all other arms are preserved in b_competitors.run.csv. Independent manually derived expectations exactly match: six changed pairs each have eight test inputs, hence 48 wrong out of 576 under stale state. Revised method here is source-defined replacement, not learner-invented repair.

Facts-only reconstruction: 576/576, 144 training integer writes, 1152 evaluation example reads, 2304 evaluation arithmetic operations (two subtractions, equality, addition per query). This is a strong facts-only control, not one deliberately forbidden to infer a rule. Input generation and equality-scoring law are researcher supplied; no target label is exposed to ask or experience.

No stronger claim from tape: tape only returns inferred offset and shared source performs addition; it does not synthesize an executable additive method. Sparse arm is an exact-key associative store, duplicating flat hash mechanics. Representation information and training opportunities are equal across C arms; same arena capacity/record ceilings are used, not identical occupied bytes or CPU budgets. Construction primitive counting omits reads during shifted relation-row copying, key arithmetic, and allocation; do not compare these totals as cycle counts. All C store results are deterministic on repeated execution.

B's supplied original source independently compiles, then segfaults before output (return 139). Preserve as PROCESS-FAIL, not a numeric Web result. B is fixing it separately. Thus the current follow-up verdict is SURVIVED competitor adequacy on B's teacher task, with Web-specific advantage UNRESOLVED pending a runnable repaired Web. Additive hypothesis, consequence acquisition, retrieval API, and update procedure remain entirely researcher-defined. No L3 evidence.

## Corrected Team B replication and integrity qualification
B sent revised n*8 typed-slice allocation plus an iterative membership implementation. Independent cold compilation and three repeat runs confirm:

| B arm | correct/576 | member inspections / stated primitive count | expression nodes |
|---|---:|---:|---:|
| Web |576|22896|75|
| erase region roots |0|0|75|
| consistent rename |576|22896|75|
| membership scramble |0|22896|75|
| recombine |0|113736|93|
| stale changed world |528|22896|75|
| changed-world rebuild |576|22896|75|
| direct indexed flat |576|576|75 reported|
| facts-only |576|2304|75 reported|

The flat/facts node count reflects unused Web scaffolding still constructed in B's shared harness, not flat's required representation. Primitive counts mix membership-node visits with arithmetic operations, not full CPU instructions. Nevertheless direct offsets avoid the Web traversal, and C's independent arms confirm equivalent information suffices.

The original array-integrity fixture allocates n*4 for a typed i32 slice and reproducibly prints 13 bad flat rows, zero bad facts. Changing to n*8 produces zero bad rows, three repeated executions. This isolates an element-layout/allocation mismatch in these fixtures; the exact language/backend contract is not established, so do not state the compiler is proved defective. C's raw-byte duplicate-fact version and exhaustive 72-key reads for all six stores show zero bad entries, three identical runs. These C results do not rely on typed-i32 allocation.

Corrected Web verdict: KILLED Web-specific accuracy advantage on this additive task. Learned offsets matter; regions are a redundant retrieval representation over them. Erasing a particular implementation's roots disables its traversal, but that does not show the task needs those regions. Original crashes/corruption remain preserved as PROCESS-FAIL; no stale failed-build binary was used.

Further source-ownership caveat: B's changed-world rebuild creates a fresh workspace using all changed training offsets. It is not a continuous learner selectively splitting/merging old state following new evidence. C's sequential source-defined overwrite of the six changed pairs does achieve recovery, but neither demonstrates an acquired repair policy. Next highest-information experiment remains executable nonadditive construction under matched proposal/ISA/search resources, with persistent selective revision and fact-preserving organization lesions.
