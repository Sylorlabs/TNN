import csv,importlib.util,random,json,hashlib
from pathlib import Path
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('assay',p/'corrected.py')
# Load only definitions; never re-run top-level assay.
s=(p/'corrected.py').read_text();scope={'__file__':str(p/'corrected.py')};exec(s[:s.index('rows=[];states=[]')],scope)
class Counter:
 def __init__(self):self.history=[[] for _ in range(4)]
 def choose(self,cards,rng):
  quality=[sum(v)/len(v) if v else 4.5 for v in self.history];best=max(quality[d] for _,d in cards)
  return rng.choice([c for c in cards if abs(quality[c[1]]-best)<1e-12])
 def update(self,d,r):self.history[d].append(r)
raw=list(csv.DictReader((p/'corrected_raw.csv').open()));lookup={(int(r['seed']),r['prior'],int(r['world'])):r for r in raw if r['arm']=='continuous'}
fails=0;tests=0;checks=0;world=scope['world'];ep=scope['episode']
for seed in range(128):
 for prior in ['relevant','irrelevant','misleading']:
  c=Counter();target=seed%4
  for i in range(16):
   secret=target if prior=='relevant' else ((target+1)%4 if prior=='misleading' else (seed*7+i*3)%4)
   ep(c,world(seed,0,i,secret),random.Random(seed*10000+i),'continuous',secret)
  for i in range(8):
   curve,n,b=ep(c,world(seed,1,i,target),random.Random(seed*10000+300+i),'continuous',target);r=lookup[seed,prior,i];tests+=1
   fails+=int(curve!=[int(r['s'+str(j)]) for j in range(1,5)] or n!=int(r['charged']))
   # Independent fact checker scans every proposed candidate membership.
   survivors=[h for h in b['names'] if all(h in f['members'] for f in b['facts'])];assert sorted(survivors)==b['post'];checks+=len(b['names'])*len(b['facts'])
result={'independent_counter_worlds':tests,'mismatches':fails,'scalar_fact_membership_checks':checks,'note':'Direct-resolution counter baseline was independently coded after corrected run; its outcomes exactly match continuous, no architecture advantage.'}
(p/'independent.json').write_text(json.dumps(result,indent=2));print(result)
