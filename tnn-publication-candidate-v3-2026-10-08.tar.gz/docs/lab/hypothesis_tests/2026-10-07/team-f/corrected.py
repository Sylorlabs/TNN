import random,math,json,csv,hashlib
from pathlib import Path
P=Path(__file__).parent
ARMS=['rename','transplant','direct_baseline','continuous','fresh','facts_only','method_only','method_reset','method_permute','ridge_baseline','random','oracle']
class Method:
 def __init__(self):self.total=[0.0]*4;self.count=[0]*4
 def choose(self,cards,rng):
  scores=[(self.total[j]/self.count[j] if self.count[j] else 4.5) for j in range(4)]
  best=max(scores[c[1]] for c in cards);return rng.choice([c for c in cards if abs(scores[c[1]]-best)<1e-12])
 def update(self,j,r):self.total[j]+=r;self.count[j]+=1
 def state(self):return {'total':self.total[:],'count':self.count[:]}
def world(seed,phase,index,secret):
 rng=random.Random(seed*100000+phase*1000+index);perm=list(range(16));rng.shuffle(perm)
 names=[f'w{phase}-{index}-h{p:03d}-{rng.getrandbits(64):016x}' for p in range(16)]
 cards=[];partition={};card_ids=[]
 for d in range(4):
  for k in range(4):
   cid=f'w{phase}-{index}-q-{rng.getrandbits(64):016x}';card_ids.append(cid)
   if d==secret:groups={names[h]:f'g{perm[h]}' for h in range(16)}
   else:groups={names[h]:f'g{(perm[h]>>k)&1}' for h in range(16)}
   cards.append((cid,d));partition[cid]=groups
 rng.shuffle(cards);hidden=rng.choice(names)
 # Evaluator identifiability proof. Not exposed to learner.
 assert len({tuple(partition[cid][h] for cid in card_ids) for h in names})==16
 return names,cards,partition,hidden
def episode(method,w,rng,arm,secret):
 names,cards,part,hidden=w;post=set(names);facts=[];curve=[];charged=0
 for step in range(4):
  if len(post)==1:curve.append(1);continue
  if arm=='oracle':card=rng.choice([c for c in cards if c[1]==secret])
  elif arm=='random':card=rng.choice(cards)
  else:card=method.choose(cards,rng)
  cid,d=card;out=part[cid][hidden];before=len(post)
  # Membership evidence exposed only after query; no hidden label in policy.
  members=[h for h in names if part[cid][h]==out];post.intersection_update(members)
  assert hidden in post and post
  reward=math.log2(len(names)/len(members))-.05;method.update(d,reward)
  facts.append({'card':cid,'outcome':out,'members':members});cards=[c for c in cards if c[0]!=cid]
  charged+=1;curve.append(int(len(post)==1))
 return curve,charged,{'names':names,'facts':facts,'hidden_for_verifier':hidden,'post':sorted(post)}
def verify_retention(bank):
 checks=0;lost=0
 for b in bank:
  post=set(b['names'])
  for f in b['facts']:post.intersection_update(f['members'])
  checks+=1;lost+=int(sorted(post)!=b['post'] or b['hidden_for_verifier'] not in post)
 return checks,lost
rows=[];states=[]
for seed in range(128):
 target_secret=seed%4
 for prior in ['relevant','irrelevant','misleading']:
  for arm in ARMS:
   method=Method();bank=[]
   for i in range(16):
    secret=target_secret if prior=='relevant' else ((target_secret+1)%4 if prior=='misleading' else (seed*7+i*3)%4)
    # All arms see same prior worlds/caps; discarded states still charged.
    curve,n,b=episode(method,world(seed,0,i,secret),random.Random(seed*10000+i),'continuous',secret);bank.append(b)
   if arm in ['fresh','facts_only','method_reset']:method=Method()
   if arm=='method_permute':method.total=method.total[1:]+method.total[:1];method.count=method.count[1:]+method.count[:1]
   if arm=='method_only':bank=[]
   prior_state=method.state()
   if arm=='transplant':
    saved=json.loads(json.dumps(prior_state));method=Method();method.total=saved['total'];method.count=saved['count']
   if arm=='rename':method.total=method.total[1:]+method.total[:1];method.count=method.count[1:]+method.count[:1]
   for i in range(8):
    if arm in ['fresh','facts_only','method_reset']:method=Method()
    if arm=='fresh':bank=[]
    w=world(seed,1,i,target_secret)
    if arm=='rename':w=(w[0],[(cid,(d-1)%4) for cid,d in w[1]],w[2],w[3])
    curve,n,b=episode(method,w,random.Random(seed*10000+300+i),arm,target_secret);bank.append(b)
    checks,lost=verify_retention(bank)
    rows.append({'seed':seed,'prior':prior,'arm':arm,'world':i,'s1':curve[0],'s2':curve[1],'s3':curve[2],'s4':curve[3],'charged':n,'bank_checks':checks,'bank_losses':lost})
   states.append({'seed':seed,'prior':prior,'arm':arm,'prior_method':prior_state,'final_method':method.state(),'facts_bank':bank})
with (P/'corrected_raw.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(P/'corrected_states.json').write_text(json.dumps(states,separators=(',',':')))
summary={}
for prior in ['relevant','irrelevant','misleading']:
 summary[prior]={}
 for arm in ARMS:
  rr=[r for r in rows if r['prior']==prior and r['arm']==arm]
  summary[prior][arm]={k:sum(r[k] for r in rr)/len(rr) for k in ['s1','s2','s3','s4','charged']}
  summary[prior][arm]['world_first_query']=[sum(r['s1'] for r in rr if r['world']==i)/128 for i in range(8)]
(P/'corrected_results.json').write_text(json.dumps(summary,indent=2));print('rows',len(rows),'pointwise_bank_losses',sum(r['bank_losses'] for r in rows));print(json.dumps(summary,indent=2))
