#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, json, math, random, statistics
from dataclasses import dataclass
from pathlib import Path
import numpy as np

STRATS=3; FDIM=7; STEPS=4800; DELAY=(1,10)
DEV_SEEDS=[36101,36107,36113]
DEV_SCENARIOS=['aba','abca','abcb','cost_only','false_alarm']
FRESH_SEEDS=[36203,36209,36217]
FRESH_SCENARIOS=['abaca','gradual','success_only','long_return']
BETAS={'v2':None,'passive':0.0,'eig_006':0.06,'eig_012':0.12,'eig_020':0.20}

def phi3(x):
    a,b,c=x; return np.array([1.,a,b,c,a*b,b*c,a*c],float)
def sigmoid(z): return 1/(1+math.exp(-max(-20,min(20,float(z)))))
def entropy_bern(p):
    p=np.clip(p,1e-9,1-1e-9); return -(p*np.log(p)+(1-p)*np.log(1-p))

def gen_contexts(seed:int):
    r=np.random.default_rng(seed)
    A_s=r.normal(0,.55,(STRATS,FDIM)); A_s[:,0]+=np.array([.35,.15,0.])
    A_c=r.normal(0,.28,(STRATS,FDIM)); A_c[:,0]+=np.array([-1.45,-1.25,-1.05])
    out=[(A_s,A_c)]
    for j in range(1,4):
        s=r.normal(0,.65,(STRATS,FDIM)); c=r.normal(0,.32,(STRATS,FDIM))
        s[:,0]+=np.roll(np.array([.65,.10,-.30]),j); c[:,0]+=np.roll(np.array([-1.25,-1.55,-.95]),j)
        out.append((s,c))
    return out

def sched(sc,t):
    if sc=='aba': return [0,1,0][min(2,t//1600)],0.
    if sc=='abca': return [0,1,2,0][min(3,t//1200)],0.
    if sc=='abcb': return [0,1,2,1][min(3,t//1200)],0.
    if sc=='cost_only': return [0,1,0,1][min(3,t//1200)],2.
    if sc=='success_only': return [0,1,0,1][min(3,t//1200)],1.
    if sc=='abaca': return [0,1,0,2,0][min(4,t//960)],0.
    if sc=='long_return': return [0,1,2,3,0][min(4,t//960)],0.
    if sc=='false_alarm': return 0,3.
    if sc=='gradual':
        h=STEPS//2; a=t/h if t<h else (STEPS-t)/h
        return 1,max(0.,min(1.,a))
    raise KeyError(sc)

def make_tape(seed,sc):
    ctx=gen_contexts(seed*13+97); rng=random.Random(seed*1009+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int)
    hidden=[]
    for t in range(STEPS):
        f=phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]); F[t]=f
        k,flag=sched(sc,t); As,Ac=ctx[0]; Bs,Bc=ctx[k]
        if sc=='gradual':
            a=flag; Ws=(1-a)*As+a*Bs; Wc=(1-a)*Ac+a*Bc; hk=('blend',round(a,3))
        elif sc=='success_only': Ws=Bs;Wc=Ac;hk=('success',k)
        elif sc=='cost_only': Ws=As;Wc=Bc;hk=('cost',k)
        else: Ws,Wc=Bs,Bc;hk=k
        p=np.array([sigmoid(Ws[s]@f) for s in range(STRATS)]); c=np.array([.02+.28*sigmoid(Wc[s]@f) for s in range(STRATS)])
        P[t]=p;C[t]=c
        corrupt=sc=='false_alarm' and (1500<=t<1660 or 3150<=t<3270)
        for s in range(STRATS):
            q=(1-p[s]) if corrupt and rng.random()<.72 else p[s]
            O[t,s]=1. if rng.random()<q else 0.; D[t,s]=rng.randint(*DELAY)
        hidden.append(hk)
    return (F,P,C,O,D),hidden

class OnlineModel:
    def __init__(self):
        self.count=np.zeros(STRATS); self.ps=np.zeros((STRATS,FDIM));self.ps[:,0]=.5;self.pf=self.ps.copy();self.cs=np.zeros((STRATS,FDIM));self.cs[:,0]=.14;self.cf=self.cs.copy()
        self.ep_s=np.ones(STRATS)*.25;self.ep_f=np.ones(STRATS)*.25;self.ec_s=np.ones(STRATS)*.08;self.ec_f=np.ones(STRATS)*.08
    def _blend(self,slow,fast,es,ef):
        a=(1/(ef+.025))/((1/(ef+.025))+(1/(es+.025))); return a*fast+(1-a)*slow
    def predict(self,f):
        p=self._blend(self.ps@f,self.pf@f,self.ep_s,self.ep_f);c=self._blend(self.cs@f,self.cf@f,self.ec_s,self.ec_f)
        return np.clip(p,.02,.98),np.clip(c,.01,.45)
    def update(self,s,f,o,c,w=1.):
        if w<=1e-9:return
        n=float(f@f);w=min(1.,float(w))
        e=o-float(self.ps[s]@f);self.ps[s]+=(.016*w)*e*f/(1+.02*n);self.ep_s[s]=(.986**w)*self.ep_s[s]+(1-.986**w)*abs(e)
        e=o-float(self.pf[s]@f);self.pf[s]+=(.07*w)*e*f/(1+.05*n);self.ep_f[s]=(.94**w)*self.ep_f[s]+(1-.94**w)*abs(e)
        e=c-float(self.cs[s]@f);self.cs[s]+=(.022*w)*e*f/(1+.02*n);self.ec_s[s]=(.986**w)*self.ec_s[s]+(1-.986**w)*abs(e)
        e=c-float(self.cf[s]@f);self.cf[s]+=(.08*w)*e*f/(1+.05*n);self.ec_f[s]=(.94**w)*self.ec_f[s]+(1-.94**w)*abs(e)
        self.count[s]+=w
    def consolidate(self):
        z=copy.deepcopy(self);z.ps=z.pf.copy();z.cs=z.cf.copy();z.ep_s=z.ep_f.copy();z.ec_s=z.ec_f.copy();return z

class V2:
    def __init__(self):self.m=OnlineModel();self.count=self.m.count
    def predict(self,f):return self.m.predict(f)
    def choose(self,f,rng):
        p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.075 else int(np.argmax(u+.11/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):self.m.update(s,f,o,c)
    def diag(self):return {'models':1,'probe_fraction':0.}

class BayesArchive:
    def __init__(self,beta=0.,maxsnap=4,every=800):
        self.beta=beta;self.maxsnap=maxsnap;self.every=every;self.active=OnlineModel();self.count=self.active.count;self.snaps=[];self.w=np.array([1.]);self.up=0;self.last_snap=0;self.probes=0;self.decisions=0;self.reweights=0
    @staticmethod
    def dist(a,b):return float(np.mean(np.abs(a.ps-b.ps))+np.mean(np.abs(a.cs-b.cs))+np.mean(np.abs(a.pf-b.pf))+np.mean(np.abs(a.cf-b.cf)))
    def models(self):return self.snaps+[self.active]
    def reset_w(self):
        k=len(self.models())
        if k==1:self.w=np.array([1.])
        else:
            self.w=np.ones(k)*(.35/(k-1));self.w[-1]=.65
    def snapshot(self):
        z=self.active.consolidate()
        if self.snaps and min(self.dist(z,x) for x in self.snaps)<.035:return
        if len(self.snaps)>=self.maxsnap:self.snaps.pop(0)
        self.snaps.append(copy.deepcopy(z));self.reset_w()
    def matrices(self,f):
        ps=[];cs=[]
        for m in self.models():p,c=m.predict(f);ps.append(p);cs.append(c)
        return np.asarray(ps),np.asarray(cs)
    def predict(self,f):
        ps,cs=self.matrices(f);return np.tensordot(self.w,ps,1),np.tensordot(self.w,cs,1)
    def info_gain(self,f):
        ps,cs=self.matrices(f);mix=np.tensordot(self.w,ps,1)
        mi=entropy_bern(mix)-np.tensordot(self.w,entropy_bern(ps),1)
        cm=np.tensordot(self.w,cs,1);var=np.tensordot(self.w,(cs-cm)**2,1)
        ci=.5*np.log1p(var/(.035**2))
        return np.maximum(0.,mi+.30*ci)
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        if rng.random()<.04:return rng.randrange(STRATS)
        base=u+.08/np.sqrt(self.count+1)
        if self.beta<=0 or len(self.snaps)==0:return int(np.argmax(base))
        ig=self.info_gain(f);best=int(np.argmax(base));scores=base+self.beta*ig;diag=int(np.argmax(scores));opp=max(0.,float(base[best]-base[diag]))
        if diag!=best and self.beta*float(ig[diag])>opp+.0015:
            self.probes+=1;return diag
        return best
    def update(self,s,f,o,c,t):
        ms=self.models();ps=[];cs=[]
        for m in ms:p,q=m.predict(f);ps.append(p[s]);cs.append(q[s])
        ps=np.clip(np.asarray(ps),.02,.98);cs=np.asarray(cs)
        ll=np.where(o>.5,np.log(ps),np.log(1-ps))-.5*((cs-c)/.04)**2
        prior=.992*self.w+.008/len(ms);z=np.log(np.maximum(prior,1e-15))+ll;z-=z.max();post=np.exp(z);post/=post.sum();self.w=post;self.reweights+=1
        self.active.update(s,f,o,c);self.count=self.active.count;self.up+=1
        if self.up-self.last_snap>=self.every:self.snapshot();self.last_snap=self.up
    def diag(self):
        return {'models':len(self.models()),'snapshots':len(self.snaps),'probe_fraction':self.probes/max(1,self.decisions),'posterior_max':float(self.w.max()),'reweights':self.reweights}

def run_candidate(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*7919+sum(map(ord,sc)));m=V2() if name=='v2' else BayesArchive(BETAS[name]);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts)
    if sc=='aba': bounds=[1600,3200];ret=(3200,3900)
    elif sc in ('abca','abcb','cost_only','success_only'):bounds=[1200,2400,3600];ret=(3600,4300)
    elif sc=='abaca':bounds=[960,1920,2880,3840];ret=(3840,4540)
    elif sc=='long_return':bounds=[960,1920,2880,3840];ret=(3840,4540)
    elif sc=='gradual':bounds=[2400];ret=(4000,4700)
    elif sc=='false_alarm':bounds=[1500,1660,3150,3270];ret=None
    posts=[float(np.mean(oracle[b:min(STEPS,b+360)]-exp[b:min(STEPS,b+360)])) for b in bounds]
    rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def aggregate(rows,names):
    out={}
    for n in names:
        rr=[r['results'][n] for r in rows];rets=[x['return_regret'] for x in rr if x['return_regret'] is not None]
        out[n]={'mean_regret':statistics.mean(x['mean_regret'] for x in rr),'optimal':statistics.mean(x['optimal'] for x in rr),'post_change_regret':statistics.mean(x['post_change_regret'] for x in rr),'return_regret':statistics.mean(rets),'max_models':max(x['diag']['models'] for x in rr),'probe_fraction':statistics.mean(x['diag'].get('probe_fraction',0) for x in rr)}
        fas=[x for r,x in zip(rows,rr) if r['scenario']=='false_alarm']
        out[n]['false_alarm_regret']=statistics.mean(x['mean_regret'] for x in fas) if fas else None
    return out

def gate(agg,name):
    b=agg['v2'];x=agg[name]
    return {'return_improve':x['return_regret']<=.95*b['return_regret'],'overall_bound':x['mean_regret']<=1.03*b['mean_regret'],'post_bound':x['post_change_regret']<=1.05*b['post_change_regret'],'false_alarm_bound':x['false_alarm_regret']<=1.05*b['false_alarm_regret'],'models_bound':x['max_models']<=5,'probe_bound':x['probe_fraction']<=.20}

def run_suite(seeds,scenarios,names):
    rows=[]
    for seed in seeds:
        for sc in scenarios:
            tape,_=make_tape(seed,sc);results={n:run_candidate(n,tape,seed,sc) for n in names};rows.append({'seed':seed,'scenario':sc,'results':results})
    agg=aggregate(rows,names);g={n:gate(agg,n) for n in names if n!='v2'}
    return rows,agg,g

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['dev','fresh','one'],default='dev');ap.add_argument('--seed',type=int);ap.add_argument('--scenario');ap.add_argument('--candidate');ap.add_argument('--out',required=True);a=ap.parse_args()
    names=list(BETAS)
    if a.mode=='one':
        tape,_=make_tape(a.seed,a.scenario);obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run_candidate(a.candidate,tape,a.seed,a.scenario)}
    else:
        seeds,sc=(DEV_SEEDS,DEV_SCENARIOS) if a.mode=='dev' else (FRESH_SEEDS,FRESH_SCENARIOS);rows,agg,g=run_suite(seeds,sc,names);obj={'mode':a.mode,'seeds':seeds,'scenarios':sc,'aggregate':agg,'gates':g,'rows':rows}
        if a.mode=='dev':
            passing=[n for n in names if n!='v2' and all(g[n].values())];obj['passing']=passing;obj['selected']=min(passing,key=lambda n:agg[n]['return_regret']) if passing else None
    Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
    print(json.dumps(obj.get('aggregate',obj),sort_keys=True))
if __name__=='__main__':main()
