from pathlib import Path
import json,statistics
D=Path(__file__).resolve().parent
seeds=[36501,36507,36513,36519];scenarios=['staggered_return','cost_recurrence','unseen_pairing','double_recombine','cross_noise'];controls=['v2','r36','r39'];cands=['arb_slow','arb_mid','arb_sharp']
def rows(c):return [json.loads((D/'dev_jobs'/f'{s}_{sc}_{c}.json').read_text()) for s in seeds for sc in scenarios]
def agg(c):
 rs=rows(c)
 def mean(k,p=None):return statistics.fmean(r['result'][k] for r in rs if (p is None or p(r)) and r['result'][k] is not None)
 a={'mean_regret':mean('mean_regret'),'post_change_regret':mean('post_change_regret'),'return_regret':mean('return_regret',lambda r:r['result']['return_regret'] is not None),'cost_recurrence_return':mean('return_regret',lambda r:r['scenario']=='cost_recurrence'),'unseen_pairing_return':mean('return_regret',lambda r:r['scenario']=='unseen_pairing'),'cross_noise_mean':mean('mean_regret',lambda r:r['scenario']=='cross_noise')}
 if c!='v2':
  vm={(r['seed'],r['scenario']):r['result'] for r in rows('v2')};rat=[]
  for r in rs:
   rr=r['result']['return_regret']
   if rr is not None:
    vr=vm[(r['seed'],r['scenario'])]['return_regret']
    if vr and vr>0:rat.append(rr/vr)
  a['worst_return_ratio_vs_v2']=max(rat)
 if c in cands:
  ds=[r['result'].get('diag',{}) for r in rs];a['max_success_experts']=max(int(x.get('success_experts',0)) for x in ds);a['max_cost_experts']=max(int(x.get('cost_experts',0)) for x in ds);a['mean_success_factor_weight']=statistics.fmean(float(x.get('mean_success_factor_weight',0)) for x in ds);a['mean_cost_factor_weight']=statistics.fmean(float(x.get('mean_cost_factor_weight',0)) for x in ds)
 return a
m={c:agg(c) for c in controls+cands};b=m['r39']
for c in cands:
 x=m[c];g={'cost_recurrence':x['cost_recurrence_return']<=.95*b['cost_recurrence_return'],'worst_return':x['worst_return_ratio_vs_v2']<b['worst_return_ratio_vs_v2'],'mean_return':x['return_regret']<=b['return_regret'],'overall':x['mean_regret']<=1.02*b['mean_regret'],'post_change':x['post_change_regret']<=1.02*b['post_change_regret'],'unseen_pairing':x['unseen_pairing_return']<=1.02*b['unseen_pairing_return'],'cross_noise':x['cross_noise_mean']<=1.03*b['cross_noise_mean'],'bounded':x['max_success_experts']<=5 and x['max_cost_experts']<=5};x['gates']=g;x['pass']=all(g.values())
passers=[c for c in cands if m[c]['pass']];sel=min(passers,key=lambda c:(m[c]['cost_recurrence_return'],m[c]['worst_return_ratio_vs_v2'],m[c]['return_regret'])) if passers else None
out={'controls':{c:m[c] for c in controls},'candidates':{c:m[c] for c in cands},'selected':sel,'fresh_open_allowed':sel is not None};(D/'DEV_RESULTS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,indent=2,sort_keys=True))
