from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('dev',HERE/'r40_reliability_arbitration.py');dev=importlib.util.module_from_spec(sp);sp.loader.exec_module(dev)
r36=dev.r36;STEPS=r36.STEPS;STRATS=r36.STRATS;FDIM=r36.FDIM;DELAY=r36.DELAY

def state(sc,t):
    if sc=='long_cost_return':
        if t<800:return 0,0,0.
        if t<1900:return 0,2,0.
        if t<3300:return 0,3,0.
        return 0,2,0.
    if sc=='async_return':
        if t<650:return 0,0,0.
        if t<1350:return 1,0,0.
        if t<2150:return 1,2,0.
        if t<3000:return 0,2,0.
        if t<3700:return 2,0,0.
        return 0,0,0.
    if sc=='novel_recombine':
        if t<700:return 0,0,0.
        if t<1400:return 1,0,0.
        if t<2100:return 0,2,0.
        if t<2800:return 2,0,0.
        if t<3550:return 1,2,0.
        return 0,0,0.
    if sc=='gradual_cost_return':
        if t<700:return 0,0,0.
        if t<1700:return 0,0,min(1.,(t-700)/1000.)
        if t<2900:return 0,2,1.
        if t<3900:return 0,0,max(0.,(3900-t)/1000.)
        return 0,0,0.
    if sc=='noise_then_return':
        if t<1100:return 0,0,0.
        if t<2200:return 0,2,0.
        if t<3300:return 0,0,0.
        return 0,2,0.
    raise KeyError(sc)

def make_tape(seed,sc):
    ctx=r36.gen_contexts(seed*29+733);rng=random.Random(seed*1741+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int)
    for t in range(STEPS):
        f=r36.phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]);F[t]=f;si,ci,a=state(sc,t);Ws=ctx[si][0]
        if sc=='gradual_cost_return' and 700<=t<3900:
            W0=ctx[0][1];W2=ctx[2][1];Wc=(1-a)*W0+a*W2
        else:Wc=ctx[ci][1]
        p=np.array([r36.sigmoid(Ws[s]@f) for s in range(STRATS)]);c=np.array([.02+.28*r36.sigmoid(Wc[s]@f) for s in range(STRATS)])
        P[t]=p;C[t]=c;onoise=sc=='noise_then_return' and 550<=t<720;cnoise=sc=='noise_then_return' and 2750<=t<2950
        for s in range(STRATS):
            q=(1-p[s]) if onoise and rng.random()<.68 else p[s];O[t,s]=1. if rng.random()<q else 0.
            if cnoise:C[t,s]=min(.45,max(.01,c[s]+rng.uniform(.07,.15)))
            D[t,s]=rng.randint(*DELAY)
    return F,P,C,O,D

def windows(sc):
    if sc=='long_cost_return':return [800,1900,3300],(3300,4500)
    if sc=='async_return':return [650,1350,2150,3000,3700],(3700,4550)
    if sc=='novel_recombine':return [700,1400,2100,2800,3550],(3550,4550)
    if sc=='gradual_cost_return':return [700,1700,2900,3900],(3900,4550)
    if sc=='noise_then_return':return [550,720,1100,2200,2750,2950,3300],(3300,4500)
    raise KeyError(sc)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':dev.run(a.candidate,make_tape(a.seed,a.scenario),a.seed,a.scenario,windows)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
