from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('dev',HERE/'r41_strategy_reliability.py');dev=importlib.util.module_from_spec(sp);sp.loader.exec_module(dev)
r36=dev.r36;STEPS=r36.STEPS;STRATS=r36.STRATS;FDIM=r36.FDIM;DELAY=r36.DELAY

def phases(sc,t):
    if sc=='subset_cost_return':return 0 if t<800 or t>=3400 else (1 if t<2100 else 2)
    if sc=='subset_success_return':return 0 if t<750 or t>=3500 else (1 if t<2200 else 2)
    if sc=='split_async':
        if t<700:return 0
        if t<1450:return 1
        if t<2250:return 2
        if t<3050:return 3
        if t<3750:return 4
        return 0
    if sc=='partial_recombine':
        if t<700:return 0
        if t<1400:return 1
        if t<2100:return 2
        if t<2850:return 3
        if t<3600:return 4
        return 0
    if sc=='selective_noise':return 0 if t<1150 or (2200<=t<3350) else (1 if t<2200 else 2)
    raise KeyError(sc)

def select_weights(ctx,sc,t):
    ph=phases(sc,t);Ws=ctx[0][0].copy();Wc=ctx[0][1].copy();half=STRATS//2
    if sc=='subset_cost_return':
        if ph==1:Wc[:half]=ctx[2][1][:half]
        elif ph==2:Wc[half:]=ctx[3][1][half:]
    elif sc=='subset_success_return':
        if ph==1:Ws[:half]=ctx[1][0][:half]
        elif ph==2:Ws[half:]=ctx[2][0][half:]
    elif sc=='split_async':
        if ph>=1:Ws[:half]=ctx[1][0][:half]
        if ph>=2:Wc[half:]=ctx[2][1][half:]
        if ph>=3:Ws[:half]=ctx[0][0][:half];Ws[half:]=ctx[2][0][half:]
        if ph>=4:Wc[half:]=ctx[0][1][half:];Wc[:half]=ctx[3][1][:half]
    elif sc=='partial_recombine':
        if ph==1:Ws[:half]=ctx[1][0][:half]
        elif ph==2:Wc[half:]=ctx[2][1][half:]
        elif ph==3:Ws[:half]=ctx[1][0][:half];Wc[half:]=ctx[2][1][half:]
        elif ph==4:Ws[half:]=ctx[2][0][half:];Wc[:half]=ctx[3][1][:half]
    elif sc=='selective_noise':
        if ph==1:Wc[:half]=ctx[2][1][:half]
        elif ph==2:Wc[half:]=ctx[2][1][half:]
    return Ws,Wc

def make_tape(seed,sc):
    ctx=r36.gen_contexts(seed*31+911);rng=random.Random(seed*1877+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int);half=STRATS//2
    for t in range(STEPS):
        f=r36.phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]);F[t]=f;Ws,Wc=select_weights(ctx,sc,t)
        p=np.array([r36.sigmoid(Ws[s]@f) for s in range(STRATS)]);c=np.array([.02+.28*r36.sigmoid(Wc[s]@f) for s in range(STRATS)]);P[t]=p;C[t]=c
        for s in range(STRATS):
            q=p[s]
            if sc=='selective_noise' and 600<=t<790 and s<half and rng.random()<.72:q=1-q
            O[t,s]=1. if rng.random()<q else 0.
            if sc=='selective_noise' and 2850<=t<3050 and s>=half:C[t,s]=min(.45,max(.01,c[s]+rng.uniform(.08,.16)))
            D[t,s]=rng.randint(*DELAY)
    return F,P,C,O,D

def windows(sc):
    if sc=='subset_cost_return':return [800,2100,3400],(3400,4500)
    if sc=='subset_success_return':return [750,2200,3500],(3500,4550)
    if sc=='split_async':return [700,1450,2250,3050,3750],(3750,4550)
    if sc=='partial_recombine':return [700,1400,2100,2850,3600],(3600,4550)
    if sc=='selective_noise':return [600,790,1150,2200,2850,3050,3350],(3350,4500)
    raise KeyError(sc)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':dev.run(a.candidate,make_tape(a.seed,a.scenario),a.seed,a.scenario,windows)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
