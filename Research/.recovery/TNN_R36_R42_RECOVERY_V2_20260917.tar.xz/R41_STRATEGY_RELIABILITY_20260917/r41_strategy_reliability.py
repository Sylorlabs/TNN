from __future__ import annotations
import argparse, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
R39=HERE.parent/'R39_ONLINE_FACTOR_EXPERTS_20260917'
bs=importlib.util.spec_from_file_location('base',R39/'r39_online_factor_experts.py');base=importlib.util.module_from_spec(bs);bs.loader.exec_module(base)
fs=importlib.util.spec_from_file_location('fresh39',R39/'r39_fresh_challenge.py');fresh39=importlib.util.module_from_spec(fs);fs.loader.exec_module(fresh39)
ws=importlib.util.spec_from_file_location('wave3',R39/'r39_wave3_stability.py');wave3=importlib.util.module_from_spec(ws);ws.loader.exec_module(wave3)
r36=base.r36;STRATS=r36.STRATS;STEPS=r36.STEPS

class StrategyReliability:
    def __init__(self,eta,beta):
        self.factor=base.FactorExperts(.75,.18);self.stable=r36.BayesArchive(.12);self.eta=float(eta);self.beta=float(beta);self.count=self.stable.count
        self.sf=np.full(STRATS,.35);self.ss=np.full(STRATS,.35);self.cf=np.full(STRATS,.20);self.cs=np.full(STRATS,.20);self.asum=np.zeros(2);self.an=0
    def _a(self,stable_loss,factor_loss):
        z=np.clip(self.beta*(stable_loss-factor_loss),-20,20);a=1/(1+np.exp(-z));return np.clip(a,.15,.90)
    def weights(self):return self._a(self.ss,self.sf),self._a(self.cs,self.cf)
    def predict(self,f):
        pf,cf=self.factor.predict(f);ps,cs=self.stable.predict(f);a_s,a_c=self.weights();self.asum[0]+=float(np.mean(a_s));self.asum[1]+=float(np.mean(a_c));self.an+=1
        return a_s*pf+(1-a_s)*ps,a_c*cf+(1-a_c)*cs
    def choose(self,f,rng):
        p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):
        pf,cf=self.factor.predict(f);ps,cs=self.stable.predict(f);e=self.eta
        ef_s=abs(float(o)-float(pf[s]));es_s=abs(float(o)-float(ps[s]));ef_c=min(2.,abs(float(c)-float(cf[s]))/.15);es_c=min(2.,abs(float(c)-float(cs[s]))/.15)
        self.sf[s]=(1-e)*self.sf[s]+e*ef_s;self.ss[s]=(1-e)*self.ss[s]+e*es_s;self.cf[s]=(1-e)*self.cf[s]+e*ef_c;self.cs[s]=(1-e)*self.cs[s]+e*es_c
        self.factor.update(s,f,o,c,t);self.stable.update(s,f,o,c,t);self.count=self.stable.count
    def diag(self):
        d=self.factor.diag();a_s,a_c=self.weights();d.update({'success_factor_weight_min':float(a_s.min()),'success_factor_weight_max':float(a_s.max()),'cost_factor_weight_min':float(a_c.min()),'cost_factor_weight_max':float(a_c.max()),'mean_success_factor_weight':self.asum[0]/max(1,self.an),'mean_cost_factor_weight':self.asum[1]/max(1,self.an)});return d

def model(name):
    if name=='v2':return base.make_model('v2')
    if name=='r36':return base.make_model('r36')
    if name=='r39':return wave3.FixedBlend(.70)
    if name=='strat_slow':return StrategyReliability(.015,8.)
    if name=='strat_mid':return StrategyReliability(.035,8.)
    if name=='strat_sharp':return StrategyReliability(.025,12.)
    raise KeyError(name)

def run(name,tape,seed,sc,windows):
    F,P,C,O,D=tape;rng=random.Random(seed*13007+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh39.make_tape(a.seed,a.scenario),a.seed,a.scenario,fresh39.windows)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
