from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r38dev',HERE/'r38_factorized_context.py');r38=importlib.util.module_from_spec(spec);spec.loader.exec_module(r38)
r36=r38.r36; STEPS=r36.STEPS; STRATS=r36.STRATS; FDIM=r36.FDIM; DELAY=r36.DELAY

def factors(sc,t):
    if sc=='success_cycle':
        if t<900:return 0,0
        if t<1800:return 1,0
        if t<2900:return 2,0
        return 0,0
    if sc=='cost_cycle':
        if t<900:return 0,0
        if t<1800:return 0,1
        if t<2900:return 0,2
        return 0,0
    if sc=='unseen_recombine':
        if t<800:return 0,0
        if t<1600:return 1,2
        if t<2400:return 2,1
        if t<3500:return 1,1
        return 0,0
    if sc=='cross_return':
        if t<800:return 0,0
        if t<1500:return 1,1
        if t<2300:return 0,1
        if t<3300:return 1,0
        return 0,0
    if sc=='factor_noise':return 0,0
    raise KeyError(sc)

def make_tape(seed,sc):
    ctx=r36.gen_contexts(seed*19+307);rng=random.Random(seed*1301+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int)
    for t in range(STEPS):
        f=r36.phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]);F[t]=f;si,ci=factors(sc,t);Ws=ctx[si][0];Wc=ctx[ci][1]
        p=np.array([r36.sigmoid(Ws[s]@f) for s in range(STRATS)]);c=np.array([.02+.28*r36.sigmoid(Wc[s]@f) for s in range(STRATS)])
        P[t]=p;C[t]=c
        onoise=sc=='factor_noise' and 1000<=t<1160
        cnoise=sc=='factor_noise' and 3000<=t<3200
        for s in range(STRATS):
            q=(1-p[s]) if onoise and rng.random()<.70 else p[s]
            O[t,s]=1. if rng.random()<q else 0.
            if cnoise:C[t,s]=min(.45,max(.01,c[s]+rng.uniform(.09,.16)))
            D[t,s]=rng.randint(*DELAY)
    return F,P,C,O,D

def windows(sc):
    if sc in ('success_cycle','cost_cycle'):return [900,1800,2900],(2900,4400)
    if sc=='unseen_recombine':return [800,1600,2400,3500],(3500,4500)
    if sc=='cross_return':return [800,1500,2300,3300],(3300,4500)
    if sc=='factor_noise':return [1000,1160,3000,3200],None

def make_model(name):
    if name in ('v2','r36','haz05','factor_passive','factor_eig','factor_haz'):return r38.make_model(name)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*9109+sum(map(ord,sc)));m=make_model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);bounds,ret=windows(sc)
    posts=[float(np.mean(oracle[b:min(STEPS,b+360)]-exp[b:min(STEPS,b+360)])) for b in bounds]
    rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
