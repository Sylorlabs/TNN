from pathlib import Path
import concurrent.futures, subprocess, json, os
D=Path(__file__).resolve().parent; OUT=D/'dev_jobs'; OUT.mkdir(exist_ok=True)
seeds=[36301,36307,36313,36319]
scenarios=['irregular_return','double_return','partial_mix','noisy_stationary','novel_then_return']
candidates=['v2','r36','haz05','factor_passive','factor_eig','factor_haz']
jobs=[]
for seed in seeds:
  for sc in scenarios:
    for c in candidates:
      out=OUT/f'{seed}_{sc}_{c}.json'
      if not out.exists(): jobs.append((seed,sc,c,out))
def one(j):
  seed,sc,c,out=j
  p=subprocess.run(['python3',str(D/'r38_factorized_context.py'),'--seed',str(seed),'--scenario',sc,'--candidate',c,'--out',str(out)],capture_output=True,text=True)
  return {'seed':seed,'scenario':sc,'candidate':c,'rc':p.returncode,'stderr':p.stderr[-2000:]}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
  results=list(ex.map(one,jobs))
(D/'DEV_JOB_STATUS.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
if any(x['rc'] for x in results): raise SystemExit(1)
(D/'DEV_JOBS_COMPLETE').write_text('PASS\n')
print('completed',len(results),'new jobs')
