from __future__ import annotations
import argparse, importlib.util, json
from pathlib import Path
HERE=Path(__file__).resolve().parent
fs=importlib.util.spec_from_file_location('fresh',HERE/'r38_fresh_challenge.py');fresh=importlib.util.module_from_spec(fs);fs.loader.exec_module(fresh)
hs=importlib.util.spec_from_file_location('hybrid',HERE/'r38_hybrid_context.py');hybrid=importlib.util.module_from_spec(hs);hs.loader.exec_module(hybrid)
orig=fresh.make_model
def make_model(name):
    if name=='hybrid_adaptive': return hybrid.Hybrid(None)
    return orig(name)
fresh.make_model=make_model
ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':fresh.run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)}
Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
