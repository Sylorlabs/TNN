from __future__ import annotations
import argparse, copy, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
R37DIR=HERE.parent/'R37_ROBUST_CONTEXT_ROUTING_20260917'
spec=importlib.util.spec_from_file_location('r37fresh',R37DIR/'r37_fresh_challenge.py'); fresh=importlib.util.module_from_spec(spec);spec.loader.exec_module(fresh)
r37=fresh.r37; r36=fresh.r36
STRATS=r36.STRATS; FDIM=r36.FDIM; STEPS=r36.STEPS

class FactorArchive:
    def __init__(self,beta=0.0,hscale=0.0,maxsnap=4,every=800):
        self.beta=beta;self.hscale=hscale;self.maxsnap=maxsnap;self.every=every
        self.active=r36.OnlineModel();self.count=self.active.count
        self.ssnaps=[];self.csnaps=[];self.ws=np.array([1.]);self.wc=np.array([1.])
        self.up=0;self.last_snap=0;self.probes=0;self.decisions=0;self.reweights=0
        self.smean=1.0;self.sdev=.5;self.sev=0.;self.cmean=1.0;self.cdev=.5;self.cev=0.;self.hsum=0.;self.hmax=0.
    @staticmethod
    def sdist(a,b):return float(np.mean(np.abs(a.ps-b.ps))+np.mean(np.abs(a.pf-b.pf)))
    @staticmethod
    def cdist(a,b):return float(np.mean(np.abs(a.cs-b.cs))+np.mean(np.abs(a.cf-b.cf)))
    def smodels(self):return self.ssnaps+[self.active]
    def cmodels(self):return self.csnaps+[self.active]
    @staticmethod
    def reset_w(n):
        if n==1:return np.array([1.])
        w=np.ones(n)*(.35/(n-1));w[-1]=.65;return w
    def snapshot(self):
        z=self.active.consolidate()
        if not self.ssnaps or min(self.sdist(z,x) for x in self.ssnaps)>=.025:
            if len(self.ssnaps)>=self.maxsnap:self.ssnaps.pop(0)
            self.ssnaps.append(copy.deepcopy(z));self.ws=self.reset_w(len(self.smodels()))
        if not self.csnaps or min(self.cdist(z,x) for x in self.csnaps)>=.012:
            if len(self.csnaps)>=self.maxsnap:self.csnaps.pop(0)
            self.csnaps.append(copy.deepcopy(z));self.wc=self.reset_w(len(self.cmodels()))
    def matrices(self,f):
        ps=np.asarray([m.predict(f)[0] for m in self.smodels()])
        cs=np.asarray([m.predict(f)[1] for m in self.cmodels()])
        return ps,cs
    def predict(self,f):
        ps,cs=self.matrices(f);return np.tensordot(self.ws,ps,1),np.tensordot(self.wc,cs,1)
    def info_gain(self,f):
        ps,cs=self.matrices(f)
        pm=np.tensordot(self.ws,ps,1);mi=r36.entropy_bern(pm)-np.tensordot(self.ws,r36.entropy_bern(ps),1)
        cm=np.tensordot(self.wc,cs,1);var=np.tensordot(self.wc,(cs-cm)**2,1);ci=.5*np.log1p(var/(.035**2))
        return np.maximum(0.,mi+.30*ci)
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        if rng.random()<.04:return rng.randrange(STRATS)
        base=u+.08/np.sqrt(self.count+1)
        if self.beta<=0 or (not self.ssnaps and not self.csnaps):return int(np.argmax(base))
        ig=self.info_gain(f);best=int(np.argmax(base));score=base+self.beta*ig;diag=int(np.argmax(score));opp=max(0.,float(base[best]-base[diag]))
        if diag!=best and self.beta*float(ig[diag])>opp+.0015:self.probes+=1;return diag
        return best
    def _hazard(self,surprise,kind):
        if self.hscale<=0:return .008
        if kind=='s':mean,dev,ev=self.smean,self.sdev,self.sev
        else:mean,dev,ev=self.cmean,self.cdev,self.cev
        excess=max(0.,surprise-(mean+1.5*dev));ev=.88*ev+.12*excess;den=max(.15,dev*2.5);h=min(.25,max(.008,.008+self.hscale*min(1.,ev/den)))
        delta=abs(surprise-mean);mean=.985*mean+.015*surprise;dev=.985*dev+.015*delta
        if kind=='s':self.smean,self.sdev,self.sev=mean,dev,ev
        else:self.cmean,self.cdev,self.cev=mean,dev,ev
        self.hsum+=h;self.hmax=max(self.hmax,h);return h
    def update(self,s,f,o,c,t):
        sms=self.smodels();cms=self.cmodels()
        sp=np.clip(np.asarray([m.predict(f)[0][s] for m in sms]),.02,.98)
        cp=np.asarray([m.predict(f)[1][s] for m in cms])
        sll=np.where(o>.5,np.log(sp),np.log(1-sp)); cll=-.5*((cp-c)/.04)**2
        sm=float(sll.max());ssur=-(sm+math.log(max(1e-15,float(np.sum(self.ws*np.exp(sll-sm))))))
        cm=float(cll.max());csur=-(cm+math.log(max(1e-15,float(np.sum(self.wc*np.exp(cll-cm))))))
        hs=self._hazard(ssur,'s');hc=self._hazard(csur,'c')
        ps=(1-hs)*self.ws+hs/len(sms);pc=(1-hc)*self.wc+hc/len(cms)
        z=np.log(np.maximum(ps,1e-15))+sll;z-=z.max();self.ws=np.exp(z);self.ws/=self.ws.sum()
        z=np.log(np.maximum(pc,1e-15))+cll;z-=z.max();self.wc=np.exp(z);self.wc/=self.wc.sum();self.reweights+=1
        self.active.update(s,f,o,c);self.count=self.active.count;self.up+=1
        if self.up-self.last_snap>=self.every:self.snapshot();self.last_snap=self.up
    def diag(self):
        return {'success_factors':len(self.smodels()),'cost_factors':len(self.cmodels()),'models':max(len(self.smodels()),len(self.cmodels())),'probe_fraction':self.probes/max(1,self.decisions),'posterior_success_max':float(self.ws.max()),'posterior_cost_max':float(self.wc.max()),'reweights':self.reweights,'hazard_mean':self.hsum/max(1,2*self.reweights),'hazard_max':self.hmax}

def make_model(name):
    if name=='v2':return r36.V2()
    if name=='r36':return r36.BayesArchive(.12)
    if name=='haz05':return r37.HazardArchive(.05)
    if name=='factor_passive':return FactorArchive(0.,0.)
    if name=='factor_eig':return FactorArchive(.12,0.)
    if name=='factor_haz':return FactorArchive(.12,.03)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*8317+sum(map(ord,sc)));m=make_model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc)
    posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
