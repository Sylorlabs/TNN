from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r38base',HERE/'r38_factorized_context.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
r36=base.r36; fresh=base.fresh; STRATS=r36.STRATS; STEPS=r36.STEPS

class Hybrid:
    def __init__(self,alpha=None):
        self.mono=r36.BayesArchive(.12);self.fac=base.FactorArchive(.12,0.);self.alpha_fixed=alpha;self.decisions=0;self.probes=0;self.asum=0.;self.amax=0.;self.count=self.mono.count
    def alpha(self):
        if self.alpha_fixed is not None:return self.alpha_fixed
        fc=float(np.sqrt(self.fac.ws.max()*self.fac.wc.max()));mc=float(self.mono.w.max())
        return min(.80,max(.15,.15+1.50*max(0.,fc-mc)))
    def predict(self,f):
        pm,cm=self.mono.predict(f);pf,cf=self.fac.predict(f);a=self.alpha();self.asum+=a;self.amax=max(self.amax,a);return (1-a)*pm+a*pf,(1-a)*cm+a*cf
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        if rng.random()<.04:return rng.randrange(STRATS)
        baseu=u+.08/np.sqrt(self.count+1);best=int(np.argmax(baseu));a=self.alpha();ig=self.fac.info_gain(f);scores=baseu+(a*.12)*ig;diag=int(np.argmax(scores));opp=max(0.,float(baseu[best]-baseu[diag]))
        if diag!=best and (a*.12)*float(ig[diag])>opp+.0015:self.probes+=1;return diag
        return best
    def update(self,s,f,o,c,t):
        self.mono.update(s,f,o,c,t);self.fac.update(s,f,o,c,t);self.count=self.mono.count
    def diag(self):
        d=self.fac.diag();d.update({'mono_models':len(self.mono.models()),'blend_mean':self.asum/max(1,self.decisions),'blend_max':self.amax,'probe_fraction':self.probes/max(1,self.decisions)});return d

def model(name):
    if name=='hybrid25':return Hybrid(.25)
    if name=='hybrid50':return Hybrid(.50)
    if name=='hybrid75':return Hybrid(.75)
    if name=='hybrid_adaptive':return Hybrid(None)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*8317+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
