from __future__ import annotations
import argparse, copy, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('base',HERE/'r39_online_factor_experts.py');base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
r36=base.r36;fresh=base.fresh;STRATS=r36.STRATS;STEPS=r36.STEPS

class ConfirmedBank(base.Bank):
    def __init__(self,kind,threshold,confirm_n):
        super().__init__(kind,threshold);self.confirm_n=confirm_n;self.prov=None;self.prov_n=0;self.prov_gain=0.;self.confirmed=0;self.rejected=0
    def _loss(self,p,y):
        if self.kind=='s':
            q=min(.98,max(.02,float(p)));return -math.log(q if y>.5 else 1-q)
        return .5*((float(p)-float(y))/.045)**2
    def _start_candidate(self,winner,s,f,y):
        n=copy.deepcopy(self.experts[winner]);n.pf=n.ps.copy();n.cf=n.cs.copy();n.ep_f=n.ep_s.copy();n.ec_f=n.ec_s.copy();n.count=n.count*.25
        self.prov=n;self.prov_n=0;self.prov_gain=0.;self.evidence=0.
        if self.kind=='s':base.success_update(n,s,f,y,1.)
        else:base.cost_update(n,s,f,y,1.)
    def update(self,s,f,y):
        pr=self.preds(f,s)
        if self.kind=='s':
            p=np.clip(pr,.02,.98);ll=np.where(y>.5,np.log(p),np.log(1-p))
        else:ll=-.5*((pr-y)/.045)**2
        prior=.994*self.w+.006/len(self.w);z=np.log(np.maximum(prior,1e-15))+ll;z-=z.max();post=np.exp(z);post/=post.sum();self.w=post
        m=float(ll.max());sur=-(m+math.log(max(1e-15,float(np.sum(prior*np.exp(ll-m))))));amb=1-float(post.max());self.evidence=.90*self.evidence+.10*(max(0.,sur-.12)+.7*amb);self.emax=max(self.emax,self.evidence)
        winner=int(np.argmax(post));self.assignments[winner]+=1
        # Score a provisional expert pre-update against the current best existing expert.
        if self.prov is not None:
            cp=self.prov.predict(f)[0 if self.kind=='s' else 1][s]
            self.prov_gain += self._loss(pr[winner],y)-self._loss(cp,y);self.prov_n+=1
            if self.kind=='s':base.success_update(self.prov,s,f,y,1.)
            else:base.cost_update(self.prov,s,f,y,1.)
        for i,e in enumerate(self.experts):
            rw=float(post[i]**2)
            if i==winner:rw=max(rw,.55)
            if self.kind=='s':base.success_update(e,s,f,y,rw)
            else:base.cost_update(e,s,f,y,rw)
        if self.prov is not None and self.prov_n>=self.confirm_n:
            if self.prov_gain>2.0 and len(self.experts)<5:
                self.experts.append(self.prov);self.w=np.append(self.w*.45,.55);self.w/=self.w.sum();self.created+=1;self.confirmed+=1
            else:self.rejected+=1
            self.prov=None;self.prov_n=0;self.prov_gain=0.;self.evidence=0.
        if self.prov is None and self.evidence>self.threshold and (len(self.experts)==1 or float(post.max())<.78) and len(self.experts)<5:self._start_candidate(winner,s,f,y)

class ConfirmedFactors:
    def __init__(self,confirm_n):self.sb=ConfirmedBank('s',.75,confirm_n);self.cb=ConfirmedBank('c',.18,confirm_n);self.count=np.zeros(STRATS);self.decisions=0
    def predict(self,f):return self.sb.predict(f),self.cb.predict(f)
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):self.sb.update(s,f,o);self.cb.update(s,f,c);self.count[s]+=1
    def diag(self):return {'success_experts':len(self.sb.experts),'cost_experts':len(self.cb.experts),'models':max(len(self.sb.experts),len(self.cb.experts)),'success_created':self.sb.created,'cost_created':self.cb.created,'success_confirmed':self.sb.confirmed,'cost_confirmed':self.cb.confirmed,'success_rejected':self.sb.rejected,'cost_rejected':self.cb.rejected,'probe_fraction':0.}

class Blend:
    def __init__(self,factor,alpha=.75):self.factor=factor;self.stable=r36.BayesArchive(.12);self.alpha=alpha;self.count=self.stable.count;self.decisions=0
    def predict(self,f):
        pf,cf=self.factor.predict(f);ps,cs=self.stable.predict(f);return self.alpha*pf+(1-self.alpha)*ps,self.alpha*cf+(1-self.alpha)*cs
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):self.factor.update(s,f,o,c,t);self.stable.update(s,f,o,c,t);self.count=self.stable.count
    def diag(self):
        d=self.factor.diag();d['blend_factor']=self.alpha;return d

def model(name):
    if name=='confirm128':return ConfirmedFactors(128)
    if name=='confirm256':return ConfirmedFactors(256)
    if name=='confirm128_blend25':return Blend(ConfirmedFactors(128),.75)
    if name=='balanced_blend25':return Blend(base.FactorExperts(.75,.18),.75)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*9109+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
