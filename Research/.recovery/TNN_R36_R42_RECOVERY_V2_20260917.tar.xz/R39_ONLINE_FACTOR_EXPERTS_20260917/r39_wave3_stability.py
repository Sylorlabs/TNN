from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('base',HERE/'r39_online_factor_experts.py');base=importlib.util.module_from_spec(sp);sp.loader.exec_module(base)
r36=base.r36;fresh=base.fresh;STRATS=r36.STRATS;STEPS=r36.STEPS

class FixedBlend:
    def __init__(self,alpha):
        self.factor=base.FactorExperts(.75,.18);self.stable=r36.BayesArchive(.12);self.alpha=float(alpha);self.count=self.stable.count
    def predict(self,f):
        pf,cf=self.factor.predict(f);ps,cs=self.stable.predict(f)
        a=self.alpha
        return a*pf+(1-a)*ps,a*cf+(1-a)*cs
    def choose(self,f,rng):
        p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):
        self.factor.update(s,f,o,c,t);self.stable.update(s,f,o,c,t);self.count=self.stable.count
    def diag(self):
        d=self.factor.diag();d['blend_factor']=self.alpha;return d

class ConfidenceBlend(FixedBlend):
    def __init__(self):super().__init__(.70);self.alpha_sum=0.;self.alpha_n=0;self.alpha_min=1.;self.alpha_max=0.
    def _alpha(self):
        conf=min(float(self.factor.sb.w.max()),float(self.factor.cb.w.max()))
        a=max(.55,min(.90,.35+.55*conf))
        self.alpha_sum+=a;self.alpha_n+=1;self.alpha_min=min(self.alpha_min,a);self.alpha_max=max(self.alpha_max,a)
        return a
    def predict(self,f):
        pf,cf=self.factor.predict(f);ps,cs=self.stable.predict(f);a=self._alpha()
        return a*pf+(1-a)*ps,a*cf+(1-a)*cs
    def diag(self):
        d=self.factor.diag();d['blend_factor_mean']=self.alpha_sum/max(1,self.alpha_n);d['blend_factor_min']=self.alpha_min;d['blend_factor_max']=self.alpha_max;return d

def model(name):
    if name=='balanced_blend30':return FixedBlend(.70)
    if name=='balanced_blend35':return FixedBlend(.65)
    if name=='confidence_blend':return ConfidenceBlend()
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*9109+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
