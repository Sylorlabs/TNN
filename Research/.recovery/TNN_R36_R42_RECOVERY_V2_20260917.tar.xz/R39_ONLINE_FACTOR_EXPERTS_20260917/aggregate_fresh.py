from pathlib import Path
import json,statistics
D=Path(__file__).resolve().parent
seeds=[36501,36507,36513,36519];scenarios=['staggered_return','cost_recurrence','unseen_pairing','double_recombine','cross_noise'];candidates=['v2','r36','r38','balanced_blend30']

def rows(c):return [json.loads((D/'fresh_jobs'/f'{s}_{sc}_{c}.json').read_text()) for s in seeds for sc in scenarios]
def agg(c):
 rs=rows(c)
 def mean(k,p=None):return statistics.fmean(r['result'][k] for r in rs if (p is None or p(r)) and r['result'][k] is not None)
 a={'mean_regret':mean('mean_regret'),'post_change_regret':mean('post_change_regret'),'return_regret':mean('return_regret',lambda r:r['result']['return_regret'] is not None),'cost_recurrence_return':mean('return_regret',lambda r:r['scenario']=='cost_recurrence'),'unseen_pairing_return':mean('return_regret',lambda r:r['scenario']=='unseen_pairing'),'cross_noise_mean':mean('mean_regret',lambda r:r['scenario']=='cross_noise')}
 if c!='v2':
  vm={(r['seed'],r['scenario']):r['result'] for r in rows('v2')};rat=[]
  for r in rs:
   rr=r['result']['return_regret']
   if rr is not None:
    vr=vm[(r['seed'],r['scenario'])]['return_regret']
    if vr and vr>0:rat.append(rr/vr)
  a['worst_return_ratio_vs_v2']=max(rat)
 if c=='balanced_blend30':
  ds=[r['result'].get('diag',{}) for r in rs];a['max_success_experts']=max(int(x.get('success_experts',0)) for x in ds);a['max_cost_experts']=max(int(x.get('cost_experts',0)) for x in ds)
 return a
m={c:agg(c) for c in candidates};r=m['r38'];x=m['balanced_blend30']
g={
 'worst_return':x['worst_return_ratio_vs_v2']<r['worst_return_ratio_vs_v2'],
 'mean_return':x['return_regret']<=.95*r['return_regret'],
 'cost_recurrence':x['cost_recurrence_return']<=.90*r['cost_recurrence_return'],
 'unseen_pairing':x['unseen_pairing_return']<=.95*r['unseen_pairing_return'],
 'overall':x['mean_regret']<=1.03*r['mean_regret'],
 'post_change':x['post_change_regret']<=1.05*r['post_change_regret'],
 'cross_noise':x['cross_noise_mean']<=1.05*r['cross_noise_mean'],
 'bounded':x['max_success_experts']<=5 and x['max_cost_experts']<=5,
}
out={'metrics':m,'gates':g,'pass':all(g.values()),'selected':'balanced_blend30'}
(D/'FRESH_RESULTS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
