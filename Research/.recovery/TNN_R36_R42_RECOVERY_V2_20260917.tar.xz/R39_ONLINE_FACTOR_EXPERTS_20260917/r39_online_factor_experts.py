from __future__ import annotations
import argparse, copy, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
R38DIR=HERE.parent/'R38_FACTORIZED_CONTEXT_20260917'
fs=importlib.util.spec_from_file_location('r38fresh',R38DIR/'r38_fresh_challenge.py');fresh=importlib.util.module_from_spec(fs);fs.loader.exec_module(fresh)
hs=importlib.util.spec_from_file_location('r38hybrid',R38DIR/'r38_hybrid_context.py');hybrid=importlib.util.module_from_spec(hs);hs.loader.exec_module(hybrid)
r36=hybrid.r36; STRATS=r36.STRATS; STEPS=r36.STEPS

def success_update(m,s,f,o,w=1.0):
    w=max(0.,min(1.,float(w)));n=float(f@f)
    e=o-float(m.ps[s]@f);m.ps[s]+=(.018*w)*e*f/(1+.02*n);m.ep_s[s]=(.986**w)*m.ep_s[s]+(1-.986**w)*abs(e)
    e=o-float(m.pf[s]@f);m.pf[s]+=(.085*w)*e*f/(1+.05*n);m.ep_f[s]=(.94**w)*m.ep_f[s]+(1-.94**w)*abs(e);m.count[s]+=w

def cost_update(m,s,f,c,w=1.0):
    w=max(0.,min(1.,float(w)));n=float(f@f)
    e=c-float(m.cs[s]@f);m.cs[s]+=(.024*w)*e*f/(1+.02*n);m.ec_s[s]=(.986**w)*m.ec_s[s]+(1-.986**w)*abs(e)
    e=c-float(m.cf[s]@f);m.cf[s]+=(.095*w)*e*f/(1+.05*n);m.ec_f[s]=(.94**w)*m.ec_f[s]+(1-.94**w)*abs(e);m.count[s]+=w

class Bank:
    def __init__(self,kind,threshold):
        self.kind=kind;self.threshold=threshold;self.experts=[r36.OnlineModel()];self.w=np.array([1.]);self.evidence=0.;self.emax=0.;self.created=0;self.assignments=np.zeros(5)
    def preds(self,f,s=None):
        if self.kind=='s':a=np.asarray([m.predict(f)[0] for m in self.experts])
        else:a=np.asarray([m.predict(f)[1] for m in self.experts])
        return a if s is None else a[:,s]
    def predict(self,f):return np.tensordot(self.w,self.preds(f),1)
    def update(self,s,f,y):
        pr=self.preds(f,s)
        if self.kind=='s':
            p=np.clip(pr,.02,.98);ll=np.where(y>.5,np.log(p),np.log(1-p))
        else:ll=-.5*((pr-y)/.045)**2
        prior=.994*self.w+.006/len(self.w);z=np.log(np.maximum(prior,1e-15))+ll;z-=z.max();post=np.exp(z);post/=post.sum();self.w=post
        m=float(ll.max());sur=-(m+math.log(max(1e-15,float(np.sum(prior*np.exp(ll-m))))));amb=1-float(post.max());self.evidence=.90*self.evidence+.10*(max(0.,sur-.12)+.7*amb);self.emax=max(self.emax,self.evidence)
        winner=int(np.argmax(post));self.assignments[winner]+=1
        # responsibility-weighted learning keeps factors distinct while allowing recurrence refinement
        for i,e in enumerate(self.experts):
            rw=float(post[i]**2)
            if i==winner:rw=max(rw,.55)
            if self.kind=='s':success_update(e,s,f,y,rw)
            else:cost_update(e,s,f,y,rw)
        if self.evidence>self.threshold and (len(self.experts)==1 or float(post.max())<.78) and len(self.experts)<5:
            # seed a new plastic expert from the current winner's slow state, then allow fast specialization
            n=copy.deepcopy(self.experts[winner]);n.pf=n.ps.copy();n.cf=n.cs.copy();n.ep_f=n.ep_s.copy();n.ec_f=n.ec_s.copy();n.count=n.count*.25
            self.experts.append(n);self.w=np.append(self.w*.45,.55);self.w/=self.w.sum();self.created+=1;self.evidence=0.
            if self.kind=='s':success_update(n,s,f,y,1.)
            else:cost_update(n,s,f,y,1.)
    def diag(self):return {'count':len(self.experts),'posterior_max':float(self.w.max()),'created':self.created,'evidence':self.evidence}

class FactorExperts:
    def __init__(self,sthresh,cthresh):self.sb=Bank('s',sthresh);self.cb=Bank('c',cthresh);self.count=np.zeros(STRATS);self.decisions=0
    def predict(self,f):return self.sb.predict(f),self.cb.predict(f)
    def choose(self,f,rng):
        self.decisions+=1;p,c=self.predict(f);u=p-c
        return rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
    def update(self,s,f,o,c,t):self.sb.update(s,f,o);self.cb.update(s,f,c);self.count[s]+=1
    def diag(self):return {'success_experts':len(self.sb.experts),'cost_experts':len(self.cb.experts),'models':max(len(self.sb.experts),len(self.cb.experts)),'success_created':self.sb.created,'cost_created':self.cb.created,'success_posterior_max':float(self.sb.w.max()),'cost_posterior_max':float(self.cb.w.max()),'success_evidence':self.sb.evidence,'cost_evidence':self.cb.evidence,'success_evidence_max':self.sb.emax,'cost_evidence_max':self.cb.emax,'probe_fraction':0.}

def make_model(name):
    if name=='v2':return r36.V2()
    if name=='r36':return r36.BayesArchive(.12)
    if name=='r38':return hybrid.Hybrid(None)
    if name=='expert_strict':return FactorExperts(1.00,.25)
    if name=='expert_balanced':return FactorExperts(.75,.18)
    if name=='expert_fast':return FactorExperts(.55,.12)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*9109+sum(map(ord,sc)));m=make_model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
