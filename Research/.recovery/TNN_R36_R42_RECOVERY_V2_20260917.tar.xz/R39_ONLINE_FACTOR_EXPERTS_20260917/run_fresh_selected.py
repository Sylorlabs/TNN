from pathlib import Path
import concurrent.futures,subprocess,json
D=Path(__file__).resolve().parent;OUT=D/'fresh_jobs';OUT.mkdir(exist_ok=True)
seeds=[36501,36507,36513,36519];scenarios=['staggered_return','cost_recurrence','unseen_pairing','double_recombine','cross_noise'];candidates=['v2','r36','r38','balanced_blend30']
jobs=[]
for s in seeds:
 for sc in scenarios:
  for c in candidates:
   out=OUT/f'{s}_{sc}_{c}.json'
   if not out.exists():jobs.append((s,sc,c,out))
def one(j):
 s,sc,c,out=j;p=subprocess.run(['python3',str(D/'r39_fresh_selected.py'),'--seed',str(s),'--scenario',sc,'--candidate',c,'--out',str(out)],capture_output=True,text=True);return {'seed':s,'scenario':sc,'candidate':c,'rc':p.returncode,'stderr':p.stderr[-1600:]}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:res=list(ex.map(one,jobs))
(D/'FRESH_JOB_STATUS.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
if any(x['rc'] for x in res):raise SystemExit(1)
(D/'FRESH_JOBS_COMPLETE').write_text('PASS\n');print('completed',len(res),'jobs')
