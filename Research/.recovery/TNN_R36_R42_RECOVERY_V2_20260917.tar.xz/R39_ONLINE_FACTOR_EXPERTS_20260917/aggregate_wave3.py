from pathlib import Path
import json,math,statistics
D=Path(__file__).resolve().parent
seeds=[36401,36407,36413,36419];scenarios=['success_cycle','cost_cycle','unseen_recombine','cross_return','factor_noise']
controls=['v2','r36','r38'];cands=['balanced_blend30','balanced_blend35','confidence_blend']

def read_rows(candidate):
    base=D/'dev_jobs' if candidate in controls else D/'wave3_jobs'
    return [json.loads((base/f'{s}_{sc}_{candidate}.json').read_text()) for s in seeds for sc in scenarios]

def agg(candidate):
    rows=read_rows(candidate)
    mean=lambda key,flt=None:statistics.fmean(r['result'][key] for r in rows if (flt is None or flt(r)) and r['result'][key] is not None)
    a={'mean_regret':mean('mean_regret'),'post_change_regret':mean('post_change_regret'),'return_regret':mean('return_regret',lambda r:r['result']['return_regret'] is not None),'factor_noise_mean':mean('mean_regret',lambda r:r['scenario']=='factor_noise'),'cost_cycle_return':mean('return_regret',lambda r:r['scenario']=='cost_cycle'),'unseen_recombine_return':mean('return_regret',lambda r:r['scenario']=='unseen_recombine')}
    if candidate!='v2':
        vmap={(r['seed'],r['scenario']):r['result'] for r in read_rows('v2')}
        ratios=[]
        for r in rows:
            rr=r['result']['return_regret']
            if rr is not None:
                vr=vmap[(r['seed'],r['scenario'])]['return_regret']
                if vr and vr>0:ratios.append(rr/vr)
        a['worst_return_ratio_vs_v2']=max(ratios)
    if candidate in cands:
        diags=[r['result'].get('diag',{}) for r in rows]
        a['max_success_experts']=max(int(x.get('success_experts',0)) for x in diags)
        a['max_cost_experts']=max(int(x.get('cost_experts',0)) for x in diags)
    return a
allm={x:agg(x) for x in controls+cands}
r38=allm['r38']
for c in cands:
    m=allm[c]
    gates={
      'worst_return':m['worst_return_ratio_vs_v2']<r38['worst_return_ratio_vs_v2'],
      'cost_cycle':m['cost_cycle_return']<=.90*r38['cost_cycle_return'],
      'unseen_recombine':m['unseen_recombine_return']<=.95*r38['unseen_recombine_return'],
      'overall':m['mean_regret']<=1.03*r38['mean_regret'],
      'post_change':m['post_change_regret']<=1.05*r38['post_change_regret'],
      'noise':m['factor_noise_mean']<=1.05*r38['factor_noise_mean'],
      'bounded':m['max_success_experts']<=5 and m['max_cost_experts']<=5,
    }
    m['gates']=gates;m['pass']=all(gates.values())
passers=[c for c in cands if allm[c]['pass']]
selected=min(passers,key=lambda c:(allm[c]['worst_return_ratio_vs_v2'],allm[c]['return_regret'])) if passers else None
out={'controls':{c:allm[c] for c in controls},'candidates':{c:allm[c] for c in cands},'selected':selected,'fresh_open_allowed':selected is not None}
(D/'DEV_RESULTS_WAVE3.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
