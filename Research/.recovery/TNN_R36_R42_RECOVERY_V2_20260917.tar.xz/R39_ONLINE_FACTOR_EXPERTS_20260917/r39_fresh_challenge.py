from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('dev',HERE/'r39_online_factor_experts.py');dev=importlib.util.module_from_spec(sp);sp.loader.exec_module(dev)
r36=dev.r36;STEPS=r36.STEPS;STRATS=r36.STRATS;FDIM=r36.FDIM;DELAY=r36.DELAY

def factors(sc,t):
    if sc=='staggered_return':
        if t<700:return 0,0
        if t<1400:return 1,0
        if t<2100:return 1,2
        if t<2900:return 0,2
        if t<3600:return 2,0
        return 0,0
    if sc=='cost_recurrence':
        if t<850:return 0,0
        if t<1800:return 0,2
        if t<3150:return 0,3
        return 0,2
    if sc=='unseen_pairing':
        if t<800:return 0,0
        if t<1600:return 1,0
        if t<2400:return 0,2
        if t<3500:return 1,2
        return 0,0
    if sc=='double_recombine':
        if t<700:return 0,0
        if t<1400:return 1,1
        if t<2100:return 0,1
        if t<2800:return 2,0
        if t<3500:return 1,0
        return 0,0
    if sc=='cross_noise':return 0,0
    raise KeyError(sc)

def make_tape(seed,sc):
    ctx=r36.gen_contexts(seed*23+401);rng=random.Random(seed*1427+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int)
    for t in range(STEPS):
        f=r36.phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]);F[t]=f;si,ci=factors(sc,t);Ws=ctx[si][0];Wc=ctx[ci][1]
        p=np.array([r36.sigmoid(Ws[s]@f) for s in range(STRATS)]);c=np.array([.02+.28*r36.sigmoid(Wc[s]@f) for s in range(STRATS)])
        P[t]=p;C[t]=c;onoise=sc=='cross_noise' and 900<=t<1080;cnoise=sc=='cross_noise' and 3000<=t<3210
        for s in range(STRATS):
            q=(1-p[s]) if onoise and rng.random()<.72 else p[s];O[t,s]=1. if rng.random()<q else 0.
            if cnoise:C[t,s]=min(.45,max(.01,c[s]+rng.uniform(.08,.17)))
            D[t,s]=rng.randint(*DELAY)
    return F,P,C,O,D

def windows(sc):
    if sc=='staggered_return':return [700,1400,2100,2900,3600],(3600,4550)
    if sc=='cost_recurrence':return [850,1800,3150],(3150,4500)
    if sc=='unseen_pairing':return [800,1600,2400,3500],(3500,4550)
    if sc=='double_recombine':return [700,1400,2100,2800,3500],(3500,4550)
    if sc=='cross_noise':return [900,1080,3000,3210],None

def model(name):
    if name in ('v2','r36','r38','expert_strict','expert_balanced','expert_fast'):return dev.make_model(name)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*10007+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
