from __future__ import annotations
import argparse, importlib.util, json, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
fs=importlib.util.spec_from_file_location('freshgen',HERE/'r39_fresh_challenge.py');fresh=importlib.util.module_from_spec(fs);fs.loader.exec_module(fresh)
ws=importlib.util.spec_from_file_location('wave3',HERE/'r39_wave3_stability.py');wave3=importlib.util.module_from_spec(ws);ws.loader.exec_module(wave3)
base=wave3.base;r36=wave3.r36;STEPS=r36.STEPS;STRATS=r36.STRATS

def model(name):
    if name=='v2':return base.make_model('v2')
    if name=='r36':return base.make_model('r36')
    if name=='r38':return base.make_model('r38')
    if name=='balanced_blend30':return wave3.FixedBlend(.70)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*10007+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=fresh.windows(sc);posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b];rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':run(a.candidate,fresh.make_tape(a.seed,a.scenario),a.seed,a.scenario)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
