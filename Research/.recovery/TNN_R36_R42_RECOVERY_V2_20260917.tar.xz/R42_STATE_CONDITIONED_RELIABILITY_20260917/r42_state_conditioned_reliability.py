from __future__ import annotations
import argparse, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
R39=ROOT/'R39_ONLINE_FACTOR_EXPERTS_20260917'; R41=ROOT/'R41_STRATEGY_RELIABILITY_20260917'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
base=load('r39base',R39/'r39_online_factor_experts.py'); wave3=load('r39wave3',R39/'r39_wave3_stability.py'); fresh39=load('r39fresh',R39/'r39_fresh_challenge.py')
r36=base.r36; STRATS=r36.STRATS; STEPS=r36.STEPS; FDIM=r36.FDIM
BASE_ALPHA=.70; BASE_LOGIT=math.log(BASE_ALPHA/(1-BASE_ALPHA))

class StateConditionalArbiter:
    def __init__(self,lr,gain,fast_eta,slow_eta):
        self.factor=base.FactorExperts(.75,.18); self.stable=r36.BayesArchive(.12); self.count=self.stable.count
        self.lr=float(lr); self.gain=float(gain); self.fast_eta=float(fast_eta); self.slow_eta=float(slow_eta)
        self.fast_s=np.zeros(STRATS); self.slow_s=np.zeros(STRATS); self.fast_c=np.zeros(STRATS); self.slow_c=np.zeros(STRATS)
        self.tfs=np.zeros((STRATS,FDIM)); self.tss=np.zeros((STRATS,FDIM)); self.tfc=np.zeros((STRATS,FDIM)); self.tsc=np.zeros((STRATS,FDIM))
        self.theta_s=np.zeros((STRATS,10)); self.theta_c=np.zeros((STRATS,10)); self.pending={}; self.updates=0
        self.wsum=np.zeros(2); self.wdev=np.zeros(2); self.wn=0; self.wmin=np.ones(2); self.wmax=np.zeros(2); self.state_abs=0.
    @staticmethod
    def clip(v): return float(np.clip(v,-1.,1.))
    def stable_conf(self): return float(self.stable.w.max()) if len(self.stable.w) else 1.
    def features(self,f,s,ch,fp,sp):
        if ch=='s': fast,slow,tf,ts,post,evid,scale=self.fast_s[s],self.slow_s[s],self.tfs[s],self.tss[s],float(self.factor.sb.w.max()),float(self.factor.sb.evidence),.35
        else: fast,slow,tf,ts,post,evid,scale=self.fast_c[s],self.slow_c[s],self.tfc[s],self.tsc[s],float(self.factor.cb.w.max()),float(self.factor.cb.evidence),.12
        fn=float(f@f)+1e-9; sf=float(f@tf)/math.sqrt(fn*(float(tf@tf)+1e-9)); ss=float(f@ts)/math.sqrt(fn*(float(ts@ts)+1e-9))
        return np.asarray([1.,self.clip(fast),self.clip(slow),self.clip(fast-slow),self.clip(sf),self.clip(ss),self.clip(sf-ss),self.clip((float(fp)-float(sp))/scale),self.clip((post-.5)*2),self.clip((self.stable_conf()-.5)*2+min(1.,evid)*.25)],float)
    def weight(self,theta,z):
        pred=math.tanh(float(theta@z)); a=1/(1+math.exp(-(BASE_LOGIT+self.gain*pred))); return float(np.clip(a,.15,.90)),pred
    def raw(self,f):
        pf,cf=self.factor.predict(f); ps,cs=self.stable.predict(f); return pf,cf,ps,cs
    def predict(self,f):
        pf,cf,ps,cs=self.raw(f); p=np.empty(STRATS); c=np.empty(STRATS)
        for s in range(STRATS):
            a,_=self.weight(self.theta_s[s],self.features(f,s,'s',pf[s],ps[s])); b,_=self.weight(self.theta_c[s],self.features(f,s,'c',cf[s],cs[s])); p[s]=a*pf[s]+(1-a)*ps[s]; c[s]=b*cf[s]+(1-b)*cs[s]
        return p,c
    def choose(self,f,rng):
        pf,cf,ps,cs=self.raw(f); p=np.empty(STRATS); c=np.empty(STRATS); Zs=[]; Zc=[]; As=[]; Ac=[]
        for s in range(STRATS):
            zs=self.features(f,s,'s',pf[s],ps[s]); zc=self.features(f,s,'c',cf[s],cs[s]); a,qs=self.weight(self.theta_s[s],zs); b,qc=self.weight(self.theta_c[s],zc)
            p[s]=a*pf[s]+(1-a)*ps[s]; c[s]=b*cf[s]+(1-b)*cs[s]; Zs.append(zs); Zc.append(zc); As.append(a); Ac.append(b); self.state_abs+=abs(qs)+abs(qc)
        u=p-c; s=rng.randrange(STRATS) if rng.random()<.04 else int(np.argmax(u+.08/np.sqrt(self.count+1)))
        self.pending.setdefault(f.tobytes(),[]).append({'s':s,'zs':Zs[s],'zc':Zc[s],'pf':float(pf[s]),'ps':float(ps[s]),'cf':float(cf[s]),'cs':float(cs[s])})
        self.wsum += [As[s],Ac[s]]; self.wdev += [abs(As[s]-BASE_ALPHA),abs(Ac[s]-BASE_ALPHA)]; self.wn+=1; self.wmin=np.minimum(self.wmin,[As[s],Ac[s]]); self.wmax=np.maximum(self.wmax,[As[s],Ac[s]])
        return s
    def train(self,theta,z,target):
        pred=math.tanh(float(theta@z)); theta*=.9995; theta+=self.lr*(target-pred)*(1-pred*pred)*z; np.clip(theta,-2.,2.,out=theta)
    def update(self,s,f,o,c,t):
        key=f.tobytes(); q=self.pending.get(key); rec=None
        if q:
            idx=next((i for i,x in enumerate(q) if x['s']==s),0); rec=q.pop(idx)
            if not q:self.pending.pop(key,None)
        if rec is None:
            pf,cf,ps,cs=self.raw(f); rec={'zs':self.features(f,s,'s',pf[s],ps[s]),'zc':self.features(f,s,'c',cf[s],cs[s]),'pf':float(pf[s]),'ps':float(ps[s]),'cf':float(cf[s]),'cs':float(cs[s])}
        efs=abs(float(o)-rec['pf']); ess=abs(float(o)-rec['ps']); efc=min(2.,abs(float(c)-rec['cf'])/.15); esc=min(2.,abs(float(c)-rec['cs'])/.15)
        ts=float(np.clip(ess-efs,-1.,1.)); tc=float(np.clip(esc-efc,-1.,1.)); self.train(self.theta_s[s],rec['zs'],ts); self.train(self.theta_c[s],rec['zc'],tc)
        fe,se=self.fast_eta,self.slow_eta; self.fast_s[s]=(1-fe)*self.fast_s[s]+fe*ts; self.slow_s[s]=(1-se)*self.slow_s[s]+se*ts; self.fast_c[s]=(1-fe)*self.fast_c[s]+fe*tc; self.slow_c[s]=(1-se)*self.slow_c[s]+se*tc
        self.tfs[s]=(1-fe)*self.tfs[s]+fe*ts*f; self.tss[s]=(1-se)*self.tss[s]+se*ts*f; self.tfc[s]=(1-fe)*self.tfc[s]+fe*tc*f; self.tsc[s]=(1-se)*self.tsc[s]+se*tc*f
        self.updates+=1; self.factor.update(s,f,o,c,t); self.stable.update(s,f,o,c,t); self.count=self.stable.count
    def diag(self):
        d=self.factor.diag(); d.update({'arb_updates':self.updates,'base_factor_weight':BASE_ALPHA,'mean_success_factor_weight':float(self.wsum[0]/max(1,self.wn)),'mean_cost_factor_weight':float(self.wsum[1]/max(1,self.wn)),'mean_success_weight_deviation':float(self.wdev[0]/max(1,self.wn)),'mean_cost_weight_deviation':float(self.wdev[1]/max(1,self.wn)),'success_factor_weight_min':float(self.wmin[0]),'success_factor_weight_max':float(self.wmax[0]),'cost_factor_weight_min':float(self.wmin[1]),'cost_factor_weight_max':float(self.wmax[1]),'state_signal_abs_mean':float(self.state_abs/max(1,self.wn*STRATS*2)),'theta_success_norm':float(np.linalg.norm(self.theta_s)),'theta_cost_norm':float(np.linalg.norm(self.theta_c))}); return d
CANDIDATES={'state_cautious':(.012,.70,.060,.010),'state_balanced':(.025,1.00,.080,.012),'state_fast':(.045,1.20,.120,.018)}
def model(name):
    if name=='v2':return base.make_model('v2')
    if name=='r36':return base.make_model('r36')
    if name=='r39':return wave3.FixedBlend(.70)
    if name in CANDIDATES:return StateConditionalArbiter(*CANDIDATES[name])
    raise KeyError(name)
def run(name,tape,seed,sc,windows):
    F,P,C,O,D=tape; rng=random.Random(seed*13007+sum(map(ord,sc))); m=model(name); pending={}; exp=[]; choices=[]; opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t]; opt=int(np.argmax(tu)); s=m.choose(F[t],rng); choices.append(s); opts.append(opt); exp.append(float(tu[s])); due=t+int(D[t,s]); pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1); exp=np.asarray(exp); choices=np.asarray(choices); opts=np.asarray(opts); b,ret=windows(sc); posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b]; rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,required=True); ap.add_argument('--scenario',required=True); ap.add_argument('--candidate',required=True); ap.add_argument('--out',required=True); ap.add_argument('--fresh',action='store_true'); a=ap.parse_args()
    if a.fresh:
        fresh41=load('r41fresh_for_r42',R41/'r41_fresh_challenge.py'); tape=fresh41.make_tape(a.seed,a.scenario); windows=fresh41.windows
    else:tape=fresh39.make_tape(a.seed,a.scenario); windows=fresh39.windows
    obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'fresh':bool(a.fresh),'result':run(a.candidate,tape,a.seed,a.scenario,windows)}; Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
