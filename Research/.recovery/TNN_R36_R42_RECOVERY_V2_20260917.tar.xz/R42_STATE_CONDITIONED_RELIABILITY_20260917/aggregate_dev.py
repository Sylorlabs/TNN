from pathlib import Path
import json,statistics
D=Path(__file__).resolve().parent; ROOT=D.parent; R41=ROOT/'R41_STRATEGY_RELIABILITY_20260917'; R40=ROOT/'R40_RELIABILITY_ARBITRATION_20260917'
new=[json.loads(p.read_text()) for p in sorted((D/'dev_jobs').glob('*.json'))]
def inherited(dirp,name):
 rows=[]
 for p in sorted((dirp/'dev_jobs').glob(f'*_{name}.json')):
  x=json.loads(p.read_text());rows.append(x)
 return rows
controls={'v2':inherited(R41,'v2'),'r36':inherited(R41,'r36'),'r39':inherited(R41,'r39'),'r40_mid':inherited(R40,'arb_mid'),'r40_sharp':inherited(R40,'arb_sharp'),'r41_slow':inherited(R41,'strat_slow'),'r41_mid':inherited(R41,'strat_mid')}
scenarios=['staggered_return','cost_recurrence','unseen_pairing','double_recombine','cross_noise'];seeds=[36501,36507,36513,36519]
def normalize(row):return {'seed':row['seed'],'scenario':row['scenario'],'result':row['result']}
def rows_for(name):
 if name in controls:return [normalize(r) for r in controls[name]]
 return [normalize(r) for r in new if r['candidate']==name]
def mean(name,key,sc=None):
 a=[r['result'][key] for r in rows_for(name) if (sc is None or r['scenario']==sc) and r['result'][key] is not None];return statistics.mean(a)
def summary(name):
 rs=rows_for(name);d=[r['result']['diag'] for r in rs]
 out={'rows':len(rs),'mean_regret':mean(name,'mean_regret'),'post_change_regret':mean(name,'post_change_regret'),'return_regret':mean(name,'return_regret'),'cost_recurrence_return':mean(name,'return_regret','cost_recurrence'),'unseen_pairing_return':mean(name,'return_regret','unseen_pairing'),'cross_noise_mean':mean(name,'mean_regret','cross_noise'),'max_success_experts':max(x.get('success_experts',1) for x in d),'max_cost_experts':max(x.get('cost_experts',1) for x in d),'mean_weight_deviation':statistics.mean((x.get('mean_success_weight_deviation',0)+x.get('mean_cost_weight_deviation',0))/2 for x in d),'min_arb_updates':min(x.get('arb_updates',0) for x in d)}
 ratios=[]
 v2={(r['seed'],r['scenario']):r['result'] for r in rows_for('v2')}
 for r in rs:
  b=v2[(r['seed'],r['scenario'])];x=r['result'];
  if x['return_regret'] is not None and b['return_regret'] not in (None,0):ratios.append(x['return_regret']/b['return_regret'])
 out['worst_return_ratio_vs_v2']=max(ratios) if ratios else None;return out
names=list(controls)+['state_cautious','state_balanced','state_fast'];S={n:summary(n) for n in names};base=S['r39'];cand={}
for n in ['state_cautious','state_balanced','state_fast']:
 x=S[n];g={'cost_recurrence':x['cost_recurrence_return']<=.95*base['cost_recurrence_return'],'worst_return':x['worst_return_ratio_vs_v2']<base['worst_return_ratio_vs_v2'],'mean_return':x['return_regret']<=base['return_regret'],'overall':x['mean_regret']<=1.02*base['mean_regret'],'post_change':x['post_change_regret']<=1.02*base['post_change_regret'],'unseen_pairing':x['unseen_pairing_return']<=1.02*base['unseen_pairing_return'],'cross_noise':x['cross_noise_mean']<=1.03*base['cross_noise_mean'],'bounded_and_exercised':x['max_success_experts']<=5 and x['max_cost_experts']<=5 and x['min_arb_updates']>=100 and x['mean_weight_deviation']>=.01};cand[n]={**x,'gates':g,'pass':all(g.values())}
passing=[n for n,x in cand.items() if x['pass']];selected=min(passing,key=lambda n:(cand[n]['cost_recurrence_return'],cand[n]['worst_return_ratio_vs_v2'],cand[n]['return_regret'])) if passing else None
out={'status':'R42_DEVELOPMENT','candidate_job_count':len(new),'paired_control_source':'R41_STRATEGY_RELIABILITY_20260917/dev_jobs','historical_controls':['R40 arb_mid','R40 arb_sharp','R41 strat_slow','R41 strat_mid'],'controls':{n:S[n] for n in controls},'candidates':cand,'selected_for_fresh':selected,'fresh_open_allowed':selected is not None};(D/'DEV_RESULTS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,indent=2,sort_keys=True))
