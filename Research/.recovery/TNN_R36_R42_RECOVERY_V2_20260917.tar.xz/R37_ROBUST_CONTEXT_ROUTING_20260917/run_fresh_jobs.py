import concurrent.futures, subprocess, pathlib, sys
root=pathlib.Path(__file__).resolve().parent
seeds=[36301,36307,36313,36319]
scenarios=['irregular_return','double_return','partial_mix','noisy_stationary','novel_then_return']
cands=['v2','r36','haz05']
jobs=[(s,sc,c) for s in seeds for sc in scenarios for c in cands]
def one(job):
 s,sc,c=job;out=root/'fresh_jobs'/f'{s}_{sc}_{c}.json'
 if out.exists():return str(out)
 p=subprocess.run([sys.executable,str(root/'r37_fresh_challenge.py'),'--seed',str(s),'--scenario',sc,'--candidate',c,'--out',str(out)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
 if p.returncode:raise RuntimeError(f'{job}: {p.stderr}')
 return str(out)
with concurrent.futures.ProcessPoolExecutor(max_workers=6) as ex:
 for i,p in enumerate(ex.map(one,jobs),1):
  if i%6==0:print(i,flush=True)
(root/'FRESH_JOBS_COMPLETE').write_text('60\n')
