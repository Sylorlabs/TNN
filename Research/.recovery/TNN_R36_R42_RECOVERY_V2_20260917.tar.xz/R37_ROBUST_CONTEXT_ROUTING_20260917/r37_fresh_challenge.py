from __future__ import annotations
import argparse, importlib.util, json, math, random
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r37dev',HERE/'r37_robust_context.py');r37=importlib.util.module_from_spec(spec);spec.loader.exec_module(r37)
r36=r37.r36
STEPS=r36.STEPS; STRATS=r36.STRATS; FDIM=r36.FDIM; DELAY=r36.DELAY

def context_for(sc,t):
    if sc=='irregular_return':
        if t<700:return ('full',0)
        if t<1550:return ('full',1)
        if t<2250:return ('full',0)
        if t<3500:return ('full',2)
        return ('full',0)
    if sc=='double_return':
        if t<800:return ('full',0)
        if t<1600:return ('full',1)
        if t<2400:return ('full',0)
        if t<3300:return ('full',1)
        return ('full',0)
    if sc=='partial_mix':
        if t<900:return ('parts',0,0)
        if t<1750:return ('parts',1,0)
        if t<2600:return ('parts',1,2)
        if t<3550:return ('parts',0,2)
        return ('parts',0,0)
    if sc=='noisy_stationary':return ('noise',0)
    if sc=='novel_then_return':
        if t<1000:return ('full',0)
        if t<1900:return ('full',1)
        if t<3650:return ('full',3)
        return ('full',0)
    raise KeyError(sc)

def make_tape(seed,sc):
    ctx=r36.gen_contexts(seed*17+211);rng=random.Random(seed*1201+sum(map(ord,sc)))
    F=np.zeros((STEPS,FDIM));P=np.zeros((STEPS,STRATS));C=np.zeros((STEPS,STRATS));O=np.zeros((STEPS,STRATS));D=np.zeros((STEPS,STRATS),int)
    for t in range(STEPS):
        f=r36.phi3([rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-1,1)]);F[t]=f;tag=context_for(sc,t)
        As,Ac=ctx[0]
        if tag[0]=='full': Ws,Wc=ctx[tag[1]]
        elif tag[0]=='parts': Ws=ctx[tag[1]][0];Wc=ctx[tag[2]][1]
        else: Ws,Wc=As,Ac
        p=np.array([r36.sigmoid(Ws[s]@f) for s in range(STRATS)]);c=np.array([.02+.28*r36.sigmoid(Wc[s]@f) for s in range(STRATS)])
        P[t]=p;C[t]=c
        corrupt=sc=='noisy_stationary' and (1100<=t<1230 or 3010<=t<3190)
        for s in range(STRATS):
            q=(1-p[s]) if corrupt and rng.random()<.70 else p[s]
            O[t,s]=1. if rng.random()<q else 0.;D[t,s]=rng.randint(*DELAY)
    return F,P,C,O,D

def windows(sc):
    if sc=='irregular_return':return [700,1550,2250,3500],(3500,4500)
    if sc=='double_return':return [800,1600,2400,3300],(3300,4500)
    if sc=='partial_mix':return [900,1750,2600,3550],(3550,4500)
    if sc=='noisy_stationary':return [1100,1230,3010,3190],None
    if sc=='novel_then_return':return [1000,1900,3650],(3650,4550)

def model(name):
    if name=='v2':return r36.V2()
    if name=='r36':return r36.BayesArchive(.12)
    if name=='haz05':return r37.HazardArchive(.05)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*8317+sum(map(ord,sc)));m=model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(STEPS):
        for s,f,o,c in pending.pop(t,[]):m.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=m.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts);b,ret=windows(sc)
    posts=[float(np.mean(oracle[x:min(STEPS,x+360)]-exp[x:min(STEPS,x+360)])) for x in b]
    rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)),'return_regret':rr,'diag':m.diag()}

def main():
    a=argparse.ArgumentParser();a.add_argument('--seed',type=int,required=True);a.add_argument('--scenario',required=True);a.add_argument('--candidate',required=True);a.add_argument('--out',required=True);x=a.parse_args()
    o={'seed':x.seed,'scenario':x.scenario,'candidate':x.candidate,'result':run(x.candidate,make_tape(x.seed,x.scenario),x.seed,x.scenario)};Path(x.out).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
