import concurrent.futures, subprocess, pathlib, json, os, sys
root=pathlib.Path(__file__).resolve().parent
seeds=[36203,36209,36217]
scenarios=['abaca','gradual','success_only','long_return']
cands=['v2','r36','haz05','haz15','haz30','haz15r']
jobs=[(s,sc,c) for s in seeds for sc in scenarios for c in cands]
def one(job):
 s,sc,c=job; out=root/'dev_jobs'/f'{s}_{sc}_{c}.json'
 if out.exists(): return str(out)
 cmd=[sys.executable,str(root/'r37_robust_context.py'),'--seed',str(s),'--scenario',sc,'--candidate',c,'--out',str(out)]
 p=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
 if p.returncode: raise RuntimeError(f'{job}: {p.stderr}')
 return str(out)
with concurrent.futures.ProcessPoolExecutor(max_workers=6) as ex:
 for i,p in enumerate(ex.map(one,jobs),1):
  if i%6==0: print(i,flush=True)
(root/'DEV_JOBS_COMPLETE').write_text('72\n')
