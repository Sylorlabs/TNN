from __future__ import annotations
import copy, importlib.util, json, math, random, statistics, sys
from pathlib import Path
import numpy as np
BASE=Path(__file__).resolve().parent.parent/'R36_CONTEXT_IDENTIFICATION_20260917'/'r36_context_identification.py'
spec=importlib.util.spec_from_file_location('r36base',BASE); r36=importlib.util.module_from_spec(spec); spec.loader.exec_module(r36)

class HazardArchive(r36.BayesArchive):
    def __init__(self, scale:float, robust:bool=False):
        super().__init__(beta=.12,maxsnap=4,every=800)
        self.hscale=scale; self.robust=robust; self.smean=1.0; self.sdev=.5; self.evidence=0.; self.hsum=0.; self.hmax=0.
    def update(self,s,f,o,c,t):
        ms=self.models(); ps=[]; cs=[]
        for m in ms:
            p,q=m.predict(f); ps.append(p[s]); cs.append(q[s])
        ps=np.clip(np.asarray(ps),.02,.98); cs=np.asarray(cs)
        ll=np.where(o>.5,np.log(ps),np.log(1-ps))-.5*((cs-c)/.04)**2
        if self.robust:
            top=float(ll.max()); ll=np.maximum(ll,top-5.0)
        m=float(ll.max()); mix=float(np.sum(self.w*np.exp(ll-m))); surprise=-(m+math.log(max(1e-15,mix)))
        excess=max(0.,surprise-(self.smean+1.5*self.sdev))
        self.evidence=.88*self.evidence+.12*excess
        denom=max(.15,self.sdev*2.5)
        h=.008+self.hscale*min(1.,self.evidence/denom)
        h=min(.35,max(.008,h)); self.hsum+=h; self.hmax=max(self.hmax,h)
        prior=(1-h)*self.w+h/len(ms)
        z=np.log(np.maximum(prior,1e-15))+ll;z-=z.max();post=np.exp(z);post/=post.sum();self.w=post;self.reweights+=1
        delta=abs(surprise-self.smean); self.smean=.985*self.smean+.015*surprise; self.sdev=.985*self.sdev+.015*delta
        self.active.update(s,f,o,c);self.count=self.active.count;self.up+=1
        if self.up-self.last_snap>=self.every:self.snapshot();self.last_snap=self.up
    def diag(self):
        d=super().diag();d.update({'hazard_mean':self.hsum/max(1,self.reweights),'hazard_max':self.hmax,'surprise_mean':self.smean,'surprise_dev':self.sdev});return d

def make_model(name):
    if name=='v2':return r36.V2()
    if name=='r36':return r36.BayesArchive(.12)
    if name=='haz05':return HazardArchive(.05)
    if name=='haz15':return HazardArchive(.15)
    if name=='haz30':return HazardArchive(.30)
    if name=='haz15r':return HazardArchive(.15,True)
    raise KeyError(name)

def run(name,tape,seed,sc):
    F,P,C,O,D=tape;rng=random.Random(seed*7919+sum(map(ord,sc)));model=make_model(name);pending={};exp=[];choices=[];opts=[]
    for t in range(r36.STEPS):
        for s,f,o,c in pending.pop(t,[]):model.update(s,f,o,c,t)
        tu=P[t]-C[t];opt=int(np.argmax(tu));s=model.choose(F[t],rng);choices.append(s);opts.append(opt);exp.append(float(tu[s]));due=t+int(D[t,s]);pending.setdefault(due,[]).append((s,F[t].copy(),float(O[t,s]),float(C[t,s])))
    oracle=np.max(P-C,axis=1);exp=np.asarray(exp);choices=np.asarray(choices);opts=np.asarray(opts)
    if sc=='aba':bounds=[1600,3200];ret=(3200,3900)
    elif sc in ('abca','abcb','cost_only','success_only'):bounds=[1200,2400,3600];ret=(3600,4300)
    elif sc in ('abaca','long_return'):bounds=[960,1920,2880,3840];ret=(3840,4540)
    elif sc=='gradual':bounds=[2400];ret=(4000,4700)
    elif sc=='false_alarm':bounds=[1500,1660,3150,3270];ret=None
    else: bounds=[];ret=None
    posts=[float(np.mean(oracle[b:min(r36.STEPS,b+360)]-exp[b:min(r36.STEPS,b+360)])) for b in bounds]
    rr=float(np.mean(oracle[ret[0]:ret[1]]-exp[ret[0]:ret[1]])) if ret else None
    return {'mean_regret':float(np.mean(oracle-exp)),'optimal':float(np.mean(choices==opts)),'post_change_regret':float(np.mean(posts)) if posts else 0.,'return_regret':rr,'diag':model.diag()}

def dev_one(seed,sc,name):return run(name,r36.make_tape(seed,sc)[0],seed,sc)

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--scenario',required=True);ap.add_argument('--candidate',required=True);ap.add_argument('--out',required=True);a=ap.parse_args()
    obj={'seed':a.seed,'scenario':a.scenario,'candidate':a.candidate,'result':dev_one(a.seed,a.scenario,a.candidate)};Path(a.out).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':main()
