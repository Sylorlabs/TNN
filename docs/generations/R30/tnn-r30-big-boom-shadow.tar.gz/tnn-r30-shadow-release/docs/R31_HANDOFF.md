# R31 Handoff — Native Reproduction and Longer Development

R31 should begin by making the strongest R30 findings reproducible in native Zag rather than opening another broad substrate search.

## Gate 1 — durable native toolchain
1. Obtain a real `znc` compiler from the official `Sylorlabs/zag` source/release in an execution environment that can transfer binary bytes.
2. Verify hash/provenance and self-host/fixpoint.
3. Persist the verified compiler artifact immediately under project-local durable storage.
4. Compile `tnn_r30_big_boom.zag` twice and verify deterministic outputs.

## Gate 2 — native speech reproduction
- Reproduce the R30 stable-acoustic-identity CTC campaign in Zag.
- Run at least three independent seeds to the same 100k developmental dose.
- Checkpoint at 1k, 4k, 10k, 20k, 40k, 60k, 80k, 100k.
- Persist every checkpoint immediately.
- Run hard no-gap, long-sequence, coarticulation, endpoint damage, speaker transfer, repeated units, inserted silence and adversarial confidence batteries.
- Any exact 0 or 100 automatically launches the extreme-score diagnostic suite.

## Gate 3 — entity confidence
Focus on the remaining hard identity boundary: repeated confidently wrong evidence, severe occlusion, channel loss and identity/appearance conflict. Improve metacognitive sensory reliability and active evidence seeking without reintroducing graphs.

## Gate 4 — capacity-aware Master
Build a diagnostic teacher that allocates lesson budget based on failure severity **and** finite episodic diversity/capacity. Compare against random, balanced and self-curriculum controls.

## Gate 5 — resource-aware memory
Retain heuristic default + conservative regret override + LRU eviction-only. Train memory under multiple explicit resource envelopes so a policy cannot appear intelligent only by storing everything exactly.

## Gate 6 — contextual Foundry
Architecture-history proposals must be conditioned on observable failure telemetry. Never transfer architectural credit merely because two experiments are temporally adjacent.

## Gate 7 — one longer native life
After the above is native, run a single 250k+ event graph-free developmental life with global-step curriculum logic, fresh-process save/reload, teacher withdrawal, delayed relevance, changed physics, siblings, speech, names, active perception and self-revision.

Promotion remains contingent on native execution, exact lineage continuity, regression parity, trace integrity and clean-room reproducibility.
