# R30 Traceability Contract

Every consequential cognitive decision should be reconstructable through:

`evidence → sensory PAM → episodic retrieval → hypotheses → reliability → prediction → memory → active observation → action/language/social decision → outcome → regret → revision`

Required fields include event ID, parent event IDs, global development step, subsystem, generic reason code, subject/candidate IDs, evidence strength, uncertainty, chosen action, predicted outcome, actual outcome, regret and revision consequence.

The recovered 100k trace had 7,415 unique records, zero duplicate IDs and zero invalid parent references. However, because the raw trace was erased by a container reset, the final R30 release treats trace integrity as measured reference evidence rather than reproducible qualification evidence.

R31/R30-native reproduction must persist checkpoint and trace shards immediately to durable project storage rather than wait for end-of-run packaging.
