# R30 Failures and Boundaries

## Native execution
- No usable local `znc` could be materialized.
- Fresh shell clone of the official Zag repository failed due outbound networking.
- GitHub connector could locate the committed binary but could not return executable bytes.
- Therefore all R30 quantitative metrics are reference/fallback evidence only.

## Container reset
The unpersisted `/mnt/data/tnn-r30-big-boom` workspace was erased during a container refresh after substantial R30 execution. Metrics already visible in execution logs were reconstructed into `R30_RECOVERED_EXECUTION_SUMMARY.json`. Missing raw R30 traces and model checkpoints cannot be reconstructed and must be rerun for reproducible qualification.

## Speech
- Primary 100k seed is recovered only as checkpoint metrics, not the raw model file.
- Replication seeds are known only through 57.6k; do not claim their 100k endpoints.
- Silence-shift reached 100% and is explicitly quarantined pending a harder battery.

## Long life
- A segment-relative curriculum threshold bug was found after fresh-process reload.
- State continuity was preserved, but some mature evaluation/training pathways were temporarily delayed.
- A later 100k→120k continuation used corrected global thresholds; its summarized metrics survived in the recovery ledger, raw trace did not.

## Memory
- 99.74% aggressive exact recall at large budget is not treated as solved; the policy appears to exploit abundant capacity and does not generalize to tighter budgets.
- LRU-as-representation produced 0% exact recall and remains rejected.

## Foundry
- Uncontextualized architecture-history learners failed because they transferred stale credit between unrelated landscapes.
- Context-aware history fixed much of this, but it is still bounded synthetic evidence.

## Claims not made
No claim of unrestricted natural speech, human-level language, AHI, universal object permanence, open-ended recursive self-improvement, or native R30 qualification is made.
