# R30 Hardcoding Ledger

## Allowed protected substrate
- Generic memory storage classes and allocation mechanics.
- Generic Innate System Fluency: how to invoke internal machinery, not which task answer to choose.
- Generic CTC-style latent monotonic acoustic alignment machinery, if/when validated natively.
- Generic causal tracing and immutable evaluator/resource boundaries.
- Birth/default generic memory heuristic, with TNN retained as decision authority and learned overrides permitted.

## Explicitly not hardcoded
- English words, phonemes, vocabulary or grammar.
- VAD or acoustic word boundaries.
- Entity labels/categories.
- Which PAM should solve a task.
- Graph/entity relationship ontology.
- Benchmark answers.
- Architecture winner selection.

## Graph policy
Active R30 cognition and Foundry are graph-free. Historical graph experiments may exist only as research evidence outside the active runtime.

## Python boundary
Python was used as external fallback/reference experimentation because native Zag execution was blocked. No Python reference result is treated as native TNN capability or promotable cognition.
