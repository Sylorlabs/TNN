# R30 Authorship and Evidence Ledger

- Canonical inherited brain: verified R27 accepted lineage.
- R28/R29 graph-free architecture decisions are inherited project research.
- R30 native target source is reconstructed from the persisted graph-free R28 Zag source plus R30 source-contract additions.
- R30 quantitative experiments were executed through the fallback/reference runtime and are clearly labeled non-native.
- Metrics reconstructed after the container reset are sourced only from results that had already appeared in execution output; no missing values were invented.
- Replication endpoints that were not observed before reset are explicitly omitted.
- All exact 0%/100% values are flagged for diagnostic interpretation rather than automatically claimed as failure/success.
