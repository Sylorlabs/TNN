# R30 Big Boom — Shadow Status

**Disposition:** `SHADOW_RESEARCH_CHECKPOINT / NATIVE_PROMOTION_BLOCKED`  
**Canonical accepted brain:** R27  
**R30 newborn restarts:** 0  
**Active cognition:** graph-free  
**Native quantitative R30 execution:** not established in this environment  

R30 produced strong reference evidence, particularly for long no-VAD CTC training, but the cloud environment lost the unpersisted raw R30 workspace during a container reset and could not materialize the official `znc` binary. The measured R30 results are therefore retained as recovered reference evidence and cannot replace R27.

## Promotion blockers

- Reproduce the R30 long training quantitatively in native Zag.
- Re-run three speech seeds to the same 100k dose and preserve raw checkpoints.
- Run the final hard silence/coarticulation/open-set battery natively.
- Re-run one long life with global developmental thresholds from birth through fresh-process reload.
- Preserve raw causal traces and checkpoints durably as they are created.
- Pass R25–R27 regressions, native clean-room packaging, hardcoding/authorship audit.
