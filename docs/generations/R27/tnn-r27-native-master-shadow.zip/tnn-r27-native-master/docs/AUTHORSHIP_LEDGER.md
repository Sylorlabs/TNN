# Authorship Ledger

## TNN-side design target
- chooses memory disposition from learned delayed utility/regret;
- generates whole non-core PAM graphs from generic primitives;
- shadow-tests and mutates graph populations;
- tracks entity hypotheses and uncertainty;
- chooses evidence-gathering observations;
- learns action/effect and anonymous name bindings;
- handles sibling testimony with source lineage;
- diagnoses failures and uses causal history for later revisions.

## Researcher/assistant
- implemented protected generic Zag substrate and trace format;
- designed the core relational signature candidate after measured viewpoint information loss;
- designed external reference validators and adversarial worlds;
- removed a researcher-authored Foundry shortcut after detecting it;
- cannot claim native execution because compiler bytes are unavailable.

## Master teacher
- external to learner cognition; may select examples/contrasts and diagnose confusion;
- its knowledge is never counted as TNN runtime competence; qualification requires withdrawal.

## External verifier
- owns hidden truth/labels and promotion authority;
- external Python reference validators are evidence tools only, never TNN cognition.
