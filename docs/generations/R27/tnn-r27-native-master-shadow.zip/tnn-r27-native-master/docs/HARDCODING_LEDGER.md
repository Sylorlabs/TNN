# Hardcoding Ledger

## Protected / intentionally hardcoded
- generic numeric/sensory computational primitives;
- memory storage classes (not their selection policy);
- PAM VM primitive opcodes (not topology selection);
- causal trace format;
- immutable root verification boundary;
- resource envelope supplied externally;
- hardcoded Master teacher may exist outside learner cognition.

## Learned / TNN-controlled
- memory disposition policy and revision from regret;
- non-core PAM topology generation, mutation, testing, promotion proposal, deletion;
- entity persistence/split/merge evidence;
- active observation choice;
- action-effect model;
- name/entity motif bindings;
- sibling source reliability/consolidation;
- failure-driven non-core architecture search.

## Rejected hardcoding found during this run
The first Foundry draft explicitly mapped representation/routing/memory failure types to researcher-selected PAM opcodes. This was removed as noncompliant.
