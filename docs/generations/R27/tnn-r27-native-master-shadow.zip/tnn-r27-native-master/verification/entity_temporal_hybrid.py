#!/usr/bin/env python3
from __future__ import annotations
import json,math,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def bases(seed,n=40,d=12):
 r=random.Random(seed);return [[r.randrange(100,900)+e*13+r.randrange(-25,26) for _ in range(d)] for e in range(n)]
def tf(v,r,kind):
 x=list(v);d=len(x);sh=r.randrange(d);x=x[sh:]+x[:sh];scale=r.randrange(820,1181);off=r.randrange(-70,71);noise={'view':18,'occlusion':22,'compound':45,'clean':8}[kind]
 x=[z*scale/1000+off+r.uniform(-noise,noise) for z in x]
 if kind in ('occlusion','compound'):
  m=sum(x)/d
  for i in r.sample(range(d),d//3):x[i]=m+r.uniform(-12,12)
 return x
def sig(v):
 m=sum(v)/len(v);c=[x-m for x in v];span=max(c)-min(c)+1e-9;return sorted(x/span for x in c)
def dist(a,b):return sum((x-y)**2 for x,y in zip(a,b))
def centroid(xs):return [sum(x[i] for x in xs)/len(xs) for i in range(len(xs[0]))]
def classify(q,sets,cents):
 # two independent generic evidence routes
 ds_set=[];ds_cent=[]
 for i,views in enumerate(sets):
  vd=sorted(dist(q,m) for m in views);ds_set.append((sum(vd[:2])/2,i));ds_cent.append((dist(q,cents[i]),i))
 ds_set.sort();ds_cent.sort()
 b=ds_set[0];r=ds_set[1]; margin=r[0]-b[0]; u=max(0,min(1,1-margin/0.025))
 cb=ds_cent[0];cr=ds_cent[1];cm=cr[0]-cb[0];cu=max(0,min(1,1-cm/0.025))
 return b[1],u,cb[1],cu

def run(seed,hard=False):
 r=random.Random(seed);bs=bases(seed);sets=[];cents=[]
 for b in bs:
  views=[sig(tf(b,r,'clean')) for _ in range(5)]+[sig(tf(b,r,'view')) for _ in range(14)]
  sets.append(views);cents.append(centroid(views))
 # learn generic persistence pressure from continuous development
 bias=.55
 for _ in range(300):
  e=r.randrange(len(bs));prior=e
  for kind in ('view','occlusion','compound'):
   ps,us,pc,uc=classify(sig(tf(bs[e],r,kind)),sets,cents)
   current=ps if us<uc else pc;u=min(us,uc)
   keep=prior if u+bias>=1.18 else current
   bias=max(.05,min(.95,bias+(.0018 if keep==e else -.0032)))
 ok=occ=switchok=switchtot=active=0;total=0
 for _ in range(120):
  e=r.randrange(len(bs));prior=-1
  for t,kind in enumerate(['view','view','occlusion','compound','view']):
   truth=e
   if hard and t==3 and r.random()<.15:e=(e+1+r.randrange(len(bs)-1))%len(bs);truth=e
   elif (not hard) and t==4 and r.random()<.25:e=(e+1+r.randrange(len(bs)-1))%len(bs);truth=e
   ps,us,pc,uc=classify(sig(tf(bs[truth],r,kind)),sets,cents)
   # visible evidence: multi-view set is better for switching. information-loss: continuity + centroid.
   if kind=='view': current,u=ps,us
   else: current,u=pc,uc
   chosen=current
   if prior>=0 and kind in ('occlusion','compound') and u+bias>=1.05:chosen=prior
   # generic active reinspection only when current observation is ambiguous and action is available
   if u>=.72:
    active+=1
    ps2,us2,pc2,uc2=classify(sig(tf(bs[truth],r,'view')),sets,cents)
    if us2<.72: chosen=ps2;u=us2
   good=chosen==truth;ok+=good;total+=1
   if kind in ('occlusion','compound'):occ+=good
   if prior>=0 and truth!=prior:switchtot+=1;switchok+=good
   prior=chosen
 return {'accuracy':ok/total,'occlusion_compound':occ/(120*2),'switch_accuracy':switchok/max(1,switchtot),'active_reinspection_rate':active/total,'persistence_bias':bias,'frames':total}
def main():
 seeds=range(52001,52005);nom=[run(s,False) for s in seeds];hard=[run(s,True) for s in seeds]
 summ={k:statistics.mean(x[k] for x in nom) for k in ('accuracy','occlusion_compound','switch_accuracy','active_reinspection_rate')}
 summ.update({'hard_'+k:statistics.mean(x[k] for x in hard) for k in ('accuracy','occlusion_compound','switch_accuracy','active_reinspection_rate')})
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','nominal':nom,'post100_challenge':hard,'summary':summ}
 (ROOT/'results/entity_temporal_hybrid.json').write_text(json.dumps(out,indent=2));print(json.dumps(summ,indent=2))
if __name__=='__main__':main()
