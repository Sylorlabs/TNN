#!/usr/bin/env python3
import json,random,statistics,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
W=12; M=14

def templates(seed):
 r=random.Random(seed);return [[m*170+i*7+r.randrange(-4,5) for i in range(W)] for m in range(M)]
def render(tpl,dur,r,noise):
 out=[]
 for j in range(dur):
  src=min(W-1,(j*W)//dur);out.append(tpl[src]+r.randrange(-noise,noise+1))
 return out
def dist(samples,start,dur,tpl):
 if start+dur>len(samples):return 10**18
 return sum(abs(samples[start+(i*dur)//W]-tpl[i]) for i in range(W))
def decode(samples,tpls,means,mind,maxd):
 pos=0;out=[]
 while pos<len(samples) and len(out)<100:
  best=None
  for m,t in enumerate(tpls):
   for d in range(mind,maxd+1):
    if pos+d>len(samples):continue
    sc=dist(samples,pos,d,t)+abs(d-means[m])*3
    if best is None or sc<best[0]:best=(sc,m,d)
  if best is None:break
  _,m,d=best;out.append(m);pos+=d
 return out
def edit_acc(a,b):
 n,m=len(a),len(b);dp=list(range(m+1))
 for i,x in enumerate(a,1):
  nd=[i]+[0]*m
  for j,y in enumerate(b,1):nd[j]=min(dp[j]+1,nd[j-1]+1,dp[j-1]+(x!=y))
  dp=nd
 return max(0,1-dp[m]/max(1,n))
def trial(seed,noise):
 r=random.Random(seed);tpls=templates(seed);means=[12+r.randrange(-1,2) for _ in range(M)]
 # training-derived means from 12 examples/motif
 obs=[]
 for m in range(M):
  ds=[r.randrange(9,16) for _ in range(12)];obs.append(round(sum(ds)/len(ds)))
 correct=[];vad=[]
 for q in range(180):
  truth=[r.randrange(M) for _ in range(r.randrange(4,11))];chunks=[];bounds=[]
  for x in truth:
   d=r.randrange(9,16);chunks+=render(tpls[x],d,r,noise);bounds.append((len(chunks)-d,d))
  pred=decode(chunks,tpls,obs,8,17);correct.append(edit_acc(truth,pred))
  # VAD/reference boundary control receives true boundaries, then motif classification only.
  vp=[]
  for st,d in bounds:vp.append(min(range(M),key=lambda mm:dist(chunks,st,d,tpls[mm])))
  vad.append(edit_acc(truth,vp))
 return {'no_vad':statistics.mean(correct),'boundary_control':statistics.mean(vad),'examples':len(correct)}
def hard_trial(seed):
 r=random.Random(seed);tpls=templates(seed);obs=[12 for _ in range(M)];scores=[]
 for q in range(220):
  truth=[r.randrange(M) for _ in range(r.randrange(6,15))];samples=[]
  for idx,x in enumerate(truth):
   d=r.randrange(6,23);chunk=render(tpls[x],d,r,75)
   # crude coarticulation: blend first/last two samples with neighbors when available
   if samples and chunk:
    for k in range(min(2,len(chunk))):chunk[k]=(chunk[k]+samples[-1])//2
   samples+=chunk
  pred=decode(samples,tpls,obs,5,24);scores.append(edit_acc(truth,pred))
 return statistics.mean(scores)

def main():
 rows=[]
 for s in range(71001,71011):
  rows.append({'clean':trial(s,12),'noise':trial(s+100,35)})
 summ={
 'clean_no_vad':statistics.mean(x['clean']['no_vad'] for x in rows),
 'clean_control':statistics.mean(x['clean']['boundary_control'] for x in rows),
 'noise_no_vad':statistics.mean(x['noise']['no_vad'] for x in rows),
 'noise_control':statistics.mean(x['noise']['boundary_control'] for x in rows),
 'hard_no_vad':statistics.mean(hard_trial(s) for s in range(72001,72011)),
 }
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','rows':rows,'summary':summ}
 (ROOT/'results/acoustic_reference.json').write_text(json.dumps(out,indent=2));print(json.dumps(summ,indent=2))
if __name__=='__main__':main()
