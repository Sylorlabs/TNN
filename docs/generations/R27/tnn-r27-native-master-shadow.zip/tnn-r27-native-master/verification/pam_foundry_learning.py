#!/usr/bin/env python3
from __future__ import annotations
import json,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
# protected generic primitives have physical effects; TNN does not see this evaluator table.
CAP={
1:(3,2,1,0,0,-1), # local
2:(8,1,2,1,1,-3), # recurrence
3:(7,0,1,0,5,-2), # delay
4:(1,1,2,8,0,-1), # gate
5:(0,2,8,1,0,-1), # norm
6:(5,1,3,0,3,-2), # accum
7:(6,3,2,1,2,-3), # predict
8:(0,2,1,8,0,-2), # compete
9:(2,0,1,1,9,-2), # memory port
10:(2,9,2,1,0,-4),# cross scale
}
F=6; OPS=10

def world(r):
 # telemetry dimensions: temporal, spatial, noise/uncertainty, routing, memory, resource scarcity
 return [r.randrange(0,11) for _ in range(5)]+[r.randrange(0,8)]
def graph_score(g,w):
 # capability is max+complementarity, cost penalized more when resources scarce
 caps=[0]*5;cost=0
 for op in g:
  c=CAP[op]
  for i in range(5):caps[i]+=c[i]
  cost+=-c[5]
 benefit=sum(min(12,caps[i])*w[i] for i in range(5))
 # diversity bonus rewards complementary circuitry but is generic
 benefit+=len(set(g))*2
 return benefit-cost*(2+w[5])
def choose_graph(weights,w,r,step,n=7):
 g=[]
 for slot in range(n):
  if step<100 and r.random()<.22:op=r.randrange(1,OPS+1)
  else:
   def val(o):
    base=sum(weights[o-1][i]*w[i] for i in range(F))
    repeat=g.count(o)
    return base-repeat*18 + (2 if o not in g else 0)
   op=max(range(1,OPS+1),key=val)
  g.append(op)
 return g

def train(seed,steps=900):
 r=random.Random(seed);weights=[[0.0]*F for _ in range(OPS)]
 hist=[]
 for step in range(steps):
  w=world(r);g=choose_graph(weights,w,r,step,4+r.randrange(5));score=graph_score(g,w)
  # TNN shadow-ablates each operation to assign local causal credit.
  credits=[]
  for idx,op in enumerate(g):
   ab=g[:idx]+g[idx+1:]
   credit=score-graph_score(ab,w)
   credits.append(credit)
   for i in range(F):weights[op-1][i]+=0.0015*credit*w[i]
  rg=[r.randrange(1,OPS+1) for _ in g];delta=score-graph_score(rg,w)
  hist.append(delta)
 return weights,hist
def eval(seed,weights,n=1500):
 r=random.Random(seed);learn=[];rand=[]
 for step in range(n):
  w=world(r);g=choose_graph(weights,w,r,9999+step,6);rg=[r.randrange(1,OPS+1) for _ in range(6)]
  learn.append(graph_score(g,w));rand.append(graph_score(rg,w))
 return {'learned_mean':statistics.mean(learn),'random_mean':statistics.mean(rand),'gain':statistics.mean(learn)-statistics.mean(rand),'learned_win_rate':sum(a>b for a,b in zip(learn,rand))/n,'trials':n}
def main():
 ws=[]
 for s in range(61001,61006):ws.append(train(s)[0])
 mw=[[statistics.mean(w[o][i] for w in ws) for i in range(F)] for o in range(OPS)]
 rows=[eval(s,mw) for s in range(62001,62011)]
 summ={k:statistics.mean(x[k] for x in rows) for k in ('learned_mean','random_mean','gain','learned_win_rate')}
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','hidden_seeds':10,'summary':summ,'rows':rows,'learned_weights':mw}
 (ROOT/'results/pam_foundry_learning.json').write_text(json.dumps(out,indent=2));print(json.dumps(summ,indent=2))
if __name__=='__main__':main()
