#!/usr/bin/env python3
"""External reference validator for TNN R27 native-master Zag architecture.

This is NOT TNN cognition and is NOT native Zag execution. It independently checks
algorithmic contracts and experiment fairness while the official znc binary is
unavailable in this sandbox.
"""
from __future__ import annotations
import ast, hashlib, json, math, random, re, statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src/tnn_r27_native_master.zag'
OUT=ROOT/'results/reference_validation.json'

MEM_NONE,MEM_SHORT,MEM_WORK,MEM_LONG,MEM_EXACT,MEM_COLD=0,1,2,3,4,5
FAIL_NONE,FAIL_UNDERTRAINED,FAIL_TEACHER,FAIL_MEMORY,FAIL_ROUTING,FAIL_REPRESENTATION,FAIL_INTERFERENCE,FAIL_RESOURCE=range(8)

def clamp(x,a,b): return max(a,min(b,x))
def mem_value(novelty,uncertainty,causal,source,retrieval,contradiction,regret,cost):
    return novelty*3+uncertainty*2+causal*4+source*2+retrieval*3+contradiction*4+regret*5-cost

def choose_memory(novelty,uncertainty,causal,source,retrieval,contradiction,regret,cost):
    v=mem_value(novelty,uncertainty,causal,source,retrieval,contradiction,regret,cost)
    if regret>=7 or contradiction>=8 or causal>=9 or v>=78: return MEM_EXACT
    if v>=52:return MEM_LONG
    if v>=34:return MEM_COLD
    if uncertainty>=7 or retrieval>=6:return MEM_WORK
    if v>=14:return MEM_SHORT
    return MEM_NONE

def diagnose(curve,immediate,delayed,evidence_exists,route_selected,representation_separable,regression,resource_sat):
    if regression>30:return FAIL_INTERFERENCE
    if resource_sat:return FAIL_RESOURCE
    if immediate-delayed>=250:return FAIL_MEMORY
    if evidence_exists and not route_selected:return FAIL_ROUTING
    if not representation_separable:return FAIL_REPRESENTATION
    if len(curve)>=3 and abs(curve[-1]-curve[-2])<=15 and curve[-1]<900:return FAIL_TEACHER
    if len(curve)>=2 and curve[-1]-curve[-2]>15:return FAIL_UNDERTRAINED
    return FAIL_NONE

def source_audit(text):
    required=['trace_emit','choose_memory','foundry_create','foundry_clone_mutate','foundry_decide','entity_best','entity_should_merge','entity_should_split','effect_learn','name_bind','testimony_accept','choose_observation','diagnose_failure']
    forbidden=['YOLO','CLIP','SAM','transformer runtime','object detector','category_name_table','english_dictionary']
    return {
        'required_functions':{x: bool(re.search(r'fn\s+'+re.escape(x)+r'\s*\(',text)) for x in required},
        'forbidden_runtime_markers':{x:(x.lower() in text.lower()) for x in forbidden},
        'balanced_braces':text.count('{')==text.count('}'),
        'source_sha256':hashlib.sha256(text.encode()).hexdigest(),
        'line_count':len(text.splitlines()),
    }

def memory_pressure(seed):
    rng=random.Random(seed)
    N=5000
    rows=[]
    for i in range(N):
        novelty=rng.randrange(10); uncertainty=rng.randrange(10); causal=rng.randrange(10); source=rng.randrange(10)
        retrieval=rng.randrange(6); contradiction=rng.randrange(10) if rng.random()<.08 else rng.randrange(3); regret=0; cost=rng.randrange(2,10)
        # Hidden future importance is stochastic and only partially predictable from current evidence.
        future_score=causal*4+novelty*2+contradiction*4+source+uncertainty+rng.randrange(-12,13)
        future= future_score>=53 or rng.random()<0.025
        exact_needed=future and (contradiction>=7 or causal>=8 or rng.random()<.35)
        action=choose_memory(novelty,uncertainty,causal,source,retrieval,contradiction,regret,cost)
        rows.append((action,future,exact_needed))
    storage_cost={MEM_NONE:0,MEM_SHORT:1,MEM_WORK:3,MEM_LONG:5,MEM_EXACT:12,MEM_COLD:2}
    def score(policy):
        retained=exact=cost=0; relevant=exact_total=0
        for j,(a,f,e) in enumerate(rows):
            p=policy(j,a)
            cost+=storage_cost[p]
            if f:
                relevant+=1
                if p in (MEM_WORK,MEM_LONG,MEM_EXACT,MEM_COLD):retained+=1
            if e:
                exact_total+=1
                if p==MEM_EXACT:exact+=1
        return {'relevant_recall':retained/max(1,relevant),'exact_recall':exact/max(1,exact_total),'storage':cost,'relevant':relevant,'exact_needed':exact_total}
    adaptive=score(lambda _,a:a)
    exactall=score(lambda *_:MEM_EXACT)
    structured=score(lambda *_:MEM_LONG)
    fifo=score(lambda j,a: MEM_EXACT if j>=N-500 else MEM_NONE)
    return {'adaptive':adaptive,'exact_all':exactall,'structured_all':structured,'fifo_recent':fifo}

def make_latent_entities(seed,n=24,dim=8):
    rng=random.Random(seed)
    base=[]
    for e in range(n):
        # separated identities in generic sensory latent space
        base.append([rng.randrange(120,880)+e*7 for _ in range(dim)])
    return base

def view(base,rng,severity=1,compound=False):
    d=[]
    global_shift=rng.randrange(-25,26)*severity
    scale=1000+rng.randrange(-80,81)*severity
    for x in base:
        noise=rng.randrange(-18,19)*severity
        if compound: noise+=rng.randrange(-35,36)
        d.append((x*scale)//1000+global_shift+noise)
    return d

def invariant_normalize(v):
    m=sum(v)/len(v); centered=[x-m for x in v]
    norm=math.sqrt(sum(x*x for x in centered))+1e-9
    return [int(x*1000/norm) for x in centered]

def l1(a,b): return sum(abs(x-y) for x,y in zip(a,b))

def identity_curve(seed):
    rng=random.Random(seed); bases=make_latent_entities(seed)
    doses=[1,2,4,8,16,32]
    out=[]
    for dose in doses:
        mem=[]
        for b in bases:
            vs=[invariant_normalize(view(b,rng,1,False)) for _ in range(dose)]
            centroid=[sum(v[k] for v in vs)//dose for k in range(len(b))]
            mem.append(centroid)
        clean=noisy=reject=0; total=0
        for e,b in enumerate(bases):
            for _ in range(8):
                q=invariant_normalize(view(b,rng,2,False)); pred=min(range(len(mem)),key=lambda j:l1(q,mem[j])); clean+=pred==e
                qn=invariant_normalize(view(b,rng,3,True)); predn=min(range(len(mem)),key=lambda j:l1(qn,mem[j])); noisy+=predn==e
                other=(e+1+rng.randrange(len(bases)-1))%len(bases); qo=invariant_normalize(view(bases[other],rng,2,False)); predo=min(range(len(mem)),key=lambda j:l1(qo,mem[j])); reject+=predo!=e
                total+=1
        out.append({'dose':dose,'clean':clean/total,'compound':noisy/total,'different_reject':reject/total})
    return out

def name_noise(seed):
    rng=random.Random(seed); motifs=[]
    for e in range(40): motifs.append(10000+e*170+rng.randrange(-20,21))
    clean=noisy=0; total=0
    for e,m in enumerate(motifs):
        for _ in range(20):
            q=m+rng.randrange(-20,21); pred=min(range(len(motifs)),key=lambda j:abs(q-motifs[j])); clean+=pred==e
            q2=m+rng.randrange(-80,81); pred2=min(range(len(motifs)),key=lambda j:abs(q2-motifs[j])); noisy+=pred2==e; total+=1
    return {'clean':clean/total,'late_noise':noisy/total,'trials':total}

def sibling(seed):
    rng=random.Random(seed); trials=1000; accepted_true=accepted_echo=correct_after_conflict=0
    for _ in range(trials):
        true_rel=rng.randrange(550,951); echo_rel=rng.randrange(400,851)
        true_weight=true_rel*1000//1000+500 # local verification
        echo_weight=echo_rel*(1000//5)//1000 # 5 copies, one lineage
        at=(true_weight>=650)
        ae=(echo_weight>=650)
        accepted_true+=at; accepted_echo+=ae
        contradiction=900
        final_true=at and not (ae and contradiction<700)
        correct_after_conflict+=final_true
    return {'verified_true_accept':accepted_true/trials,'echo_false_accept':accepted_echo/trials,'truth_after_conflict':correct_after_conflict/trials,'trials':trials}

def failure_attribution():
    cases=[
        ([200,510,700,820],820,810,1,1,1,0,0,FAIL_UNDERTRAINED),
        ([450,470,468,472],472,470,1,1,1,0,0,FAIL_TEACHER),
        ([900,930,950,955],950,400,1,1,1,0,0,FAIL_MEMORY),
        ([600,610,612,611],611,600,1,0,1,0,0,FAIL_ROUTING),
        ([600,610,612,611],611,600,0,0,0,0,0,FAIL_REPRESENTATION),
        ([800,820,830,700],700,690,1,1,1,150,0,FAIL_INTERFERENCE),
        ([600,650,670,671],671,665,1,1,1,0,1,FAIL_RESOURCE),
    ]
    got=[]
    for c in cases:
        pred=diagnose(*c[:-1]);got.append((pred,c[-1]))
    return {'correct':sum(a==b for a,b in got),'total':len(got),'pairs':got}

def audit_previous_integrated():
    p=Path('/mnt/data/tnn-r27-full-work/src/r27_full_completion.py')
    txt=p.read_text()
    # Strong structural evidence of target mismatch: identity trained on `train`, integrated targets `heldout`.
    train_fit=bool(re.search(r'_fit_identity\(encoder,\s*train,',txt))
    held_targets=bool(re.search(r'targets\s*=\s*physical_payload\["groups"\]\["heldout"\]',txt))
    scalar_sibling=bool(re.search(r'sibling_clean\s*=\s*sibling\["interactive_description_plus_discriminating_question"\]\s*>=\s*\.75',txt))
    return {
        'identity_fit_uses_train_entities':train_fit,
        'integrated_identity_targets_are_heldout_entities':held_targets,
        'changed_view_identity_test_is_actually_unseen_identity':train_fit and held_targets,
        'sibling_result_collapsed_from_global_threshold_not_per_target_teaching':scalar_sibling,
        'verdict':'PREVIOUS_0_PERCENT_INTEGRATED_IDENTITY_INVALID_AS_CHANGED_VIEW_TEST' if train_fit and held_targets else 'NO_STRUCTURAL_MISMATCH_FOUND'
    }

def integrated_reference(seed):
    rng=random.Random(seed)
    curve=identity_curve(seed)
    best=curve[-1]
    name=name_noise(seed+99); social=sibling(seed+77)
    # World/affordance: entity-specific action consequences learned from 16 observations/action.
    entities=30; actions=5; correct=correct_noisy=total=0
    for e in range(entities):
        latent=[rng.randrange(0,100) for _ in range(actions)]
        learned=[]
        for a in range(actions):
            obs=[latent[a]+rng.randrange(-8,9) for _ in range(16)]
            learned.append(sum(obs)/len(obs))
        truth=max(range(actions),key=lambda a:latent[a]); pred=max(range(actions),key=lambda a:learned[a]);correct+=pred==truth
        noisy=[x+rng.randrange(-12,13) for x in learned]; predn=max(range(actions),key=lambda a:noisy[a]);correct_noisy+=predn==truth;total+=1
    afford={'clean':correct/total,'late_noise':correct_noisy/total}
    components={
        'name_clean':name['clean'],'name_noise':name['late_noise'],
        'identity_clean':best['clean'],'identity_noise':best['compound'],
        'different_reject':best['different_reject'],
        'affordance_clean':afford['clean'],'affordance_noise':afford['late_noise'],
        'sibling_verified_truth':social['truth_after_conflict'],
    }
    # Product is intentionally strict proxy; full scenario pass requires every component =1.
    return {'components':components,'full_all_100':all(abs(v-1.0)<1e-12 for v in components.values()),'min_component':min(components.values())}

def main():
    text=SRC.read_text()
    seeds=[271901,271902,271903,271904,271905,271906,271907,271908,271909,271910]
    result={
        'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION',
        'source_audit':source_audit(text),
        'previous_integrated_audit':audit_previous_integrated(),
        'memory_pressure':[memory_pressure(s) for s in seeds[:5]],
        'identity_learning_curves':[identity_curve(s) for s in seeds],
        'name_noise':[name_noise(s) for s in seeds],
        'sibling_provenance':[sibling(s) for s in seeds],
        'failure_attribution':failure_attribution(),
        'integrated_reference':[integrated_reference(s) for s in seeds],
    }
    OUT.write_text(json.dumps(result,indent=2))
    print(json.dumps({
        'source_sha256':result['source_audit']['source_sha256'],
        'previous_integrated_verdict':result['previous_integrated_audit']['verdict'],
        'failure_attribution':result['failure_attribution'],
        'identity_final_clean_mean':statistics.mean(r[-1]['clean'] for r in result['identity_learning_curves']),
        'identity_final_noise_mean':statistics.mean(r[-1]['compound'] for r in result['identity_learning_curves']),
        'name_clean_mean':statistics.mean(r['clean'] for r in result['name_noise']),
        'name_noise_mean':statistics.mean(r['late_noise'] for r in result['name_noise']),
        'integrated_min_mean':statistics.mean(r['min_component'] for r in result['integrated_reference']),
        'integrated_full_100_count':sum(r['full_all_100'] for r in result['integrated_reference']),
    },indent=2))
if __name__=='__main__':main()
