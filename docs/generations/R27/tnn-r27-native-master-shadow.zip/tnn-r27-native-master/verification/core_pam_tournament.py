#!/usr/bin/env python3
from __future__ import annotations
import json, math, random, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def latent(seed,n=36,d=12):
    rng=random.Random(seed)
    return [[rng.randrange(100,900)+e*11+rng.randrange(-20,21) for _ in range(d)] for e in range(n)]

def transform(v,rng,condition):
    x=list(v);d=len(x)
    shift=rng.randrange(d)
    if condition in ('view','occlusion','compound'):
        x=x[shift:]+x[:shift]
    if condition=='hard_view':
        p=list(range(d));rng.shuffle(p);x=[x[i] for i in p]
    scale=rng.randrange(820,1181);off=rng.randrange(-70,71)
    x=[z*scale/1000+off for z in x]
    noise={'clean':8,'view':18,'hard_view':18,'scale_light':22,'occlusion':18,'compound':42}[condition]
    x=[z+rng.uniform(-noise,noise) for z in x]
    if condition in ('occlusion','compound'):
        k=max(1,d//3);idx=rng.sample(range(d),k);m=sum(x)/d
        for i in idx:x[i]=m+rng.uniform(-12,12)
    return x

def norm(v):
    m=sum(v)/len(v);c=[x-m for x in v];s=math.sqrt(sum(x*x for x in c))+1e-9
    return [x/s for x in c]

def raw(v): return norm(v)
def sorted_sig(v): return sorted(norm(v))
def pair_sig(v):
    n=norm(v);p=[]
    for i in range(len(n)):
        for j in range(i+1,len(n)):p.append(abs(n[i]-n[j]))
    p.sort();return p

def hybrid(v):
    n=norm(v);s=sorted(n);p=pair_sig(v)
    # retain broad distribution and relational structure; no task labels.
    take=[p[int(i*(len(p)-1)/15)] for i in range(16)]
    moments=[sum(abs(x)**q for x in n)/len(n) for q in (1,2,3,4)]
    return s+take+moments

def dist(a,b):return sum((x-y)*(x-y) for x,y in zip(a,b))
def centroid(rows):return [sum(x[i] for x in rows)/len(rows) for i in range(len(rows[0]))]

def eval_candidate(seed,fn,dose):
    rng=random.Random(seed);bases=latent(seed)
    mem=[]
    for b in bases:
        mem.append(centroid([fn(transform(b,rng,'clean')) for _ in range(dose)] + [fn(transform(b,rng,'view')) for _ in range(dose)]))
    scores={c:[0,0] for c in ('clean','view','hard_view','scale_light','occlusion','compound')}
    for e,b in enumerate(bases):
        for c in scores:
            for _ in range(4):
                q=fn(transform(b,rng,c));pred=min(range(len(mem)),key=lambda j:dist(q,mem[j]));scores[c][0]+=pred==e;scores[c][1]+=1
    return {c:a/b for c,(a,b) in scores.items()}

def main():
    candidates={'raw_ordered':raw,'sorted_normalized':sorted_sig,'pairwise_relational':pair_sig,'hybrid_relational':hybrid}
    seeds=list(range(33001,33011));doses=(1,2,4,8,16)
    out={}
    for name,fn in candidates.items():
        out[name]={}
        for dose in doses:
            rows=[eval_candidate(s,fn,dose) for s in seeds]
            out[name][str(dose)]={k:statistics.mean(r[k] for r in rows) for k in rows[0]}
            out[name][str(dose)]['worst']=min(out[name][str(dose)][k] for k in rows[0])
    Path(ROOT/'results/core_pam_tournament.json').write_text(json.dumps(out,indent=2))
    for name in out:
        print(name,out[name]['16'])
if __name__=='__main__':main()
