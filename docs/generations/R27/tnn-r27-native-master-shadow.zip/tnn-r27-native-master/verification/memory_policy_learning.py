#!/usr/bin/env python3
from __future__ import annotations
import json,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ACTIONS=6; F=8
COST=[0,1,3,5,12,2]

def feats(x):
    novelty,unc,causal,source,retr,contr,regret,cost=x
    return [novelty,unc,causal,source,retr,contr,regret,10-cost]

def future_truth(x,rng):
    novelty,unc,causal,source,retr,contr,regret,cost=x
    score=causal*5+contr*5+novelty*2+source+unc+rng.randrange(-15,16)
    relevant=score>=58 or rng.random()<.02
    exact=relevant and (causal>=8 or contr>=7 or rng.random()<.28)
    return relevant,exact

def reward(action,relevant,exact):
    retained=action in (2,3,4,5)
    exactok=action==4
    r=0
    if relevant:r += 12 if retained else -18
    else:r += 2 if action in (0,1,5) else -2
    if exact:r += 22 if exactok else -20
    r -= COST[action]*2
    return r

def train(seed,episodes=30000):
    rng=random.Random(seed);w=[[0]*F for _ in range(ACTIONS)]
    counts=[0]*ACTIONS
    for step in range(episodes):
        x=(rng.randrange(10),rng.randrange(10),rng.randrange(10),rng.randrange(10),rng.randrange(6),rng.randrange(10) if rng.random()<.1 else rng.randrange(3),0,rng.randrange(2,10))
        f=feats(x)
        eps=max(.03,.35*(1-step/episodes))
        if rng.random()<eps:a=rng.randrange(ACTIONS)
        else:a=max(range(ACTIONS),key=lambda z:sum(w[z][i]*f[i] for i in range(F)))
        rel,exact=future_truth(x,rng);rr=reward(a,rel,exact);counts[a]+=1
        # bounded contextual bandit update, with action-specific baseline from cost
        rate=0.0025
        for i in range(F): w[a][i]+=rate*rr*f[i]/10
    return w,counts

def evaluate(seed,w,n=12000):
    rng=random.Random(seed);stats={k:{'reward':0,'storage':0,'rel':0,'relhit':0,'exact':0,'exacthit':0} for k in ('learned','exact_all','long_all','fifo','random')}
    for j in range(n):
        x=(rng.randrange(10),rng.randrange(10),rng.randrange(10),rng.randrange(10),rng.randrange(6),rng.randrange(10) if rng.random()<.1 else rng.randrange(3),0,rng.randrange(2,10));f=feats(x)
        rel,exact=future_truth(x,rng)
        pol={
          'learned':max(range(ACTIONS),key=lambda a:sum(w[a][i]*f[i] for i in range(F))),
          'exact_all':4,'long_all':3,'fifo':4 if j>=n-1200 else 0,'random':rng.randrange(ACTIONS)
        }
        for k,a in pol.items():
            s=stats[k];s['reward']+=reward(a,rel,exact);s['storage']+=COST[a]
            if rel:s['rel']+=1;s['relhit']+=a in (2,3,4,5)
            if exact:s['exact']+=1;s['exacthit']+=a==4
    for s in stats.values():
        s['relevant_recall']=s['relhit']/max(1,s['rel']);s['exact_recall']=s['exacthit']/max(1,s['exact'])
        s['reward_per_episode']=s['reward']/n;s['storage_per_episode']=s['storage']/n
    return stats

def main():
    train_seeds=range(41001,41006); eval_seeds=range(42001,42011)
    weights=[];counts=[]
    for s in train_seeds:
        w,c=train(s);weights.append(w);counts.append(c)
    # ensemble learned policy via mean weights; state itself would keep one learned policy per brain.
    mw=[[statistics.mean(w[a][i] for w in weights) for i in range(F)] for a in range(ACTIONS)]
    rows=[evaluate(s,mw) for s in eval_seeds]
    summary={}
    for k in rows[0]:
        summary[k]={m:statistics.mean(r[k][m] for r in rows) for m in ('reward_per_episode','storage_per_episode','relevant_recall','exact_recall')}
    out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','train_action_counts':counts,'mean_weights':mw,'hidden_seeds':list(eval_seeds),'summary':summary,'rows':rows}
    (ROOT/'results/memory_policy_learning.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
