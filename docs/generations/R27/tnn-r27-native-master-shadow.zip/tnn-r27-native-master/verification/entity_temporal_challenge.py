#!/usr/bin/env python3
from __future__ import annotations
import json,math,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def bases(seed,n=40,d=12):
 r=random.Random(seed);return [[r.randrange(100,900)+e*13+r.randrange(-25,26) for _ in range(d)] for e in range(n)]
def tf(v,r,kind):
 x=list(v);d=len(x);sh=r.randrange(d);x=x[sh:]+x[:sh]
 scale=r.randrange(820,1181);off=r.randrange(-70,71);noise={'view':18,'occlusion':22,'compound':45,'clean':8}[kind]
 x=[z*scale/1000+off+r.uniform(-noise,noise) for z in x]
 if kind in ('occlusion','compound'):
  m=sum(x)/d
  for i in r.sample(range(d),d//3):x[i]=m+r.uniform(-12,12)
 return x
def sig(v):
 m=sum(v)/len(v);c=[x-m for x in v];span=max(c)-min(c)+1e-9;return sorted(x/span for x in c)
def dist(a,b):return sum((x-y)**2 for x,y in zip(a,b))
def centroid(xs):return [sum(x[i] for x in xs)/len(xs) for i in range(len(xs[0]))]
def classify(q,mem):
 ds=[]
 for i,views in enumerate(mem):
  vd=sorted(dist(q,m) for m in views)
  ds.append((sum(vd[:3])/min(3,len(vd)),i))
 ds.sort();best=ds[0];runner=ds[1]
 margin=runner[0]-best[0]
 # uncertainty 1 when margin weak, 0 when strong
 u=max(0.0,min(1.0,1-margin/0.020))
 return best[1],u,best[0]
def run(seed,hard=False):
 r=random.Random(seed);bs=bases(seed);mem=[]
 for b in bs:mem.append([sig(tf(b,r,'clean')) for _ in range(4)]+[sig(tf(b,r,'view')) for _ in range(12)])
 total=ok=occ_ok=switch_ok=switch_total=0
 bias=.72
 # learn persistence bias from development continuity episodes using prediction outcomes, not a hard phase schedule
 for _ in range(600):
  e=r.randrange(len(bs));prior=e
  for kind in ('view','occlusion'):
   pred,u,_=classify(sig(tf(bs[e],r,kind)),mem);keep = prior if u+bias>=1.15 else pred
   good=keep==e; bias=max(.1,min(.95,bias+(.002 if good else -.003)))
 # hidden sequences
 for _ in range(200):
  e=r.randrange(len(bs));prior=-1
  kinds=['view','view','occlusion','compound','view']
  for t,kind in enumerate(kinds):
   truth=e
   if hard and t==3 and r.random()<.15:
    e=(e+1+r.randrange(len(bs)-1))%len(bs);truth=e # adversarial cut while evidence poor
   elif (not hard) and t==4 and r.random()<.25:
    e=(e+1+r.randrange(len(bs)-1))%len(bs);truth=e # normal cut with strong view evidence
   pred,u,_=classify(sig(tf(bs[truth],r,kind)),mem)
   chosen=pred
   if prior>=0 and u+bias>=1.25:chosen=prior
   # strong evidence must override persistence on ordinary visible cuts
   if kind=='view' and u<.70: chosen=pred
   # active reinspection: ambiguity earns one fresh view before commitment.
   if u>=.70:
    pred2,u2,_=classify(sig(tf(bs[truth],r,'view')),mem)
    if u2<u: pred,u=pred2,u2; chosen=pred2 if u2<.80 else chosen
   good=chosen==truth;ok+=good;total+=1
   if kind in ('occlusion','compound'):occ_ok+=good
   if truth!=prior and prior>=0:switch_total+=1;switch_ok+=good
   prior=chosen
 return {'accuracy':ok/total,'occlusion_compound':occ_ok/(200*2),'switch_accuracy':switch_ok/max(1,switch_total),'learned_persistence_bias':bias,'frames':total,'hard':hard}
def main():
 seeds=range(51001,51006);nom=[run(s,False) for s in seeds];hard=[run(s,True) for s in seeds]
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','nominal':nom,'post100_challenge':hard,
 'summary':{'nominal_accuracy':statistics.mean(x['accuracy'] for x in nom),'nominal_occlusion':statistics.mean(x['occlusion_compound'] for x in nom),'nominal_switch':statistics.mean(x['switch_accuracy'] for x in nom),'hard_accuracy':statistics.mean(x['accuracy'] for x in hard),'hard_occlusion':statistics.mean(x['occlusion_compound'] for x in hard),'hard_switch':statistics.mean(x['switch_accuracy'] for x in hard)}}
 (ROOT/'results/entity_temporal_challenge.json').write_text(json.dumps(out,indent=2));print(json.dumps(out['summary'],indent=2))
if __name__=='__main__':main()
