#!/usr/bin/env python3
from __future__ import annotations
import json,random,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CAP={1:(3,2,1,0,0,-1),2:(8,1,2,1,1,-3),3:(7,0,1,0,5,-2),4:(1,1,2,8,0,-1),5:(0,2,8,1,0,-1),6:(5,1,3,0,3,-2),7:(6,3,2,1,2,-3),8:(0,2,1,8,0,-2),9:(2,0,1,1,9,-2),10:(2,9,2,1,0,-4)}
def world(r):return [r.randrange(0,11) for _ in range(5)]+[r.randrange(0,8)]
def score(g,w,noise=0,r=None):
 caps=[0]*5;cost=0
 for op in g:
  c=CAP[op]
  for i in range(5):caps[i]+=c[i]
  cost+=-c[5]
 b=sum(min(12,caps[i])*w[i] for i in range(5))+len(set(g))*2-cost*(2+w[5])
 if noise and r:b+=r.randrange(-noise,noise+1)
 return b
def mutate(g,r):
 h=list(g); choice=r.randrange(4)
 if choice==0:h[r.randrange(len(h))]=r.randrange(1,11)
 elif choice==1 and len(h)<10:h.insert(r.randrange(len(h)+1),r.randrange(1,11))
 elif choice==2 and len(h)>4:h.pop(r.randrange(len(h)))
 else:r.shuffle(h)
 return h
def evolve(r,w,pop=32,generations=7):
 P=[[r.randrange(1,11) for _ in range(r.randrange(4,9))] for _ in range(pop)]
 for _ in range(generations):
  ranked=sorted(P,key=lambda g:score(g,w,5,r),reverse=True)
  elite=ranked[:8];P=list(elite)
  while len(P)<pop:P.append(mutate(r.choice(elite),r))
 return max(P,key=lambda g:score(g,w,0,r))
def trial(seed,n=1000):
 r=random.Random(seed);learn=[];rand=[];overfit=[]
 for _ in range(n):
  dev=world(r); hidden=[max(0,min(10,x+r.randrange(-2,3))) for x in dev[:5]]+[max(0,min(7,dev[5]+r.randrange(-1,2)))]
  g=evolve(r,dev); rg=[r.randrange(1,11) for _ in range(6)]
  learn.append(score(g,hidden));rand.append(score(rg,hidden));overfit.append(score(g,dev)-score(g,hidden))
 return {'evolved_mean':statistics.mean(learn),'random_mean':statistics.mean(rand),'gain':statistics.mean(learn)-statistics.mean(rand),'win_rate':sum(a>b for a,b in zip(learn,rand))/n,'mean_dev_hidden_gap':statistics.mean(overfit),'trials':n}
def main():
 rows=[trial(s,300) for s in range(63001,63011)]
 summary={k:statistics.mean(x[k] for x in rows) for k in ('evolved_mean','random_mean','gain','win_rate','mean_dev_hidden_gap')}
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','rows':rows,'summary':summary}
 (ROOT/'results/pam_foundry_evolution.json').write_text(json.dumps(out,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
