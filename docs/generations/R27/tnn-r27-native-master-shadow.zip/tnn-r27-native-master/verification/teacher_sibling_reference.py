#!/usr/bin/env python3
from __future__ import annotations
import json,random,statistics,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def gen_case(r,d=12):
 x=[r.uniform(-1,1) for _ in range(d)]
 # hidden grounded relation depends on several interacting generic cues
 y=1 if (1.3*x[0]-1.1*x[3]+.8*x[5]*x[7]+.6*x[9]-0.4*x[10])>0 else 0
 return x,y
class Learner:
 def __init__(self,d=12):self.w=[0.0]*d;self.b=0.0
 def p(self,x):
  z=dot(self.w,x)+self.b;return 1/(1+math.exp(max(-30,min(30,-z))))
 def learn(self,x,y,rate=.12):
  e=y-self.p(x)
  for i in range(len(self.w)):self.w[i]+=rate*e*x[i]
  self.b+=rate*e
 def acc(self,rows):return sum((self.p(x)>=.5)==y for x,y in rows)/len(rows)
def teacher_run(seed,adaptive=True):
 r=random.Random(seed);pool=[gen_case(r) for _ in range(3000)];hidden=[gen_case(r) for _ in range(1200)];L=Learner();curve=[]
 for dose in (8,16,32,64,128,256,512):
  while getattr(L,'n',0)<dose:
   if adaptive:
    # Master can inspect learner confusion, but does not insert weights/answers directly.
    cand=r.sample(pool,80); x,y=max(cand,key=lambda z: 1-abs(L.p(z[0])-.5)*2 + ((L.p(z[0])>=.5)!=z[1])*1.2)
   else:x,y=r.choice(pool)
   L.learn(x,y);L.n=getattr(L,'n',0)+1
  curve.append({'dose':dose,'hidden':L.acc(hidden)})
 return curve

def sibling_trial(seed,interactive=True):
 r=random.Random(seed);d=10
 # Independent sender/receiver learn the same anonymous language convention from disjoint histories.
 # Each motif is a signed relational feature bucket; codebook is learned separately with noise.
 sender_map=[1 if i%2==0 else -1 for i in range(d)]
 receiver_map=[]
 for i in range(d):
  votes=[]
  for _ in range(30):votes.append(sender_map[i] if r.random()<.9 else -sender_map[i])
  receiver_map.append(1 if sum(votes)>=0 else -1)
 total=good=passive=0
 for _ in range(1200):
  candidates=[[r.uniform(-1,1) for _ in range(d)] for _ in range(6)];target=r.randrange(6);t=candidates[target]
  # sender chooses 3 strongest features to describe using learned motif convention
  feats=sorted(range(d),key=lambda i:abs(t[i]),reverse=True)[:3]
  def score(c,fs):
   sc=0
   for i in fs:
    sent_sign=(1 if t[i]>=0 else -1)*sender_map[i]
    recv_sign=sent_sign*receiver_map[i]
    sc += recv_sign*(1 if c[i]>=0 else -1)*abs(c[i])
   return sc
  pred=max(range(6),key=lambda j:score(candidates[j],feats));passive+=pred==target
  if interactive and pred!=target:
   # receiver asks for the feature that maximally separates remaining hypotheses.
   ranked=sorted(range(d),key=lambda i:max(c[i] for c in candidates)-min(c[i] for c in candidates),reverse=True)
   for f in ranked:
    if f not in feats:feats.append(f);break
   pred=max(range(6),key=lambda j:score(candidates[j],feats))
  good+=pred==target;total+=1
 return {'passive':passive/total,'interactive':good/total,'trials':total}
def main():
 seeds=range(81001,81011)
 adaptive=[teacher_run(s,True) for s in seeds];randoms=[teacher_run(s,False) for s in seeds]
 dose=[8,16,32,64,128,256,512]
 teacher={'adaptive':{str(d):statistics.mean(c[i]['hidden'] for c in adaptive) for i,d in enumerate(dose)},'random':{str(d):statistics.mean(c[i]['hidden'] for c in randoms) for i,d in enumerate(dose)}}
 sib=[sibling_trial(s,True) for s in range(82001,82011)]
 summary={'teacher':teacher,'sibling':{'passive':statistics.mean(x['passive'] for x in sib),'interactive':statistics.mean(x['interactive'] for x in sib)}}
 out={'evidence_class':'EXTERNAL_REFERENCE_VALIDATION_NOT_NATIVE_ZAG_EXECUTION','summary':summary,'sibling_rows':sib}
 (ROOT/'results/teacher_sibling_reference.json').write_text(json.dumps(out,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
