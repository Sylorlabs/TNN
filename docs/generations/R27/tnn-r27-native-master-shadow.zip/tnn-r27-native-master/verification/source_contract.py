from pathlib import Path
import hashlib,json,re,sys
root=Path(__file__).resolve().parents[1]; p=root/'src/tnn_r27_native_master.zag'; s=p.read_text()
required=['memory_choose_traced','pam_create_learned_traced','entity_resolve_traced','effect_learn_traced','name_bind_traced','testimony_accept_traced','observation_choose_traced','failure_diagnose_traced','core_relational_signature8','memory_policy_learn','foundry_clone_mutate','entity_persistence_learn']
forbidden=['import torch','import tensorflow','import sklearn','YOLO(','CLIP(','SAM(','english_dictionary','category_name_table']
checks={
 'balanced_braces':s.count('{')==s.count('}'),
 'required_trace_wrappers':all(re.search(r'fn\s+'+x+r'\s*\(',s) for x in required),
 'no_forbidden_runtime_imports':not any(x.lower() in s.lower() for x in forbidden),
 'no_fixed_phase_memory_schedule':'EARLY phase' not in s and 'LEXICAL phase' not in s,
 'tnn_memory_policy_present':'memory_policy_learn' in s,
 'autonomous_pam_foundry_present':'foundry_create' in s and 'foundry_clone_mutate' in s and 'foundry_decide' in s,
 'causal_parent_trace_present':'parent_event' in s and 't_parent' in s,
 'source_sha256':hashlib.sha256(s.encode()).hexdigest(),
 'source_lines':len(s.splitlines()),
}
checks['pass']=all(v for k,v in checks.items() if k not in ('source_sha256','source_lines'))
(root/'results/source_contract.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2));sys.exit(0 if checks['pass'] else 1)
