#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,pickle,sys
ROOT=Path(__file__).resolve().parents[1]
P=Path('/mnt/data/tnn-r27-full-work/state/r27-accepted-state.pkl')
sys.path.insert(0,'/mnt/data/r27_extract/tnn-pre-v1-r27-general-learning/src')
# pickle class module is available from previous extracted release in environment; import fallback
try:
 import r27_experiments
except Exception:
 sys.path.insert(0,'/mnt/data/r27_extract/tnn-pre-v1-r27-general-learning')
 import r27_experiments
obj=pickle.load(open(P,'rb'))
attrs=obj.__dict__
manifest={
 'bridge_class':'EXTERNAL_ENGINEERING_NOT_COGNITION',
 'parent_file_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
 'development_step':int(attrs.get('development_step',-1)),
 'newborn_restarts':int(attrs.get('newborn_restarts',-1)),
 'accepted_state_digest_expected':'562aaaedb5b9ceec2f50482f631992c247cbe50e9f6d2321b811e311ecf73b04',
 'native_source_sha256':hashlib.sha256((ROOT/'src/tnn_r27_native_master.zag').read_bytes()).hexdigest(),
 'migration_status':'BEHAVIORAL_AND_PROVENANCE_BRIDGE_DESIGNED_NATIVE_LOAD_NOT_EXECUTED_NO_ZNC',
 'structural_identity_claim':False,
 'state_preservation_requirements':['exact_archive','provenance','promotion_rollback_history','speech_core_pam','semantic_generator','entity_graph','master_bridge','sibling_history'],
 'promotion_allowed':False,
 'blocker':'official Zag znc binary unavailable in active sandbox; GitHub connector exposes metadata but not binary bytes and local DNS is blocked'
}
(ROOT/'state/state_bridge_manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
