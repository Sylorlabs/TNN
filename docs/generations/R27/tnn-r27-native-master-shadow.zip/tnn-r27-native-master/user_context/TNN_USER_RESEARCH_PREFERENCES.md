# TNN User Research Preferences

**Status:** Living project constraint file  
**Last updated:** 2026-08-20  
**Scope:** TNN research design, implementation, evaluation, promotion, rollback, and reporting.

This file records the user's explicit preferences separately from experimental findings. Future agents should update it when the user states a new preference, correction, boundary, or priority. New entries should preserve the original intent, mark whether the preference is explicit or inferred, and note any experimental evidence that supports or conflicts with it.

## Confirmed preferences

### 1. Minimize hardcoding

**Preference:** Avoid hardcoding whenever a learnable mechanism is feasible. Hardcoding is acceptable for genuinely core infrastructure, immutable safety/verification boundaries, or when strong controlled evidence shows that a hardcoded mechanism is currently necessary and superior.

**Operational consequence:**

- Do not hardcode English grammar, dictionaries, category names, social concepts, object identities, target answers, or task-specific solution rules into mutable TNN cognition.
- Treat hardcoded prostheses as controls, not learner capability.
- Before promoting a hardcoded runtime mechanism, compare it against serious learned candidates using hidden tests, delayed tests, transfer tests, and regression tests.
- Prefer generic substrate mechanisms over named task modules.
- Record every remaining hardcoded component and why it remains.

**Source:** Explicit user instruction on 2026-08-20: prefer no hardcoding when possible; hardcoding should remain only when core/necessary or when real in-depth results justify it.

### 2. Hardcoded teachers are an acceptable special case

**Preference:** A hardcoded Master TNN may be highly capable because it is a teacher working with the base TNN, not a hidden implementation of the learner's final cognition.

**Operational consequence:**

- The Master may know mature English, evaluator identities, curriculum structure, and pedagogy.
- The Master should diagnose the learner's exact confusion, choose grounded examples and minimal contrasts, vary wording/context, request teach-back, test delayed transfer, and withdraw as competence rises.
- Master knowledge must not be copied directly into mutable TNN as dictionaries, named concept modules, target labels, or answer tables.
- Teacher dependence must be measured after withdrawal.
- Direct grounded evidence and the immutable root verifier remain more authoritative than the Master.

**Evidence already established:** Adaptive/grounded Master teaching repeatedly outperformed symbolic yes/no and weaker teaching. R27's stronger Master bridge improved general-to-specific abstraction from 66.67% to 94.44% without a new named social-language module. Earlier work also found a trained TNN teacher could outperform the hardcoded Master on a bounded teaching task.

### 3. Training-first diagnosis

**Preference:** When a result is weak, first determine whether the failure is caused by insufficient data, poor lesson quality, missing contrasts, bad curriculum ordering, inadequate rehearsal, or a weak teacher. Change architecture only when the learning curve or error structure shows that training is no longer the main bottleneck.

**Required diagnosis sequence:**

1. Establish a fixed-architecture baseline.
2. Run quantity/dose curves.
3. Improve teaching quality and targeted contrasts.
4. Test changed contexts, delay, noise, and counterexamples.
5. Classify the residual failure.
6. Try architecture only for a measured plateau, representation mismatch, interference, missing cognitive operation, or resource-allocation failure.
7. Shadow-test and roll back on regression.

### 4. Strong, in-depth experiments rather than weak demonstrations

**Preference:** Use serious tests that can disconfirm the intended claim. Do not promote mechanisms from tiny, favorable, single-seed, or circular evaluations.

**Minimum evidence expectations where feasible:**

- multiple independent seeds;
- development/selection data separated from hidden evaluation;
- meaningful baselines and negative controls;
- hard near-neighbor and counterexample cases;
- delayed retention and teacher withdrawal;
- clean, noisy, changed-context, and interference conditions;
- regression protection for accepted historical capabilities;
- exact provenance and authorship separation;
- preserved failed candidates and negative results;
- fresh-process save/reload verification;
- independent archive extraction and verifier reruns.

### 5. Do not mistake evaluator help for learned cognition

**Preference:** External labels may be used for scoring and a teacher may use them to choose lessons, but evaluator truth must not silently enter mutable learner state.

**Operational consequence:** Report separately:

- what TNN observed, learned, proposed, selected, and retained;
- what the hardcoded Master knew and taught;
- what the researcher/assistant mechanically implemented;
- what the external verifier used only for scoring and promotion.

### 6. Siblings should be real independent learners

**Preference:** Siblings should question, teach, debate, share sourced evidence, and potentially work as a development team while retaining independent identities and histories.

**Operational consequence:**

- Do not merge sibling weights and call that social learning.
- Repeated copies from one origin remain one evidence lineage.
- Sibling information stays provisional until locally verified.
- Questions should target uncertainty or discriminate hypotheses, not request arbitrary extra data.
- Report absolute performance as well as relative gains.

### 7. Protect accepted state and core mechanisms

**Preference:** Continue the same developmental brain; do not restart merely to make an experiment easier. Core PAMs, exact archive, provenance, rollback, and immutable root verification remain protected unless unusually strong evidence justifies replacement.

**Operational consequence:** New mechanisms begin as shadow/non-core candidates. The only canonical checkpoint is changed after promotion gates pass.

### 8. Capability first; compute is secondary but must be accounted for

**Preference:** Do not reject a real capability gain only because it costs more, but do not promote expensive machinery that ties or regresses a simpler mechanism.

### 9. Report claim boundaries plainly

**Preference:** Controlled or generated results must not be renamed as unrestricted camera vision, natural adult speech, teenager/adult English, human superiority, open-ended recursive self-improvement, AHI, or production readiness.

### 10. Preserve terminology and explain acronyms

**Preference:** Use consistent project terminology and expand acronyms when introduced.

## Current decision hierarchy

When deciding whether to promote a mechanism, use this order:

1. hidden capability and transfer;
2. regression safety;
3. teacher-withdrawal and delayed retention;
4. provenance/evaluator-leak audit;
5. robustness under noise and counterexamples;
6. state continuity and deterministic reload;
7. compute/memory cost;
8. conceptual elegance.

A cleaner or more biologically appealing mechanism does not replace a working one unless the evidence supports it.

## Hardcoding ledger rule

Every checkpoint should include a table with:

- hardcoded component;
- location;
- purpose;
- whether it enters mutable cognition;
- learned alternatives tested;
- evidence for retaining it;
- removal/retest trigger.

## Preference update log

| Date | Status | Preference/change | Source |
|---|---|---|---|
| 2026-08-20 | CONFIRMED | Prefer no hardcoding where possible; retain it only for core necessities or after rigorous results justify it. | Direct user message |
| 2026-08-20 | CONFIRMED | Hardcoded Master teachers are acceptable because strong teacher-to-base-TNN training has worked best so far. | Direct user message plus retained R22-R27 evidence |
| 2026-08-20 | CONFIRMED | Use real, in-depth tests rather than weak tests. | Direct user message |
| 2026-08-20 | CONFIRMED | Maintain this living preference file as the conversation continues. | Direct user message |

## Update protocol for future agents

After an explicit user preference message:

1. add or revise the relevant confirmed preference;
2. append one dated row to the update log;
3. distinguish preference from experimental fact;
4. note contradictions rather than silently replacing history;
5. copy the updated file into the next verified release and persistent `/TNN/Research/` library.

## 2026-08-20 update — Native Zag v2, autonomous PAM creation, capability-scale architecture

### 11. Pure Zag v2 implementation path

**Preference:** New TNN architecture and experiments should be implemented natively in Zag v2. Python must not become the implementation path for TNN cognition, PAMs, learning, or self-revision. Python may be used only as external analysis/evaluation glue when absolutely necessary, and such use must never be counted as TNN capability.

**Operational consequence:**
- New PAM lifecycle, sensory learning, architecture-revision machinery, and integrated TNN execution belong in native Zag v2.
- Any result produced only by a Python research surrogate is diagnostic evidence, not a promotable TNN mechanism.
- Native strict compilation, checked-mode parity, deterministic state continuity, and fresh-process verification are required for promotion.

### 12. TNN-created non-core PAMs must be autonomous

**Preference:** Once TNN proposes a non-core PAM, the human/researcher should not have to mechanically implement that PAM. Human implementation is acceptable only for protected core substrate that TNN cannot access.

**Operational consequence:**
- Replace researcher-authored PAM candidate instantiation with a TNN-accessible generative PAM construction system in Zag v2.
- TNN must be able to create, wire, initialize, train, clone, specialize, merge, route, shadow-test, promote, demote, and delete non-core PAMs using its own learned evidence and resource budget.
- The root verifier and protected core PAM substrate remain outside TNN mutation authority.
- PAM proposals must be executable structures, not English suggestions that require a researcher to translate them into source.
- PAM provenance must identify which evidence caused creation, which components were generated, and why promotion/rollback occurred.

### 13. Architecture goal is superior integrated capability, not local benchmark wins

**Preference:** The target is a large integrated architecture with superior capability. Weak integrated scores—especially 0% same-entity changed-view recognition, 0% sibling teaching, and 0% fully integrated success—are unacceptable as an endpoint and should trigger deep investigation into training, representation, routing, memory, PAM/core-PAM limitations, or architecture composition.

**Operational consequence:**
- Optimize for integrated causal capability across identity, naming, affordance, communication, robustness, memory, and self-improvement rather than isolated test scores.
- Diagnose whether failures originate in the core sensory substrate, entity persistence, cross-view invariance, binding, world-model integration, communication grounding, or self-revision machinery.
- Permit larger architecture changes when evidence shows a structural bottleneck; do not confine work to shallow tuning.
- Aim for 100% on the bounded integrated battery, but only count 100% when it survives hidden seeds, changed views, noise, distractors, delay, teacher withdrawal, and regression checks.

### 14. Core PAM redesign is allowed when evidence demands it

**Preference:** Core PAMs are protected from TNN self-mutation, not sacred. If deep tests show the protected core PAM interface prevents robust learning, the researcher may redesign the core and then rerun the complete regression and developmental battery.

**Operational consequence:**
- First distinguish training failure from substrate/interface failure with dose curves and diagnostic probes.
- If changed-view identity remains structurally impossible or information is lost before higher layers can learn, run a serious core-PAM architecture tournament.
- A new core must materially improve broad capability and must not merely overfit the current integrated test.

| Date | Status | Preference/change | Source |
|---|---|---|---|
| 2026-08-20 | CONFIRMED | New implementation path is pure native Zag v2; Python-only cognition experiments are diagnostic, not promotable. | Direct user message |
| 2026-08-20 | CONFIRMED | TNN-created non-core PAMs must be autonomously instantiated and managed without human implementation. | Direct user message |
| 2026-08-20 | CONFIRMED | Protected core PAMs may be redesigned by the researcher if deep evidence shows a substrate bottleneck. | Direct user message |
| 2026-08-20 | CONFIRMED | Goal is a giant integrated architecture with superior capability; weak integrated scores trigger deep architectural investigation. | Direct user message |

## 2026-08-20 update — Memory autonomy, skeptical 100% qualification, and stepwise training diagnosis

### 15. Memory hierarchy is TNN-controlled

**Preference:** Memory autonomy is a core differentiator of TNN. Do not impose a human-authored developmental schedule that slowly phases exact memory away. TNN should choose what enters, stays in, moves between, compresses within, or leaves short-term, working/active, long-term structured, exact episodic, semantic, procedural, sensory, and archival memory.

**Operational consequence:**
- Preserve a protected generic memory substrate, addresses, provenance, integrity checks, and resource limits, but do not hardcode which experiences deserve long-term retention.
- TNN must learn retention, promotion, compression, indexing, replay, retrieval, eviction, duplication, and archival policies from downstream value, uncertainty, future regret, recurrence, novelty, causal usefulness, source reliability, and resource cost.
- Exact raw episodes may remain addressable when affordable; compression must not silently destroy unique information before TNN has evidence that loss is acceptable.
- Different memory forms may coexist. Moving information to structured/semantic/procedural memory does not require deleting the exact episode.
- Memory policies must remain revisable from later regret: if a compressed/evicted detail later proves important, similar future evidence should be protected differently.
- Teacher or researcher may expose memory-management choices and consequences but may not directly choose which ordinary experiences the learner remembers.
- Final tests must include delayed recall, unexpected future relevance, interference, long gaps, save/reload, source conflicts, and resource pressure.

### 16. Treat 100% as a skeptical qualification target

**Preference:** Aim for the highest genuine capability possible, including 100% where the bounded task is actually solved, but never manufacture 100% with easy tests, leakage, memorized test structure, narrow seeds, favorable thresholds, or evaluator-informed learner state.

**Operational consequence:**
- 100% means every declared hidden item in the preregistered bounded battery passed; it does not imply unrestricted real-world perfection.
- Any 100% result must survive fresh hidden seeds, adversarial near-neighbors, changed views, noise, delay, teacher withdrawal, sibling transfer where applicable, save/reload, and historical regression checks.
- Add harder follow-up challenge sets after a nominal 100% pass; if performance collapses, report the capability boundary rather than treating the original 100% as general mastery.
- Keep challenge generation and evaluator labels outside mutable cognition.
- Report Wilson/binomial uncertainty or equivalent uncertainty where sample counts matter, and always state test-set size.
- Never tune directly on the final hidden set. Development failures may guide training/architecture, but the final untouched qualification set remains sealed.

### 17. Diagnose low scores step by step before declaring architecture failure

**Preference:** When performance is low, inspect learning progression step by step and push training quality/quantity until the learning curve is understood. Seek the highest real score possible, while changing architecture when evidence shows a plateau, representation bottleneck, interference, or inaccessible information.

**Operational consequence:**
- Log capability after each curriculum increment rather than only before/after.
- For each failure family, record exposure count, teacher intervention, error class, confidence, memory state, PAM route, and later outcome.
- Run dose curves until gain clearly saturates, reverses, or becomes uneconomical; do not stop at an arbitrary small dose.
- Compare more examples versus better examples, contrasts, counterexamples, active perception, rehearsal, memory-policy changes, and architecture changes.
- Use causal ablations to distinguish: insufficient exposure, poor teaching, forgotten evidence, bad retrieval, core-PAM information loss, non-core-PAM routing, entity-binding error, world-model error, language binding, sibling communication, or verifier/test defect.
- Promote architecture changes only when they improve broad hidden capability and do not merely compensate for inadequate training.

| Date | Status | Preference/change | Source |
|---|---|---|---|
| 2026-08-20 | CONFIRMED | TNN controls its own memory hierarchy and retention/compression choices; no human developmental phase-out schedule. | Direct user message |
| 2026-08-20 | CONFIRMED | 100% is a skeptical bounded qualification target, never a reason to weaken tests or tolerate leakage. | Direct user message |
| 2026-08-20 | CONFIRMED | Low scores require step-by-step training curves and failure attribution before architecture conclusions. | Direct user message |

## 2026-08-20 update — causal traceability / debuggability

### 17. TNN failures must be causally traceable

**Preference:** Native Zag TNN code should be engineered so a weak result can be traced back through the actual causal path rather than inferred from a final score.

**Operational consequence:**
- Every consequential sensory, PAM, routing, entity, memory, world-model, language, social, and architecture-revision decision should emit durable causal provenance.
- Trace records should include step, subsystem/stage, generic reason code, internal subject/candidate ID, evidence strength, confidence/uncertainty, and parent event ID.
- Architecture promotion/rollback must be reconstructable from these records.
- Failure diagnosis should distinguish undertraining, teacher/curriculum weakness, memory retrieval/retention failure, routing failure, representation/core-PAM information loss, interference/regression, and resource saturation.
- Trace infrastructure is protected core observability; task answers and evaluator labels must never be encoded into it.

**Source:** Explicit user instruction on 2026-08-20: code TNN in Zag well enough that failures can be traced back to their reason.
