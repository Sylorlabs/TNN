# TNN User Response and Preference Log

**Purpose:** Preserve explicit user guidance as the conversation evolves. This is not experimental evidence. Each entry records what the user said, the operational interpretation, and whether later evidence or user messages changed it.

## 2026-08-20 — Hardcoding, teacher role, and test depth

**User guidance:** Prefer no hardcoding when possible. Hardcoding may be necessary for core mechanisms, but it should not remain merely for convenience; serious results should justify it. Hardcoded teacher/Master TNNs are an acceptable special case because they teach the mutable base TNN, and prior results show strong teacher-to-base-TNN training has worked best. Tests should be deep and real rather than weak demonstrations. Prior project files should be consulted for context.

**Operational interpretation:**

- Default to learned mutable mechanisms.
- Keep hardcoding only for generic core substrate, immutable verification/safety boundaries, or mechanisms that survive strong matched comparisons against learned alternatives.
- Permit a highly capable hardcoded Master at training time, while prohibiting direct installation of its dictionaries, labels, named concepts, or answer tables into mutable TNN.
- Require teacher withdrawal, transfer, delay, noise, counterexamples, matched controls, regression tests, and fresh-process verification.
- Maintain a hardcoding ledger in every release.
- Continue the same accepted developmental state; use shadow candidates and rollback.

**Status:** Confirmed and binding.

## Earlier preferences recovered from verified handoffs/results

- Go hard on frontier experiments rather than cosmetic tuning.
- Treat symbolic yes/no as a poor primary teaching method.
- Make the Master diagnose exact confusions and respond with examples, contrasts, counterexamples, changed wording, and explicit bridges.
- Keep English/category/social labels outside mutable learner cognition.
- Preserve negative results and rollback history.
- Keep siblings independent, provenance-aware, questioning, and locally verifying.
- Protect core PAMs and accepted state unless strong hidden evidence supports replacement.
- Do not claim human superiority without actual matched human data.
- Keep bounded controlled claims separate from unrestricted vision, mature English, AHI, or production readiness.

## 2026-08-20 — Plan versus execution correction

**User guidance:** Check what actually ran versus what was only planned. The existence of an R27 plan should not be treated as execution. Preserve the verified work that did run, then execute the uncompleted R27 plan and report all results.

**Operational interpretation:**

- Audit source, serialized outputs, logs, timestamps, and verifier runs before assigning stage status.
- Treat the earlier R27 package as a verified partial checkpoint, not proof that every original R27 objective ran.
- Continue from that accepted state with zero newborn restarts.
- Produce a plan-versus-execution matrix and preserve failed objectives as executed negative results.

**Status:** Confirmed and binding.

## Update rule

When the user provides new project guidance:

1. append a dated entry;
2. distinguish direct preference from inferred preference and from experimental evidence;
3. record operational consequences;
4. note conflicts or reversals explicitly;
5. copy this file and `TNN_USER_RESEARCH_PREFERENCES.md` into the next verified release and `/TNN/Research/`.

## 2026-08-20 — Zag v2, autonomous non-core PAMs, and architecture-scale capability

**User guidance:** Do not store TNN project details in universal memory; keep them in project-local cloud files. TNN-created non-core PAMs should not require human implementation. Only protected core PAMs that TNN cannot access may require researcher implementation. The implementation path is pure Zag v2, not Python. The objective is a giant architecture with superior integrated capability. The poor integrated R27-completion scores—especially 0% changed-view identity, 0% sibling teaching, and 0% full integration—should trigger deep investigation into training, architecture, and possibly core PAM limitations rather than superficial tuning.

**Operational interpretation:**
- Treat project-local Markdown/JSON under `/TNN/Research` as the durable memory surface for this project.
- Implement future promotable mechanisms in native Zag v2.
- Build endogenous PAM construction so TNN can instantiate and manage non-core PAMs directly from a generic protected substrate/grammar without researcher translation.
- Keep core PAM substrate and root verifier protected from TNN mutation, while allowing researcher-led core redesign when deep evidence shows the interface is limiting capability.
- Run architecture-level diagnostics before the next integrated attempt: information-preservation, identity-binding, cross-view invariance, entity graph, affordance binding, language-to-entity binding, sibling communication, and failure attribution.
- Goal is 100% on the bounded integrated battery under strong hidden/noisy/delayed tests, not 100% through evaluator leakage or test-specific hardcoding.

**Status:** Confirmed and binding.

## 2026-08-20 — Memory autonomy and skeptical 100% target

**User guidance:** TNN should choose its own memories. Memory should not be slowly phased away by a human-authored developmental schedule. The ability to choose what belongs in long-term, short-term, and other memory layers is a core TNN advantage. The project should seek the highest real capability possible and can target 100%, but 100% must be treated skeptically: no weak tests, bullshit results, or test design that makes a perfect score easy. For low results, inspect training progress step by step before deciding whether training, architecture, or core PAMs are at fault.

**Operational interpretation:**
- Make memory allocation, retention, consolidation, exact-archive use, compression, replay, and eviction learner-controlled policies built on a protected generic memory substrate.
- Do not use age/phase rules such as automatically reducing exact memory because a developmental stage advanced.
- Preserve exact information when useful/affordable and let TNN learn when compression or eviction is worth the risk.
- Instrument every major learning curve at multiple exposure points and record teacher actions, memory state, PAM route, and error class.
- Treat 100% only as a bounded preregistered qualification result and attack it with harder hidden/adversarial follow-ups.
- Never tune on the final hidden set or allow evaluator labels into learner state.
- Continue to maximize genuine capability rather than settling for low-but-statistically-significant improvements.

**Status:** Confirmed and binding.

## 2026-08-20 — Native causal traceability

**User guidance:** Execute the full architecture plan and ensure the Zag implementation makes failures easy to trace to their actual cause.

**Operational interpretation:**
- Treat causal observability as protected core infrastructure.
- Preserve parent-linked traces across memory, PAM creation/deletion, entity merge/split/persistence, active perception, language binding, sibling testimony, teacher interventions, and failure diagnosis.
- Do not substitute final accuracy tables for causal diagnostics.
- Keep TNN project memory in project-local files only.

**Status:** Confirmed and binding.
