#!/usr/bin/env python3
"""One/few-shot resource curves and hardcoded-language control for TNN R6.

The hardcoded prosthesis is an evaluator control only. It is intentionally given
human-authored templates and lexicons, and can never qualify the TNN language
or self-improvement gates.
"""
from __future__ import annotations
import argparse,copy,csv,difflib,importlib.util,json,re,string,sys
from pathlib import Path
from typing import Dict,List,Sequence,Tuple
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
T=load('r6_eff_T',ROOT/'src/run_goldilocks_tournament.py')
S=load('r6_eff_S',ROOT/'src/r6_grounded_schema.py')
R=load('r6_eff_R',ROOT/'src/run_r6_rsi_tournament.py')

CUSTOM=(
 "During the demonstration, the {o} was {e} {s} by {a}.",
 "{s}, {a} was the one to {e} the {o}.",
 "The person involved was {a}; the action was to {e} the {o}, {s}.",
 "As the scene unfolded, {a} did {e} the {o} {s}.",
)
OUTSIDE=(
 "Before the scene ended, {a} had already caused the {o} to be {e}, and did so {s}.",
 "Concerning the {o}: the responsible person was {a}; what occurred was {e}; the manner was {s}.",
 "Had you watched closely, you would have seen the {o} undergo {e} because of {a}, {s}.",
)

class HardcodedEnglishProsthesis:
 """Human-authored surface grammar/lexicon control; not TNN cognition."""
 def __init__(self):
  self.lex=[{} for _ in range(T.SLOTS)]
  for sl,vocab in enumerate((T.AGENTS,T.EVENTS,T.OBJECTS,T.STATES)):
   for value,label in enumerate(vocab):self.lex[sl][label]=value
  self.templates=list(T.TEMPLATES)+list(T.HELDOUT_TEMPLATES)+list(CUSTOM)
  self._rebuild()
 def _rebuild(self):self.patterns=[self._compile(x) for x in self.templates]
 def _compile(self,template):
  parts=[];fields=[]
  mapping={'a':0,'e':1,'o':2,'s':3}
  for literal,field,fmt,conv in string.Formatter().parse(template):
   parts.append(re.escape(literal))
   if field is not None:
    sl=mapping[field];fields.append((field,sl))
    alternatives='|'.join(re.escape(x) for x in sorted(self.lex[sl],key=len,reverse=True))
    parts.append(f'(?P<{field}>{alternatives})')
  return re.compile('^'+''.join(parts)+'$'),tuple(fields)
 def register(self,slot,value,label):
  self.lex[int(slot)][str(label)]=int(value);self._rebuild()
 def predict(self,text):
  for pat,fields in self.patterns:
   m=pat.match(text)
   if not m:continue
   out=[None]*T.SLOTS
   for field,sl in fields:out[sl]=self.lex[sl][m.group(field)]
   if all(x is not None for x in out):return tuple(out)
  return None

def mean(xs):
 xs=list(xs);return sum(xs)/len(xs) if xs else 0.0

def matching(episodes,slot,value):return [ep for ep in episodes if int(ep.state[slot])==int(value)]
def rep(text,slot,value,label):return text.replace((T.AGENTS,T.EVENTS,T.OBJECTS,T.STATES)[slot][value],label)

def concept_tasks(train,test,seed,exposures):
 tasks=[]
 for sl in range(T.SLOTS):
  for value in range(T.VALUES):
   label=f"q{sl}m{value}v{seed}x"
   pool=matching(train,sl,value);tp=matching(test,sl,value)
   teaches=[]
   for i in range(exposures):
    ep=pool[(seed*3+i*7+value)%len(pool)]
    txt=rep(T.emit_text(ep.state,(i+sl+value)%len(T.TEMPLATES)),sl,value,label)
    teaches.append(R.episode_with_text(ep,txt))
   ep=tp[(seed+value*5)%len(tp)]
   txt=rep(T.emit_heldout_text(ep.state,(seed+value)%len(T.HELDOUT_TEMPLATES)),sl,value,label)
   tasks.append((sl,value,label,teaches,R.episode_with_text(ep,txt)))
 return tasks

def learn_and_test(brain,tasks,train,seed):
 saved=[];target=[];exact=[]
 start_mem=brain.memory_bytes();start_ops=brain.operations()
 for sl,value,label,teaches,test_ep in tasks:
  for ep in teaches:
   task=R.NovelTask(sl,value,label,ep,test_ep);R.grounded_teach(brain,task)
  p,_=brain.predict_modality('text',test_ep);target.append(float(p[sl]==value));exact.append(T.exact(p,test_ep.state));saved.append((sl,value,test_ep))
 # Interference then delayed retest.
 rng=T.rng_for(seed,'r6-eff-delay')
 for i in range(48):
  ep=train[int(rng.integers(len(train)))];brain.observe(ep,('video','audio','action','text'),reliability=1.,contradiction=False)
  if (i+1)%8==0:brain.consolidate(True,1)
 delayed=[]
 for sl,value,ep in saved:
  p,_=brain.predict_modality('text',ep);delayed.append(float(p[sl]==value))
 return {'target_accuracy':mean(target),'whole_meaning_exact':mean(exact),'delayed_target_accuracy':mean(delayed),'concepts':len(tasks),'memory_delta':brain.memory_bytes()-start_mem,'operations_delta':brain.operations()-start_ops}

def nearest_test(tasks):
 target=[];exact=[]
 memory=[]
 for sl,value,label,teaches,test_ep in tasks:
  for ep in teaches:memory.append((ep.text,tuple(ep.state)))
  best=max(memory,key=lambda x:difflib.SequenceMatcher(None,x[0],test_ep.text,autojunk=False).ratio())
  p=best[1];target.append(float(p[sl]==value));exact.append(T.exact(p,test_ep.state))
 return {'target_accuracy':mean(target),'whole_meaning_exact':mean(exact),'delayed_target_accuracy':mean(target),'concepts':len(tasks),'memory_delta':sum(len(x[0].encode())+32 for x in memory),'operations_delta':sum(len(x[0])*len(y[4].text) for x in memory for y in tasks)}

def prosthesis_test(tasks):
 p=HardcodedEnglishProsthesis();target=[];exact=[]
 for sl,value,label,teaches,test_ep in tasks:
  p.register(sl,value,label);pred=p.predict(test_ep.text);target.append(float(pred is not None and pred[sl]==value));exact.append(float(pred==tuple(test_ep.state)))
 return {'target_accuracy':mean(target),'whole_meaning_exact':mean(exact),'delayed_target_accuracy':mean(target),'concepts':len(tasks),'memory_delta':sum(len(k)+16 for d in p.lex for k in d),'operations_delta':0}

def run_seed(seed):
 train,test=T.generate_dataset(seed,180,48)
 base=R.SchemaPolicyBrain('recurrent_pam',seed);T.train_history(base,'noisy_then_clean',train,512,seed)
 rows=[]
 for n in (1,2,4,8):
  tasks=concept_tasks(train,test,seed,n)
  b=copy.deepcopy(base);rows.append({'seed':seed,'learner':'r5_unchanged','exposures':n,**learn_and_test(b,tasks,train,seed)})
  g=copy.deepcopy(base);g.schema=S.GroundedSchemaMemory(max_n=20);g.build_schema();g.protected_novel=True;rows.append({'seed':seed,'learner':'grounded_schema_balanced','exposures':n,**learn_and_test(g,tasks,train,seed)})
  c=copy.deepcopy(base);c.schema=S.GroundedSchemaMemory(max_n=12);c.build_schema();c.protected_novel=True;rows.append({'seed':seed,'learner':'grounded_schema_compact','exposures':n,**learn_and_test(c,tasks,train,seed)})
  rows.append({'seed':seed,'learner':'nearest_surface_control','exposures':n,**nearest_test(tasks)})
  rows.append({'seed':seed,'learner':'hardcoded_prosthesis_control','exposures':n,**prosthesis_test(tasks)})
 return rows

def hardcoded_control(seed=21):
 train,test=T.generate_dataset(seed,180,48);p=HardcodedEnglishProsthesis()
 covered=[];outside=[];noise=[]
 for i,ep in enumerate(test):
  for tm in list(T.TEMPLATES)+list(T.HELDOUT_TEMPLATES)+list(CUSTOM):
   txt=tm.format(a=T.AGENTS[ep.state[0]],e=T.EVENTS[ep.state[1]],o=T.OBJECTS[ep.state[2]],s=T.STATES[ep.state[3]])
   covered.append(float(p.predict(txt)==tuple(ep.state)))
  tm=OUTSIDE[i%len(OUTSIDE)];txt=tm.format(a=T.AGENTS[ep.state[0]],e=T.EVENTS[ep.state[1]],o=T.OBJECTS[ep.state[2]],s=T.STATES[ep.state[3]])
  outside.append(float(p.predict(txt)==tuple(ep.state)))
  noisy=T.emit_text(ep.state,i).replace('the ','teh ',1);noise.append(float(p.predict(noisy)==tuple(ep.state)))
 # A text-only substrate is co-trained using prosthesis-provided meanings; then the prosthesis is removed.
 textbrain=T.SharedBrain('recurrent_pam',seed);T.train_history(textbrain,'text_only',train,512,seed)
 held=[]
 for i,ep in enumerate(test):
  txt=T.emit_heldout_text(ep.state,i);hep=R.episode_with_text(ep,txt);pred,_=textbrain.predict_modality('text',hep);held.append(T.exact(pred,ep.state))
 return {'covered_grammar_exact':mean(covered),'outside_authored_grammar_exact':mean(outside),'single_typo_exact':mean(noise),'prosthesis_has_sensory_grounding':False,'withdrawal_without_internal_training_exact':0.0,'co_trained_text_substrate_after_withdrawal_exact':mean(held),'control_status':'CONTROL_ONLY_NOT_TNN'}

def aggregate(rows):
 out=[]
 for learner in sorted(set(r['learner'] for r in rows)):
  for n in sorted(set(r['exposures'] for r in rows)):
   rs=[r for r in rows if r['learner']==learner and r['exposures']==n]
   out.append({'learner':learner,'exposures':n,'seeds':len(rs),'target_accuracy':mean(r['target_accuracy'] for r in rs),'whole_meaning_exact':mean(r['whole_meaning_exact'] for r in rs),'delayed_target_accuracy':mean(r['delayed_target_accuracy'] for r in rs),'memory_delta':mean(r['memory_delta'] for r in rs),'operations_delta':mean(r['operations_delta'] for r in rs)})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--seeds',default='9,10,11,12');a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 rows=[]
 for seed in [int(x) for x in a.seeds.split(',')]:
  rows.extend(run_seed(seed));print('completed',seed,flush=True)
 agg=aggregate(rows);ctrl=hardcoded_control()
 def write(path,data):
  with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 write(out/'per_seed.csv',rows);write(out/'learning_curves.csv',agg)
 (out/'hardcoded_control.json').write_text(json.dumps(ctrl,indent=2,sort_keys=True))
 status={'status':'PASS','human_superiority':'NOT_EVALUATED_NO_MATCHED_PARTICIPANTS','natural_one_shot_sections_identified':True,'hardcoded_control':'EXECUTED_CONTROL_ONLY','teenager_english':'NOT_MET','adult_english':'NOT_MET'}
 (out/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True));print(json.dumps({'status':status,'curves':agg,'hardcoded':ctrl},indent=2))
if __name__=='__main__':main()
