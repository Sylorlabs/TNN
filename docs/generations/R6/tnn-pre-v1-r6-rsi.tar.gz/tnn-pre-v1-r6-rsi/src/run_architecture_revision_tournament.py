#!/usr/bin/env python3
"""SAR shadow tournament for R5 language failures.

Candidates are generic raw-byte/memory mechanisms.  They contain no English
surface vocabulary or grammar.  Each branch starts from the same developmental
history and is evaluated on controlled regression, one-shot transfer, and
multi-turn reference.
"""
from __future__ import annotations
import argparse, csv, importlib.util, json, math, statistics, sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple
import numpy as np

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("r5base",HERE/"run_goldilocks_tournament_v5.py")
if spec is None or spec.loader is None: raise RuntimeError("base load failed")
T=importlib.util.module_from_spec(spec);sys.modules[spec.name]=T;spec.loader.exec_module(T)

VARIANTS=("baseline","indexed_contrast","surprise_spans","stream_workspace","combined")

@dataclass
class SparseEvidence:
    fast:float=0.0
    slow:float=0.0
    sources:int=0
    @property
    def support(self)->float:return self.fast+2.0*self.slow

class IndexedContrastiveMotifMemory(T.ContrastiveMotifMemory):
    """Finds discriminating contrasts by grounded state, not recent-list luck."""
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw)
        self.index=[{} for _ in range(T.SLOTS)]
    def observe(self,text:str,state:Sequence[int],source:int,gain:float=1.0)->None:
        b=text.encode("utf-8");st=tuple(map(int,state))
        # Search experiences matching every grounded factor except one.  The
        # indexing criterion is modality-generic and never inspects language.
        for slot in range(T.SLOTS):
            key=tuple(st[i] for i in range(T.SLOTS) if i!=slot)
            candidates=self.index[slot].get(key,())
            for old,ost,osource in candidates[-96:]:
                if ost[slot]==st[slot]:continue
                pre=self._prefix(b,old);suf=self._suffix(b,old,pre)
                covered=pre+suf
                self.operations+=min(len(b),len(old))
                if covered<int(.35*min(len(b),len(old))):continue
                ns=b[pre:len(b)-suf if suf else len(b)]
                os=old[pre:len(old)-suf if suf else len(old)]
                if 0<len(ns)<=64 and 0<len(os)<=64:
                    self._add(slot,st[slot],ns,source,gain)
                    self._add(slot,ost[slot],os,osource,gain)
        super().observe(text,state,source,gain)
        for slot in range(T.SLOTS):
            key=tuple(st[i] for i in range(T.SLOTS) if i!=slot)
            bank=self.index[slot].setdefault(key,[]);bank.append((b,st,source))
            if len(bank)>128:del bank[:-128]

class SurpriseSpanMemory:
    """Prediction-error recruitment of exact, reversible raw-byte spans.

    Once the substrate has prior experience, n-grams not previously encountered
    are provisionally bound only to grounded factors the current model failed to
    recover.  This is generic novelty-driven sparse memory, not a word boundary.
    """
    def __init__(self,min_n:int=3,max_n:int=14):
        self.min_n=min_n;self.max_n=max_n
        self.seen:Counter[bytes]=Counter()
        self.cells=[[{} for _ in range(T.VALUES)] for _ in range(T.SLOTS)]
        self.observations=0;self.operations=0
    def _ngrams(self,b:bytes):
        for n in range(self.min_n,min(self.max_n,len(b))+1):
            for i in range(len(b)-n+1):yield b[i:i+n]
    def observe(self,text:str,state:Sequence[int],source:int,pred:Sequence[int],margins:Sequence[float],gain:float=1.0):
        b=text.encode("utf-8");grams=list(self._ngrams(b));self.operations+=len(grams)
        mature=self.observations>=48
        if mature:
            novel=[g for g in grams if self.seen[g]==0]
            # Store every scale, but cap each length to keep memory bounded.  The
            # internal spans of a genuinely new label recur under new framing;
            # accidental sentence-wide spans do not.
            by_len={}
            for g in novel:by_len.setdefault(len(g),[]).append(g)
            selected=[]
            for n,items in by_len.items():
                step=max(1,len(items)//24);selected.extend(items[::step][:24])
            for slot,value in enumerate(state):
                if int(pred[slot])==int(value) and float(margins[slot])>.12:continue
                bank=self.cells[slot][int(value)]
                for g in selected:
                    ev=bank.get(g)
                    if ev is None:ev=SparseEvidence();bank[g]=ev
                    bit=1<<(source%8);ind=1.0 if not(ev.sources&bit) else .18
                    ev.fast+=gain*ind*(1.0+.04*len(g));ev.sources|=bit
        for g in grams:self.seen[g]+=1
        self.observations+=1
    def consolidate(self,verified:bool):
        for row in self.cells:
            for bank in row:
                for ev in bank.values():
                    if verified or ev.sources.bit_count()>=2:ev.slow+=(.30 if verified else .10)*ev.fast
                    ev.fast*=.72
    def predict(self,text:str):
        b=text.encode("utf-8");vals=[];margins=[];conf=[]
        for slot in range(T.SLOTS):
            scores=[]
            for value in range(T.VALUES):
                score=0.0
                for g,ev in self.cells[slot][value].items():
                    self.operations+=max(1,len(b)-len(g)+1)
                    if g in b:score+=ev.support*(len(g)**1.25)
                scores.append(score)
            order=np.argsort(scores);best=int(order[-1]);runner=int(order[-2])
            vals.append(best);margins.append(scores[best]-scores[runner]);conf.append(scores[best])
        return tuple(vals),np.asarray(margins,np.float32),np.asarray(conf,np.float32)
    def memory_bytes(self):
        return sum(len(g)+24 for row in self.cells for bank in row for g in bank)

class CandidateBrain(T.SharedBrain):
    def __init__(self,architecture:str,seed:int,variant:str):
        super().__init__(architecture,seed);self.variant=variant
        if variant in ("indexed_contrast","combined"):
            self.text_contrast=IndexedContrastiveMotifMemory()
        self.surprise=SurpriseSpanMemory() if variant in ("surprise_spans","combined") else None
        self.workspace=variant in ("stream_workspace","combined")
    def observe(self,ep,modalities,reliability=1.0,contradiction=False,duplicate=1,corrupt=None):
        if self.surprise is not None and "text" in modalities and self.fitted_text and not contradiction:
            f=self.feature("text",ep,corrupt);amap=self.ensure_map("text",len(f));pred,margin=amap.predict(f)
            lexical,lmargin,conf=self.text_contrast.predict(ep.text)
            merged=[];mm=[]
            for r in range(T.SLOTS):
                if conf[r]>.35 and lmargin[r]>.05:merged.append(lexical[r]);mm.append(lmargin[r])
                else:merged.append(pred[r]);mm.append(margin[r])
            self.surprise.observe(ep.text,ep.state,ep.source,merged,mm,reliability)
        super().observe(ep,modalities,reliability,contradiction,duplicate,corrupt)
    def consolidate(self,verified:bool,rounds:int=1):
        super().consolidate(verified,rounds)
        if self.surprise is not None:
            for _ in range(rounds):self.surprise.consolidate(verified)
    def predict_modality(self,modality,ep,corrupt=None):
        base,margin=super().predict_modality(modality,ep,corrupt)
        if modality!="text" or self.surprise is None:return base,margin
        sv,sm,sc=self.surprise.predict(ep.text);out=list(base);om=list(map(float,margin))
        for r in range(T.SLOTS):
            if sc[r]>20.0 and sm[r]>8.0:out[r]=sv[r];om[r]=float(sm[r])
        return tuple(out),np.asarray(om,np.float32)
    def predict_text_stream(self,ep):
        if not self.workspace:return self.predict_modality("text",ep)
        b=ep.text.encode("utf-8")
        # Multi-scale overlapping windows, ordered by temporal endpoint.  There
        # is no punctuation/sentence rule.  Confident recent evidence updates an
        # active state; unobserved roles persist from earlier windows.
        windows=[]
        for width in (36,52,72,96):
            if len(b)<=width:windows.append((len(b),b))
            else:
                for end in range(width,len(b)+1,12):windows.append((end,b[max(0,end-width):end]))
                windows.append((len(b),b[-width:]))
        windows=sorted(set(windows),key=lambda x:(x[0],len(x[1])))
        active=[0]*T.SLOTS;active_margin=[0.0]*T.SLOTS;seen=[False]*T.SLOTS
        for end,w in windows:
            text=w.decode("utf-8",errors="ignore")
            wep=T.Episode(ep.state,ep.video,ep.audio,ep.action,text,ep.source,ep.truthful)
            pred,mar=self.predict_modality("text",wep)
            for r in range(T.SLOTS):
                threshold=.10 if not seen[r] else .18
                if float(mar[r])>=threshold:
                    active[r]=pred[r];active_margin[r]=float(mar[r]);seen[r]=True
        return tuple(active),np.asarray(active_margin,np.float32)
    def memory_bytes(self):
        return super().memory_bytes()+(self.surprise.memory_bytes() if self.surprise is not None else 0)
    def operations(self):
        return super().operations()+(self.surprise.operations if self.surprise is not None else 0)


def ep_text(ep,text,state=None):return T.Episode(tuple(state or ep.state),ep.video,ep.audio,ep.action,text,ep.source,True)
def avg(xs):return statistics.fmean(xs) if xs else 0.0

def targeted_eval(brain,test,seed):
    held=[];held_exact=[]
    for i,ep in enumerate(test):
        p,_=brain.predict_modality("text",ep_text(ep,T.emit_heldout_text(ep.state,i)))
        held.append(T.accuracy(p,ep.state));held_exact.append(T.exact(p,ep.state))
    # One grounded exposure per role, evaluated under a different construction.
    one=[];one_exact=[]
    for slot in range(T.SLOTS):
        for j in range(4):
            ep=test[(slot*9+j)%len(test)];state=list(ep.state);value=state[slot]
            known=(T.AGENTS,T.EVENTS,T.OBJECTS,T.STATES)[slot][value]
            novel=f"qz{slot}{seed}{j}vexa"
            teach=T.emit_text(state,(slot+j)%len(T.TEMPLATES)).replace(known,novel)
            query=T.emit_heldout_text(state,(j+1)%len(T.HELDOUT_TEMPLATES)).replace(known,novel)
            brain.observe(ep_text(ep,teach,state),("video","audio","action","text"),1.0,False,1)
            brain.consolidate(True,1)
            p,_=brain.predict_modality("text",ep_text(ep,query,state))
            one.append(float(p[slot]==value));one_exact.append(T.exact(p,state))
    # Multi-clause reference with an unnamed repeated entity.
    ref=[];ref_exact=[]
    for i in range(min(48,len(test)-1)):
        p1=test[i];p2=test[i+1];a=p1.state[0]
        target=(a,p2.state[1],p2.state[2],p2.state[3])
        text=(f"{T.AGENTS[a]} {T.STATES[p1.state[3]]} {T.EVENTS[p1.state[1]]} the {T.OBJECTS[p1.state[2]]}. "
              f"Then they {T.EVENTS[target[1]]} the {T.OBJECTS[target[2]]} {T.STATES[target[3]]}.")
        e=ep_text(p2,text,target)
        p,_=brain.predict_text_stream(e) if hasattr(brain,"predict_text_stream") else brain.predict_modality("text",e)
        ref.append(T.accuracy(p,target));ref_exact.append(T.exact(p,target))
    # Controlled sensory/language regression (evaluate before its internal one-shot
    # test would introduce further state changes by using a fresh summary subset).
    fused=[];stress=[]
    for ep in test[:40]:
        mods=[m for m in ("video","audio","action","text") if m in brain.maps]
        p,_=brain.predict_fused(mods,ep);fused.append(T.accuracy(p,ep.state))
        p,_=brain.predict_fused(mods,ep,{"video_noise":.12,"occlusion":.18,"audio_noise":.10,"overlap":.20});stress.append(T.accuracy(p,ep.state))
    return {
        "heldout_component":avg(held),"heldout_exact":avg(held_exact),
        "one_shot_role":avg(one),"one_shot_exact":avg(one_exact),
        "reference_component":avg(ref),"reference_exact":avg(ref_exact),
        "fused_component":avg(fused),"stress_component":avg(stress),
        "memory_bytes":brain.memory_bytes(),"operations":brain.operations(),
    }

def run(seed,variant,budget,train_n,test_n):
    train,test=T.generate_dataset(seed,train_n,test_n)
    brain=CandidateBrain("recurrent_pam",seed,variant)
    T.train_history(brain,"noisy_then_clean",train,budget,seed)
    m=targeted_eval(brain,test,seed)
    return {"seed":seed,"variant":variant,"budget":budget,**m}

def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);p.add_argument("--seeds",default="61,62,63");p.add_argument("--budget",type=int,default=512);p.add_argument("--train",type=int,default=420);p.add_argument("--test",type=int,default=120);args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True);seeds=[int(x) for x in args.seeds.split(',') if x]
    rows=[]
    for seed in seeds:
        for v in VARIANTS:
            r=run(seed,v,args.budget,args.train,args.test);rows.append(r);print(json.dumps(r,sort_keys=True),flush=True)
    fields=list(rows[0]);
    with (args.out/"raw_runs.csv").open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    summary=[]
    for v in VARIANTS:
        items=[r for r in rows if r['variant']==v];s={"variant":v,"runs":len(items)}
        for k in fields:
            if k in ('seed','variant','budget'):continue
            vals=[float(x[k]) for x in items];s[k+"_mean"]=avg(vals);s[k+"_min"]=min(vals);s[k+"_max"]=max(vals)
        summary.append(s)
    baseline=next(x for x in summary if x['variant']=='baseline')
    for s in summary:
        s['revision_score']=(.22*s['heldout_exact_mean']+.20*s['one_shot_role_mean']+.22*s['reference_exact_mean']+.18*s['fused_component_mean']+.18*s['stress_component_mean'])
        s['controlled_regression_pass']=s['heldout_exact_mean']>=baseline['heldout_exact_mean']-.02
        s['sensory_regression_pass']=s['stress_component_mean']>=baseline['stress_component_mean']-.02
        s['promotion_candidate']=bool(s['controlled_regression_pass'] and s['sensory_regression_pass'] and s['revision_score']>baseline.get('revision_score',0)+.03)
    summary.sort(key=lambda x:x['revision_score'],reverse=True)
    sfields=list(summary[0]);
    with (args.out/"summary.csv").open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=sfields);w.writeheader();w.writerows(summary)
    status={"release":"R5 SAR language architecture revision tournament","seeds":seeds,"runs":len(rows),"variants":list(VARIANTS),"baseline":baseline,"ranking":summary,"selected":summary[0]['variant'] if summary[0]['promotion_candidate'] else None,"teenager_english":"NOT_MET","production_tnn_v1":"NOT_PROMOTED"}
    (args.out/"status.json").write_text(json.dumps(status,indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps(status,indent=2,sort_keys=True))
if __name__=='__main__':main()
