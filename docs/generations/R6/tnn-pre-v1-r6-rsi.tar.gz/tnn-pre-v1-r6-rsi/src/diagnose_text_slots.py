#!/usr/bin/env python3
import importlib.util,sys,collections
from pathlib import Path
p=Path('/mnt/data/tnn_goldilocks_r5/src/run_goldilocks_tournament.py')
spec=importlib.util.spec_from_file_location('tnn',p);m=importlib.util.module_from_spec(spec);sys.modules['tnn']=m;spec.loader.exec_module(m)
for hist in ['text_only','mixed_all_from_birth','text_first_then_all','staged_video_action_audio_text']:
    train,test=m.generate_dataset(21,600,150)
    b=m.SharedBrain('shallow_pam',21);m.train_history(b,hist,train,2048,21)
    correct=[0]*m.SLOTS; confusion=[collections.Counter() for _ in range(m.SLOTS)]
    held=[0]*m.SLOTS
    for i,e in enumerate(test):
        p,_=b.predict_modality('text',e)
        for r,(a,t) in enumerate(zip(p,e.state)):
            correct[r]+=a==t;confusion[r][(t,a)]+=1
        ht=m.emit_heldout_text(e.state,i);he=m.Episode(e.state,e.video,e.audio,e.action,ht,e.source,True)
        hp,_=b.predict_modality('text',he)
        for r,(a,t) in enumerate(zip(hp,e.state)):held[r]+=a==t
    print(hist,'seen',[round(x/len(test),3) for x in correct],'held',[round(x/len(test),3) for x in held])
    for r,c in enumerate(confusion):print(' slot',r,'top errors',[(k,v) for k,v in c.most_common(5) if k[0]!=k[1]][:3])
