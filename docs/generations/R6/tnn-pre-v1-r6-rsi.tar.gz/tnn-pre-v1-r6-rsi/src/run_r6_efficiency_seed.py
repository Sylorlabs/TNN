#!/usr/bin/env python3
from __future__ import annotations
import argparse,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('eff',ROOT/'src/run_r6_learning_efficiency.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
a=argparse.ArgumentParser();a.add_argument('--seed',type=int,required=True);a.add_argument('--out',required=True);x=a.parse_args();rows=m.run_seed(x.seed);Path(x.out).write_text(json.dumps(rows,indent=2,sort_keys=True));print('completed',x.seed)
