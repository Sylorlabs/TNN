#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,pickle,importlib.util,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
T=load('r6_state_T',ROOT/'src/run_goldilocks_tournament.py');S=load('r6_state_S',ROOT/'src/r6_grounded_schema.py');R=load('r6_state_R',ROOT/'src/run_r6_rsi_tournament.py')
def build(seed=13):
 train,test=T.generate_dataset(seed,180,48);b=R.SchemaPolicyBrain('recurrent_pam',seed);T.train_history(b,'noisy_then_clean',train,512,seed);b.schema=S.GroundedSchemaMemory(max_n=20);b.build_schema();b.protected_novel=True
 tasks=R.make_cross_frame_tasks(test,seed)
 for task in tasks[:4]:R.grounded_teach(b,task)
 queries=[]
 for i,ep in enumerate(test[:12]):
  txt=T.emit_heldout_text(ep.state,i);q=R.episode_with_text(ep,txt);p,m=b.predict_modality('text',q);queries.append({'text':txt,'truth':list(ep.state),'prediction':list(p),'margin':[float(x) for x in m]})
 return b,queries

def main():
 a=argparse.ArgumentParser();a.add_argument('--out',required=True);a.add_argument('--seed',type=int,default=13);x=a.parse_args();out=Path(x.out);out.mkdir(parents=True,exist_ok=True)
 b,q=build(x.seed);payload=pickle.dumps(b,protocol=5);(out/'r6-selected-state.pkl').write_bytes(payload);restored=pickle.loads(payload)
 q2=[]
 _,test=T.generate_dataset(x.seed,180,48)
 for i,ep in enumerate(test[:12]):
  txt=T.emit_heldout_text(ep.state,i);qe=R.episode_with_text(ep,txt);p,m=restored.predict_modality('text',qe);q2.append({'text':txt,'truth':list(ep.state),'prediction':list(p),'margin':[float(v) for v in m]})
 status={'seed':x.seed,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'reload_prediction_parity':all(a['prediction']==b['prediction'] for a,b in zip(q,q2)),'queries':q}
 (out/'state-status.json').write_text(json.dumps(status,indent=2,sort_keys=True));print(json.dumps({k:v for k,v in status.items() if k!='queries'},indent=2))
if __name__=='__main__':main()
