from __future__ import annotations
import importlib.util,sys,re,math
from pathlib import Path
from collections import defaultdict,Counter
from dataclasses import dataclass
from typing import Sequence
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('T',ROOT/'src/run_goldilocks_tournament.py');T=importlib.util.module_from_spec(s);sys.modules['T']=T;s.loader.exec_module(T)
s2=importlib.util.spec_from_file_location('G',ROOT/'src/run_teenager_boundary_gate.py');G=importlib.util.module_from_spec(s2);sys.modules['G']=G;s2.loader.exec_module(G)

@dataclass
class Mot:
    span:bytes; score:float; precision:float; recall:float; count:int
@dataclass
class Ev:
    fast:float=0.;slow:float=0.;sources:int=0
    @property
    def support(self):return self.fast+2*self.slow
@dataclass
class Schema:
    segments:tuple[bytes,...]; slots:tuple[int,...]; support:int=0
    def pattern(self):
        p=b'^'+re.escape(self.segments[0])
        for i,slot in enumerate(self.slots):p+=b'(.+?)'+re.escape(self.segments[i+1])
        return re.compile(p+b'$')

class GroundedSchemaMemory:
    def __init__(self,max_n=20):
        self.max_n=max_n;self.lex=[[[] for _ in range(T.VALUES)] for _ in range(T.SLOTS)]
        self.schemas=[];self.bank=[[{} for _ in range(T.VALUES)] for _ in range(T.SLOTS)]
        self.operations=0;self.bindings=0;self.matches=0;self.ambiguous=0
    def build(self,examples):
        uniq=[];seen=set()
        for b,st,src in examples:
            k=(b,st)
            if k not in seen:seen.add(k);uniq.append((b,st,src))
        ntexts=len(uniq)
        # document occurrence counts (not repetition frequency)
        grams=defaultdict(lambda: [Counter() for _ in range(T.SLOTS)])
        totals=[[0]*T.VALUES for _ in range(T.SLOTS)]
        for b,st,src in uniq:
            for sl,v in enumerate(st):totals[sl][v]+=1
            present=set()
            L=len(b)
            for n in range(2,min(self.max_n,L)+1):
                for i in range(L-n+1):present.add(b[i:i+n])
            self.operations+=sum(max(0,L-n+1) for n in range(2,min(self.max_n,L)+1))
            for g in present:
                for sl,v in enumerate(st):grams[g][sl][v]+=1
        # score discriminative recurring spans. Recall pressure rejects template+value accidents.
        for sl in range(T.SLOTS):
          for v in range(T.VALUES):
            cand=[]
            for g,slotcounts in grams.items():
                c=slotcounts[sl][v];allc=sum(slotcounts[sl].values())
                if c<3:continue
                precision=(c+.25)/(allc+.5); recall=c/max(1,totals[sl][v])
                if precision<.88 or recall<.20:continue
                # prefer exact, broadly recurring, compact spans; longer only if equally broad.
                score=(precision**4)*(recall**1.5)*math.log1p(c)*(1+.035*min(len(g),16))
                cand.append(Mot(g,score,precision,recall,c))
            cand.sort(key=lambda m:(m.score,m.recall,m.precision,len(m.span)),reverse=True)
            # remove redundant super/substrings, keeping broad high score representatives
            chosen=[]
            for m in cand:
                if any((m.span in q.span or q.span in m.span) and abs(m.recall-q.recall)<.12 for q in chosen):continue
                chosen.append(m)
                if len(chosen)>=12:break
            self.lex[sl][v]=chosen
        # Derive a high-recall core for each alternative, then remove any
        # prefix/suffix shared by every alternative in the same latent factor.
        # This is alternative-set contrast, not a word-boundary rule.
        cores=[[b'' for _ in range(T.VALUES)] for _ in range(T.SLOTS)]
        for sl in range(T.SLOTS):
            raw=[]
            for v in range(T.VALUES):
                pool=[m for m in self.lex[sl][v] if m.precision>=.97 and m.recall>=.98]
                if not pool: pool=self.lex[sl][v][:1]
                # Longest broadly recurring motif, with score as tiebreaker.
                m=max(pool,key=lambda x:(len(x.span),x.recall,x.score))
                raw.append(m.span)
            cp=raw[0]
            for x in raw[1:]:
                k=0
                while k<min(len(cp),len(x)) and cp[k]==x[k]:k+=1
                cp=cp[:k]
            cs=b''
            for v,x in enumerate(raw):
                a=len(cp);z=len(x)-len(cs) if cs else len(x)
                core=x[a:z]
                if len(core)<2:core=x
                cores[sl][v]=core
                # Put the contrastively isolated core first for schema building.
                prior=self.lex[sl][v]
                match=next((m for m in prior if m.span==core),None)
                if match is None:
                    match=Mot(core,10.0,1.0,1.0,totals[sl][v])
                self.lex[sl][v]=[match]+[m for m in prior if m.span!=core]
        self.cores=cores
        # locate one grounded span per slot and derive construction skeletons
        sdict={}
        for b,st,src in uniq:
            opts=[]
            for sl,v in enumerate(st):
                choices=[]
                for rank,m in enumerate(self.lex[sl][v]):
                    start=0
                    while True:
                        at=b.find(m.span,start)
                        if at<0:break
                        priority=(1000.0 if rank==0 else 0.0)+m.score*math.sqrt(len(m.span))
                        choices.append((priority,at,at+len(m.span),m))
                        start=at+1
                choices.sort(reverse=True)
                opts.append((sl,choices))
            # brute force top candidates with non-overlap
            selected=[]
            for sl,choices in sorted(opts,key=lambda x:len(x[1])):
                pick=None
                for item in choices:
                    _,a,z,m=item
                    if all(z<=aa or a>=zz for _,aa,zz,_ in selected):pick=(sl,a,z,m);break
                if pick:selected.append(pick)
            if len(selected)!=T.SLOTS:continue
            selected.sort(key=lambda x:x[1])
            segments=[];slots=[];cursor=0
            for sl,a,z,m in selected:
                segments.append(b[cursor:a]);slots.append(sl);cursor=z
            segments.append(b[cursor:])
            key=(tuple(segments),tuple(slots))
            if key not in sdict:sdict[key]=Schema(tuple(segments),tuple(slots),0)
            sdict[key].support+=1
        self.schemas=[x for x in sdict.values() if x.support>=2]
        self.schemas.sort(key=lambda x:(x.support,sum(map(len,x.segments))),reverse=True)
        # seed bank with learned lexical spans
        for sl in range(T.SLOTS):
          for v in range(T.VALUES):
            core=self.cores[sl][v]
            self.bank[sl][v][core]=Ev(slow=8.0,sources=0xff)
            for m in self.lex[sl][v]:
                if m.span!=core and m.precision>=.98 and m.recall>=.60:
                    self.bank[sl][v][m.span]=Ev(slow=max(.4,m.score),sources=0xff)
    def parse(self,text,state):
        b=text.encode();st=tuple(state);candidates=[]
        for sc in self.schemas:
            mat=sc.pattern().match(b);self.operations+=len(b)
            if not mat:continue
            groups=mat.groups(); known=0; unknown=0; quality=0.
            for group,sl in zip(groups,sc.slots):
                v=st[sl];bank=self.bank[sl][v]
                exact=max((ev.support for sp,ev in bank.items() if sp==group),default=0.)
                contained=max((ev.support for sp,ev in bank.items() if sp in group or group in sp),default=0.)
                if max(exact,contained)>.15:known+=1;quality+=max(exact,contained)
                else:unknown+=1
            # At least two grounded slots anchor the construction; fewer is too ambiguous.
            if known>=2 and unknown<=2:candidates.append((known*10-unknown+quality+.05*sc.support,sc,groups))
        if not candidates:return None
        candidates.sort(key=lambda x:x[0],reverse=True)
        if len(candidates)>1 and candidates[0][0] < candidates[1][0]+.25:
            self.ambiguous+=1
        self.matches+=1
        return candidates[0][1],candidates[0][2]
    def observe(self,text,state,source,gain=1.):
        parsed=self.parse(text,state)
        if not parsed:return 0
        sc,groups=parsed
        # Support-gap recruitment: only an unsupported captured span is eligible
        # for one-shot growth. Familiar grounded spans are left untouched. This
        # is a generic evidence criterion, not a word or grammar rule.
        gaps=[]
        for group,sl in zip(groups,sc.slots):
            if not (1<=len(group)<=64):continue
            v=int(state[sl]);bank=self.bank[sl][v]
            support=max((ev.support for sp,ev in bank.items() if sp==group or sp in group or group in sp),default=0.)
            if support<=.15:gaps.append((group,sl,v))
        # One exposure can identify one isolated novelty. Multiple unsupported
        # spans remain ambiguous and are not written as facts.
        if len(gaps)!=1:return 0
        group,sl,v=gaps[0];d=self.bank[sl][v];ev=d.get(group);added=0
        if ev is None:ev=Ev();d[group]=ev;added=1;self.bindings+=1
        bit=1<<(source%8);ind=1. if not(ev.sources&bit) else .16
        ev.fast+=gain*ind;ev.sources|=bit
        return added
    def consolidate(self,verified=True):
        for row in self.bank:
          for d in row:
            for ev in d.values():
                if verified or ev.sources.bit_count()>=2:ev.slow+=.35*ev.fast
                ev.fast*=.70
    def predict(self,text):
        b=text.encode();vals=[];m=[];c=[]
        for sl in range(T.SLOTS):
            scores=[]
            for v in range(T.VALUES):
                score=0.
                for sp,ev in self.bank[sl][v].items():
                    self.operations+=max(1,len(b)-len(sp)+1)
                    if sp in b:score+=ev.support*(1+.10*min(len(sp),24))
                scores.append(score)
            order=np.argsort(scores);best=int(order[-1]);runner=int(order[-2])
            vals.append(best);m.append(scores[best]-scores[runner]);c.append(scores[best])
        return tuple(vals),np.array(m,np.float32),np.array(c,np.float32)
    def memory_bytes(self):return sum(len(sp)+32 for row in self.bank for d in row for sp in d)+sum(sum(map(len,s.segments))+64 for s in self.schemas)

class Brain(T.SharedBrain):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.schema=GroundedSchemaMemory();self.schema_enabled=False
    def build_schema(self):self.schema.build(self.text_contrast.examples);self.schema_enabled=True
    def observe(self,ep,modalities,*a,**kw):
        if self.schema_enabled and 'text' in modalities and not kw.get('contradiction',False):self.schema.observe(ep.text,ep.state,ep.source,kw.get('reliability',1.0))
        return super().observe(ep,modalities,*a,**kw)
    def consolidate(self,verified,rounds=1):
        super().consolidate(verified,rounds)
        if self.schema_enabled:
            for _ in range(rounds):self.schema.consolidate(verified)
    def _merge(self,text,p,m):
        if not self.schema_enabled:return p,m
        sv,sm,sc=self.schema.predict(text);p=list(p);m=list(m)
        for r in range(T.SLOTS):
            if sc[r]>.35 and sm[r]>.08:p[r]=sv[r];m[r]=sm[r]
        return tuple(p),np.array(m,np.float32)
    def predict_modality(self,modality,ep,corrupt=None):
        p,m=super().predict_modality(modality,ep,corrupt)
        return self._merge(ep.text,p,m) if modality=='text' else (p,m)
    def explicit_text_evidence(self,text):
        p,m,c=super().explicit_text_evidence(text)
        if not self.schema_enabled:return p,m,c
        sv,sm,sc=self.schema.predict(text);p=list(p);m=list(m);c=list(c)
        for r in range(T.SLOTS):
            if sc[r]>.35 and sm[r]>.08:p[r]=sv[r];m[r]=sm[r];c[r]=sc[r]
        return tuple(p),np.array(m,np.float32),np.array(c,np.float32)
    def memory_bytes(self):return super().memory_bytes()+(self.schema.memory_bytes() if self.schema_enabled else 0)
    def operations(self):return super().operations()+self.schema.operations

