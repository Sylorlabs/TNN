#!/usr/bin/env python3
"""Second SAR shadow tournament: contextual novelty and motif-gated discourse."""
from __future__ import annotations
import argparse,csv,importlib.util,json,statistics,sys
from collections import Counter
from pathlib import Path
from typing import Sequence
import numpy as np
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('rev1',HERE/'run_architecture_revision_tournament.py')
if sp is None or sp.loader is None:raise RuntimeError
R=importlib.util.module_from_spec(sp);sys.modules[sp.name]=R;sp.loader.exec_module(R);T=R.T
VARIANTS=('baseline','indexed_contrast','surprise_spans','stream_workspace','combined')

class SurpriseSpanMemoryV2:
    """Recruit only a localized novel span after a one-factor prediction error."""
    def __init__(self):
        self.trigrams=Counter();self.cells=[[{} for _ in range(T.VALUES)] for _ in range(T.SLOTS)]
        self.observations=0;self.operations=0
    @staticmethod
    def _regions(mask):
        out=[];start=None
        for i,x in enumerate(mask+[False]):
            if x and start is None:start=i
            if not x and start is not None:out.append((start,i));start=None
        return out
    def observe(self,text,state,source,pred,margins,gain=1.0):
        b=text.encode('utf-8');wrong=[r for r in range(T.SLOTS) if int(pred[r])!=int(state[r])]
        if self.observations>=96 and len(wrong)==1:
            covered=[False]*len(b)
            for i in range(max(0,len(b)-2)):
                g=b[i:i+3];self.operations+=1
                if self.trigrams[g]>=2:
                    for j in range(i,min(len(b),i+3)):covered[j]=True
            novel=[not x for x in covered]
            regions=[x for x in self._regions(novel) if 3<=x[1]-x[0]<=40]
            if regions:
                start,end=max(regions,key=lambda x:x[1]-x[0]);region=b[start:end]
                slot=wrong[0];value=int(state[slot]);bank=self.cells[slot][value]
                for n in range(3,min(14,len(region))+1):
                    for i in range(len(region)-n+1):
                        g=region[i:i+n];ev=bank.get(g)
                        if ev is None:ev=R.SparseEvidence();bank[g]=ev
                        bit=1<<(source%8);ind=1.0 if not(ev.sources&bit) else .18
                        ev.fast+=gain*ind*(1+.05*n);ev.sources|=bit
        for i in range(max(0,len(b)-2)):self.trigrams[b[i:i+3]]+=1
        self.observations+=1
    def consolidate(self,verified):
        for row in self.cells:
            for bank in row:
                for ev in bank.values():
                    if verified or ev.sources.bit_count()>=2:ev.slow+=(.34 if verified else .10)*ev.fast
                    ev.fast*=.74
    def predict(self,text):
        b=text.encode('utf-8');vals=[];margins=[];conf=[]
        for slot in range(T.SLOTS):
            scores=[]
            for value in range(T.VALUES):
                score=0.0
                for g,ev in self.cells[slot][value].items():
                    self.operations+=max(1,len(b)-len(g)+1)
                    if g in b:score+=ev.support*(len(g)**1.35)
                scores.append(score)
            order=np.argsort(scores);best=int(order[-1]);run=int(order[-2])
            vals.append(best);margins.append(scores[best]-scores[run]);conf.append(scores[best])
        return tuple(vals),np.asarray(margins,np.float32),np.asarray(conf,np.float32)
    def memory_bytes(self):return sum(len(g)+24 for row in self.cells for bank in row for g in bank)

class Brain(R.CandidateBrain):
    def __init__(self,architecture,seed,variant):
        super().__init__(architecture,seed,variant)
        if variant in ('surprise_spans','combined'):self.surprise=SurpriseSpanMemoryV2()
    def predict_text_stream(self,ep):
        if not self.workspace:return self.predict_modality('text',ep)
        b=ep.text.encode('utf-8');widths=(24,30,36,42,52,64,80,96)
        endpoints=sorted(set(list(range(24,len(b)+1,8))+[len(b)]))
        active=[0]*T.SLOTS;am=[0.0]*T.SLOTS;seen=[False]*T.SLOTS
        for end in endpoints:
            choices=[None]*T.SLOTS
            for width in widths:
                if width>end:continue
                w=b[max(0,end-width):end];text=w.decode('utf-8',errors='ignore')
                lex,lm,cf=self.text_contrast.predict(text)
                if self.surprise is not None:
                    sv,sm,sc=self.surprise.predict(text)
                    for r in range(T.SLOTS):
                        if sc[r]>20 and sm[r]>8:lex=list(lex);lm=lm.copy();cf=cf.copy();lex[r]=sv[r];lm[r]=sm[r];cf[r]=sc[r];lex=tuple(lex)
                for r in range(T.SLOTS):
                    # The first (shortest) window carrying explicit motif
                    # evidence wins for this endpoint. Missing roles persist.
                    if choices[r] is None and float(cf[r])>.35 and float(lm[r])>.05:
                        choices[r]=(int(lex[r]),float(lm[r]))
            for r,c in enumerate(choices):
                if c is not None:active[r],am[r]=c;seen[r]=True
        return tuple(active),np.asarray(am,np.float32)

def avg(x):return statistics.fmean(x) if x else 0.0

def run(seed,variant,budget,train_n,test_n):
    train,test=T.generate_dataset(seed,train_n,test_n);brain=Brain('recurrent_pam',seed,variant);T.train_history(brain,'noisy_then_clean',train,budget,seed)
    m=R.targeted_eval(brain,test,seed);return {'seed':seed,'variant':variant,'budget':budget,**m}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--seeds',default='71,72,73');p.add_argument('--budget',type=int,default=512);p.add_argument('--train',type=int,default=420);p.add_argument('--test',type=int,default=120);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in [int(x) for x in a.seeds.split(',') if x]:
        for v in VARIANTS:
            r=run(seed,v,a.budget,a.train,a.test);rows.append(r);print(json.dumps(r,sort_keys=True),flush=True)
    fields=list(rows[0]);
    with (a.out/'raw_runs.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    summary=[]
    for v in VARIANTS:
        it=[r for r in rows if r['variant']==v];s={'variant':v,'runs':len(it)}
        for k in fields:
            if k in ('seed','variant','budget'):continue
            vals=[float(x[k]) for x in it];s[k+'_mean']=avg(vals);s[k+'_min']=min(vals);s[k+'_max']=max(vals)
        summary.append(s)
    base=next(x for x in summary if x['variant']=='baseline')
    for s in summary:
        s['revision_score']=.20*s['heldout_exact_mean']+.22*s['one_shot_role_mean']+.24*s['reference_exact_mean']+.17*s['fused_component_mean']+.17*s['stress_component_mean']
        s['controlled_regression_pass']=s['heldout_exact_mean']>=base['heldout_exact_mean']-.02
        s['sensory_regression_pass']=s['stress_component_mean']>=base['stress_component_mean']-.02
    bscore=next(x['revision_score'] for x in summary if x['variant']=='baseline')
    for s in summary:s['promotion_candidate']=bool(s['controlled_regression_pass'] and s['sensory_regression_pass'] and s['revision_score']>=bscore+.03)
    summary.sort(key=lambda x:x['revision_score'],reverse=True)
    with (a.out/'summary.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    status={'release':'R5 SAR revision v2','runs':len(rows),'seeds':sorted(set(r['seed'] for r in rows)),'ranking':summary,'selected':summary[0]['variant'] if summary[0]['promotion_candidate'] else None,'teenager_english':'NOT_MET'}
    (a.out/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True));print(json.dumps(status,indent=2,sort_keys=True))
if __name__=='__main__':main()
