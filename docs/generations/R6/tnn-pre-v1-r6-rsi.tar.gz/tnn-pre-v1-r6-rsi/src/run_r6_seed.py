#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, importlib.util, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r6_runner',ROOT/'src/run_r6_rsi_tournament.py')
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)

ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--out',required=True);ap.add_argument('--budget',type=int,default=512);ap.add_argument('--train',type=int,default=180);ap.add_argument('--test',type=int,default=48)
a=ap.parse_args();r=mod.run_seed(a.seed,a.budget,a.train,a.test);Path(a.out).write_text(json.dumps(r,indent=2,sort_keys=True));print(f'completed seed={a.seed}')
