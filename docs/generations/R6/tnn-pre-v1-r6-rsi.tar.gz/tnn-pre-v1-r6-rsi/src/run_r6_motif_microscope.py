#!/usr/bin/env python3
"""Evaluator-only inspection of raw-byte motifs learned by the R6 lineage.

Human words and boundary labels are used only after training for diagnosis. The
learner itself receives no whitespace tokenizer or word segmentation.
"""
from __future__ import annotations
import argparse,csv,importlib.util,json,sys
from collections import Counter
from pathlib import Path
from typing import Iterable

ROOT=Path(__file__).resolve().parents[1]

def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
T=load('r6_micro_T',ROOT/'src/run_goldilocks_tournament.py')
S=load('r6_micro_S',ROOT/'src/r6_grounded_schema.py')

KNOWN=tuple(T.AGENTS)+tuple(T.EVENTS)+tuple(T.OBJECTS)+tuple(T.STATES)
KNOWN_BYTES={x.encode('utf-8') for x in KNOWN}

def classify(span:bytes)->str:
    if span in KNOWN_BYTES:return 'exact_known_surface'
    if any(span in x for x in KNOWN_BYTES):return 'inside_known_surface'
    if any(x in span for x in KNOWN_BYTES):return 'contains_known_surface'
    try:s=span.decode('utf-8')
    except UnicodeDecodeError:return 'non_utf8_fragment'
    if any(ch in s for ch in '.;,!?') and len(s)>5:return 'construction_or_phrase'
    if ' ' in s and s.strip()!=s:return 'boundary_crossing'
    if ' ' in s:return 'multiunit_phrase'
    return 'unresolved_fragment'

def motif_rows(brain,budget:int,seed:int):
    rows=[]
    for rank,span in enumerate(brain.text_motifs.motifs[:160],1):
        rows.append({'seed':seed,'budget':budget,'source':'adaptive_motif','rank':rank,'span_utf8':span.decode('utf-8','replace'),'span_hex':span.hex(),'bytes':len(span),'kind':classify(span),'support':None,'slot':None,'value':None})
    contrast=[]
    for slot,row in enumerate(brain.text_contrast.motifs):
        for value,bank in enumerate(row):
            for span,ev in bank.items():contrast.append((ev.support,len(span),slot,value,span))
    contrast.sort(reverse=True)
    for rank,(support,n,slot,value,span) in enumerate(contrast[:160],1):
        rows.append({'seed':seed,'budget':budget,'source':'contrastive_memory','rank':rank,'span_utf8':span.decode('utf-8','replace'),'span_hex':span.hex(),'bytes':len(span),'kind':classify(span),'support':support,'slot':slot,'value':value})
    return rows

def summarize(rows):
    out=[]
    groups={}
    for r in rows:groups.setdefault((r['seed'],r['budget'],r['source']),[]).append(r)
    for (seed,budget,source),rs in sorted(groups.items()):
        counts=Counter(r['kind'] for r in rs)
        aligned=sum(counts[k] for k in ('exact_known_surface','inside_known_surface','contains_known_surface'))
        out.append({'seed':seed,'budget':budget,'source':source,'motifs_inspected':len(rs),'known_surface_aligned_fraction':aligned/max(1,len(rs)),'exact_known_surface':counts['exact_known_surface'],'inside_known_surface':counts['inside_known_surface'],'contains_known_surface':counts['contains_known_surface'],'boundary_crossing':counts['boundary_crossing'],'multiunit_phrase':counts['multiunit_phrase'],'construction_or_phrase':counts['construction_or_phrase'],'unresolved_fragment':counts['unresolved_fragment']})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--seeds',default='1,2');ap.add_argument('--budgets',default='32,128,512');a=ap.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    rows=[];cores=[];schemas=[]
    for seed in [int(x) for x in a.seeds.split(',')]:
      train,test=T.generate_dataset(seed,180,48)
      for budget in [int(x) for x in a.budgets.split(',')]:
        brain=S.Brain('recurrent_pam',seed);T.train_history(brain,'noisy_then_clean',train,budget,seed);rows.extend(motif_rows(brain,budget,seed))
        if budget==max(int(x) for x in a.budgets.split(',')):
          brain.build_schema()
          for slot,row in enumerate(brain.schema.cores):
            for value,span in enumerate(row):cores.append({'seed':seed,'slot':slot,'value':value,'span_utf8':span.decode('utf-8','replace'),'span_hex':span.hex(),'kind':classify(span)})
          for rank,sc in enumerate(brain.schema.schemas[:24],1):schemas.append({'seed':seed,'rank':rank,'support':sc.support,'slots':' '.join(map(str,sc.slots)),'segments_json':json.dumps([x.decode('utf-8','replace') for x in sc.segments])})
    summary=summarize(rows)
    def write(path,data):
      if not data:return
      with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    write(out/'motifs.csv',rows);write(out/'summary.csv',summary);write(out/'contrastive_cores.csv',cores);write(out/'schemas.csv',schemas)
    (out/'status.json').write_text(json.dumps({'status':'PASS','evaluator_only_word_alignment':True,'fixed_tokenizer_in_cognition':False,'seeds':[int(x) for x in a.seeds.split(',')],'budgets':[int(x) for x in a.budgets.split(',')],'summary':summary},indent=2,sort_keys=True))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
