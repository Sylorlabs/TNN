#!/usr/bin/env python3
"""AST-level audit of R6 cognitive additions.

Only named cognitive classes/functions are inspected. Evaluators and the
hardcoded prosthesis control are intentionally outside this audit surface.
"""
from __future__ import annotations
import ast,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
files={
 ROOT/'src/r6_grounded_schema.py':{'Mot','Ev','Schema','GroundedSchemaMemory','Brain'},
 ROOT/'src/run_r6_rsi_tournament.py':{'BroadEvidence','BroadNoveltyMemory','SchemaPolicyBrain','BroadPolicyBrain'},
}
segments=[];refs=[];found=[]
for path,names in files.items():
 source=path.read_text();tree=ast.parse(source)
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:
   found.append(f'{path.name}:{node.name}');segments.append(ast.get_source_segment(source,node) or '')
   for sub in ast.walk(node):
    if isinstance(sub,ast.Name):refs.append(sub.id)
core='\n'.join(segments)
forbidden_surface=('Ava','Ben','Cora','Drew','amber cube','blue ring','moves','supports','According to the scene','noun','verb','pronoun','English grammar','question mode')
forbidden_refs={'AGENTS','EVENTS','OBJECTS','STATES','TEMPLATES','HELDOUT_TEMPLATES','HardcodedEnglishProsthesis'}
llm=(r'\btransformers?\b',r'\bopenai\b',r'\bchatgpt\b',r'\bllm\b',r'next[_ -]?token')
result={
 'audited_nodes':sorted(found),
 'node_count':len(found),
 'forbidden_global_references':sorted(forbidden_refs.intersection(refs)),
 'forbidden_surface_matches':[x for x in forbidden_surface if re.search(re.escape(x),core,re.I)],
 'llm_matches':[x for x in llm if re.search(x,core,re.I)],
 'whitespace_tokenizer_calls':len(re.findall(r'\.split\s*\(\s*\)',core)),
 'hardcoded_control_in_core':'HardcodedEnglishProsthesis' in core,
 'learned_regex_only':'.segments' in core and 're.escape(self.segments' in core,
}
result['pass']=all((result['node_count']==9,not result['forbidden_global_references'],not result['forbidden_surface_matches'],not result['llm_matches'],result['whitespace_tokenizer_calls']==0,not result['hardcoded_control_in_core'],result['learned_regex_only']))
print(json.dumps(result,indent=2,sort_keys=True));raise SystemExit(0 if result['pass'] else 1)
