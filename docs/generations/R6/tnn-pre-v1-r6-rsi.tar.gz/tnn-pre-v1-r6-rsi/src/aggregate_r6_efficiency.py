#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('eff',ROOT/'src/run_r6_learning_efficiency.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
a=argparse.ArgumentParser();a.add_argument('--inputs',required=True);a.add_argument('--out',required=True);x=a.parse_args();out=Path(x.out);out.mkdir(parents=True,exist_ok=True);rows=[]
for p in sorted(Path(x.inputs).glob('seed-*.json')):rows.extend(json.loads(p.read_text()))
agg=m.aggregate(rows);ctrl=m.hardcoded_control()
def write(path,data):
 with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
write(out/'per_seed.csv',rows);write(out/'learning_curves.csv',agg);(out/'hardcoded_control.json').write_text(json.dumps(ctrl,indent=2,sort_keys=True));status={'status':'PASS','human_superiority':'NOT_EVALUATED_NO_MATCHED_PARTICIPANTS','natural_one_shot_sections_identified':True,'hardcoded_control':'EXECUTED_CONTROL_ONLY','teenager_english':'NOT_MET','adult_english':'NOT_MET'};(out/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True));print(json.dumps({'status':status,'curves':agg,'hardcoded':ctrl},indent=2))
