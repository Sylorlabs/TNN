#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,statistics
from pathlib import Path

def load(paths,max_seed=None):
    rows=[]
    for p in paths:
        with Path(p).open(newline='',encoding='utf-8') as f:
            for r in csv.DictReader(f):
                r['seed']=int(r['seed'])
                if max_seed is not None and r['seed']>max_seed: continue
                for k,v in list(r.items()):
                    if k not in ('architecture','history','seed'):
                        if v in (None, ''): r[k]=0.0
                        else:
                            try:r[k]=float(v)
                            except:r[k]=0.0
                rows.append(r)
    # exact dedupe by condition/seed, keep last
    d={(r['seed'],r['architecture'],r['history']):r for r in rows}
    return list(d.values())

def aggregate(rows):
    g={}
    for r in rows:g.setdefault((r['architecture'],r['history']),[]).append(r)
    summary=[]
    for (a,h),items in g.items():
        out={'architecture':a,'history':h,'seeds':len(items)}
        keys=sorted({k for x in items for k in x if k not in ('architecture','history','seed')})
        for k in keys:
            vals=[float(x.get(k,0)) for x in items]
            out[k+'_mean']=statistics.fmean(vals)
            out[k+'_stdev']=statistics.pstdev(vals)
            vals2=sorted(vals)
            out[k+'_min']=vals2[0];out[k+'_max']=vals2[-1]
        summary.append(out)
    summary.sort(key=lambda x:x.get('goldilocks_score_mean',0),reverse=True)
    return summary

def rank(rows,key):
    g={}
    for r in rows:g.setdefault(r[key],[]).append(r)
    out=[]
    for name,items in g.items():
        q={key:name,'runs':len(items),'seeds':len(set(x['seed'] for x in items))}
        for m in ['goldilocks_score','fused_component','fused_exact','stress_component','stress_exact','text_component','heldout_text_component','one_shot_after','one_shot_delayed','crossmodal_consistency','fragmentation_rate','operations','memory_bytes','video_component','audio_component','action_component']:
            q[m]=statistics.fmean(float(x.get(m,0)) for x in items)
        out.append(q)
    out.sort(key=lambda x:x['goldilocks_score'],reverse=True)
    return out

def write_csv(path,rows):
    fields=sorted({k for r in rows for k in r})
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--max-seed',type=int,default=3);p.add_argument('inputs',nargs='+');a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    rows=load(a.inputs,a.max_seed)
    summary=aggregate(rows);hr=rank(rows,'history');ar=rank(rows,'architecture')
    write_csv(a.out/'raw_runs.csv',rows);write_csv(a.out/'condition_summary.csv',summary);write_csv(a.out/'history_ranking.csv',hr);write_csv(a.out/'architecture_ranking.csv',ar)
    status={'runs':len(rows),'conditions':len(summary),'expected_conditions':len(set(x['architecture'] for x in rows))*len(set(x['history'] for x in rows)),'seeds':sorted(set(x['seed'] for x in rows)),'complete':len(summary)==len(set(x['architecture'] for x in rows))*len(set(x['history'] for x in rows)) and len({x['seed'] for x in rows})>=2,'best_condition':summary[0],'history_ranking':hr,'architecture_ranking':ar}
    (a.out/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True),encoding='utf-8')
    print(json.dumps(status,indent=2,sort_keys=True))
if __name__=='__main__':main()
