#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,importlib.util,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r6_runner',ROOT/'src/run_r6_rsi_tournament.py')
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True);ap.add_argument('--out',required=True);ap.add_argument('--calibration',default='1,2,3,4')
a=ap.parse_args();indir=Path(a.inputs);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
per=[json.loads(p.read_text()) for p in sorted(indir.glob('seed-*.json'))];per.sort(key=lambda x:x['seed'])
cal={int(x) for x in a.calibration.split(',') if x.strip()};flat=[c for r in per for c in r['candidates']]
ca=mod.aggregate([r for r in flat if int(r['seed']) in cal]);hi=mod.aggregate([r for r in flat if int(r['seed']) not in cal]);decision=mod.choose_rounds(ca,hi)
(out/'per_seed.json').write_text(json.dumps(per,indent=2,sort_keys=True));(out/'calibration_summary.json').write_text(json.dumps(ca,indent=2,sort_keys=True));(out/'hidden_summary.json').write_text(json.dumps(hi,indent=2,sort_keys=True));(out/'revision_decision.json').write_text(json.dumps(decision,indent=2,sort_keys=True))
mod.write_csv(out/'calibration_summary.csv',ca);mod.write_csv(out/'hidden_summary.csv',hi)
status={'status':'PASS' if decision['hidden_promotion_pass'] else 'NOT_PROMOTED','selected_candidate':decision['round2_policy_selection']['candidate'],'bounded_sar':decision['bounded_sar'],'open_ended_recursive_self_improvement':'NOT_MET','human_superiority':'NOT_EVALUATED','teenager_english':'NOT_MET','adult_english':'NOT_MET','seeds':[r['seed'] for r in per],'calibration_seeds':sorted(cal),'hidden_seeds':sorted(set(r['seed'] for r in per)-cal)}
(out/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True));print(json.dumps(status,indent=2,sort_keys=True))
