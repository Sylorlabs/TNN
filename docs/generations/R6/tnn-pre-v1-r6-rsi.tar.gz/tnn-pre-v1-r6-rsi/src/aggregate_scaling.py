#!/usr/bin/env python3
import csv,json,re,statistics
from pathlib import Path

ROOT=Path('/mnt/data/tnn_goldilocks_r5/results')
common={'text_only','mixed_all_from_birth','staged_video_action_audio_text','text_first_then_all'}
inputs=[]
# Seed 21
inputs += [(64,ROOT/'scaling_b64_s21/raw_runs.csv'),(256,ROOT/'scaling_b256_s21/raw_runs.csv'),(1024,ROOT/'scale_profile/raw_runs.csv'),(2048,ROOT/'scaling_b2048_s21_key/raw_runs.csv'),(2048,ROOT/'scaling_b2048_s21_staged/raw_runs.csv')]
# Seeds 22,23
for s in (22,23):
    for b in (64,256,1024,2048):
        inputs.append((b,ROOT/f'scaling_b{b}_s{s}_key/raw_runs.csv'))
rows=[]
for budget,p in inputs:
    with p.open(newline='',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if r['history'] not in common: continue
            q={'budget':budget,'seed':int(r['seed']),'history':r['history'],'architecture':r['architecture']}
            for k,v in r.items():
                if k in q or k in ('seed','history','architecture'):continue
                q[k]=float(v) if v else 0.0
            rows.append(q)
# dedupe
rows=list({(r['budget'],r['seed'],r['history']):r for r in rows}.values())
g={}
for r in rows:g.setdefault((r['budget'],r['history']),[]).append(r)
summary=[]
for (b,h),items in sorted(g.items()):
    out={'budget':b,'history':h,'seeds':len(items)}
    for m in ['goldilocks_score','text_component','text_exact','heldout_text_component','heldout_text_exact','fused_component','fused_exact','stress_component','stress_exact','one_shot_after','one_shot_delayed','operations','memory_bytes']:
        vals=[x.get(m,0.0) for x in items]
        out[m+'_mean']=statistics.fmean(vals);out[m+'_stdev']=statistics.pstdev(vals)
    summary.append(out)
fields=sorted({k for r in summary for k in r})
outdir=ROOT/'scaling_aggregate';outdir.mkdir(exist_ok=True)
with (outdir/'scaling_summary.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(summary)
with (outdir/'scaling_raw.csv').open('w',newline='',encoding='utf-8') as f:
    fields2=sorted({k for r in rows for k in r});w=csv.DictWriter(f,fieldnames=fields2);w.writeheader();w.writerows(rows)
status={'runs':len(rows),'conditions':len(summary),'budgets':[64,256,1024,2048],'seeds':[21,22,23],'histories':sorted(common),'complete':all(x['seeds']==3 for x in summary)}
(outdir/'status.json').write_text(json.dumps(status,indent=2,sort_keys=True))
print(json.dumps(status,indent=2))
for h in sorted(common):
    print('\n',h)
    for r in summary:
        if r['history']==h:
            print(r['budget'],round(r['text_component_mean'],3),round(r['heldout_text_component_mean'],3),round(r['fused_component_mean'],3),round(r['one_shot_after_mean'],3))
