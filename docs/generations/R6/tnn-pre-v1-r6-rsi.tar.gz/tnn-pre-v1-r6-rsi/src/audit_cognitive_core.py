#!/usr/bin/env python3
"""AST-level anti-hardcoding audit for the R5 cognitive substrate."""
from __future__ import annotations
import ast, json, re, sys
from pathlib import Path

path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name("run_goldilocks_tournament.py")
source=path.read_text(encoding="utf-8")
tree=ast.parse(source)
core_names={
    "stable_hash_bytes","normalize","video_central","frame_tile_features","video_shallow_pam",
    "video_recurrent_pam","audio_central","audio_pam","audio_hybrid_pam","AdaptiveMotifs",
    "PrototypeCell","LocalAssociativeMap","LocalEvidenceMap","SpanEvidence",
    "ContrastiveMotifMemory","SharedBrain",
}
segments=[];refs=[]
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in core_names:
        segments.append(ast.get_source_segment(source,node) or "")
        for sub in ast.walk(node):
            if isinstance(sub,ast.Name):refs.append(sub.id)
core="\n".join(segments)
forbidden_refs={"AGENTS","EVENTS","OBJECTS","STATES","TEMPLATES","HELDOUT_TEMPLATES","history_phases"}
forbidden_surface=(
    "Ava","Ben","Cora","Drew","amber cube","blue ring","moves","supports","follows",
    "According to the scene","What happens is that","who ","pronoun","noun","verb",
    "subject role","object role","grammar rule","English parser","tokenizer vocabulary",
)
llm_patterns=(r"\btransformers?\b",r"\bopenai\b",r"\bchatgpt\b",r"\bllm\b",r"next[_ -]?token")
result={
    "source":str(path),
    "core_nodes":sorted(core_names),
    "core_node_count":len(segments),
    "forbidden_global_references":sorted(forbidden_refs.intersection(refs)),
    "forbidden_surface_matches":[x for x in forbidden_surface if re.search(r"(?<![A-Za-z])"+re.escape(x)+r"(?![A-Za-z])",core,re.I)],
    "llm_matches":[p for p in llm_patterns if re.search(p,core,re.I)],
    "whitespace_tokenizer_calls":len(re.findall(r"\.split\s*\(\s*\)",core)),
    "fixed_vocabulary_reference":int(any(x in refs for x in ("AGENTS","EVENTS","OBJECTS","STATES"))),
}
result["pass"]=all((
    result["core_node_count"]==len(core_names),
    not result["forbidden_global_references"],
    not result["forbidden_surface_matches"],
    not result["llm_matches"],
    result["whitespace_tokenizer_calls"]==0,
    result["fixed_vocabulary_reference"]==0,
))
print(json.dumps(result,indent=2,sort_keys=True))
raise SystemExit(0 if result["pass"] else 1)
