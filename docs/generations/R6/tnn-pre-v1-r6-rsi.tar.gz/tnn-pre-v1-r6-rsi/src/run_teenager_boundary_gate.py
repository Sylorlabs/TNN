#!/usr/bin/env python3
"""Blind boundary evaluation for the TNN R5 Goldilocks candidate.

This evaluator deliberately separates controlled grounded tuple recovery from a
teenager-level English claim.  It imports the frozen generic learner and trains
only through the selected developmental history.  English strings and expected
answers exist in this evaluator, never in the cognitive substrate.

A promotion requires every required capability family, including explicit
abstention and generation.  Missing representations are recorded as NOT_MET;
they are never silently converted into a favorable accuracy score.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import statistics
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("tnn_goldilocks", HERE / "run_goldilocks_tournament.py")
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("unable to load frozen learner")
T = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = T
SPEC.loader.exec_module(T)


def episode_with_text(ep, text: str, state: Sequence[int] | None = None):
    return T.Episode(tuple(state if state is not None else ep.state), ep.video, ep.audio, ep.action,
                     text, ep.source, True)


def mean(xs: Iterable[float]) -> float:
    values = list(xs)
    return statistics.fmean(values) if values else 0.0


def controlled_heldout(brain, test) -> Dict[str, float]:
    components: List[float] = []
    exacts: List[float] = []
    margins: List[float] = []
    for i, ep in enumerate(test):
        text = T.emit_heldout_text(ep.state, i)
        p, m = brain.predict_modality("text", episode_with_text(ep, text))
        components.append(T.accuracy(p, ep.state))
        exacts.append(T.exact(p, ep.state))
        margins.append(float(np.mean(m)))
    return {
        "component_accuracy": mean(components),
        "exact_accuracy": mean(exacts),
        "mean_margin": mean(margins),
        "trials": len(test),
    }


def custom_paraphrases(brain, test) -> Dict[str, float]:
    templates = (
        "During the demonstration, the {o} was {e} {s} by {a}.",
        "{s}, {a} was the one to {e} the {o}.",
        "The person involved was {a}; the action was to {e} the {o}, {s}.",
        "As the scene unfolded, {a} did {e} the {o} {s}.",
    )
    components=[]; exacts=[]
    for i, ep in enumerate(test):
        a,e,o,s = ep.state
        text = templates[i % len(templates)].format(
            a=T.AGENTS[a], e=T.EVENTS[e], o=T.OBJECTS[o], s=T.STATES[s])
        p,_=brain.predict_modality("text", episode_with_text(ep,text))
        components.append(T.accuracy(p,ep.state));exacts.append(T.exact(p,ep.state))
    return {"component_accuracy":mean(components),"exact_accuracy":mean(exacts),"trials":len(test)}


def one_shot_live_labels(brain, test, seed: int) -> Dict[str, float]:
    # A new raw-byte label receives one grounded multimodal exposure, then is
    # queried in an unseen construction.  No label definition enters the core.
    labels = ("naru", "velkin", "torvane", "selora")
    scores=[]; exacts=[]
    for slot in range(T.SLOTS):
        for j in range(4):
            ep=test[(slot*7+j) % len(test)]
            st=list(ep.state)
            value=st[slot]
            train_text=T.emit_text(st, (j+slot) % len(T.TEMPLATES))
            eval_text=T.emit_heldout_text(st, j % len(T.HELDOUT_TEMPLATES))
            old=(T.AGENTS,T.EVENTS,T.OBJECTS,T.STATES)[slot][value]
            novel=f"{labels[slot]}{seed}_{j}"
            train_text=train_text.replace(old,novel)
            eval_text=eval_text.replace(old,novel)
            taught=episode_with_text(ep,train_text,st)
            brain.observe(taught,("video","audio","action","text"),1.0,False,1)
            brain.consolidate(True,1)
            p,_=brain.predict_modality("text",episode_with_text(ep,eval_text,st))
            scores.append(float(p[slot]==value));exacts.append(T.exact(p,st))
    return {"target_role_accuracy":mean(scores),"whole_meaning_exact":mean(exacts),"trials":len(scores)}


def multi_sentence_reference(brain, test) -> Dict[str, float]:
    components=[]; exacts=[]
    # The second clause uses a pronoun, but the only named entity in the discourse
    # is the intended referent.  This is still a much easier case than unrestricted
    # coreference, and it therefore cannot by itself qualify teenager English.
    for i in range(min(48,len(test)-1)):
        ep1=test[i]
        ep2=test[i+1]
        a=ep1.state[0]
        target=(a,ep2.state[1],ep2.state[2],ep2.state[3])
        text=(f"{T.AGENTS[a]} {T.STATES[ep1.state[3]]} {T.EVENTS[ep1.state[1]]} the {T.OBJECTS[ep1.state[2]]}. "
              f"Then they {T.EVENTS[target[1]]} the {T.OBJECTS[target[2]]} {T.STATES[target[3]]}.")
        stream_ep=episode_with_text(ep2,text,target)
        p,_=brain.predict_text_stream(stream_ep)
        components.append(T.accuracy(p,target));exacts.append(T.exact(p,target))
    return {"component_accuracy":mean(components),"exact_accuracy":mean(exacts),"trials":len(exacts)}


def bounded_question_retrieval(brain, test) -> Dict[str, float]:
    components=[]; exacts=[]
    # A declarative episode and an explicit question are supplied together.  The
    # learner still returns its internal tuple rather than natural language.
    for i,ep in enumerate(test[:48]):
        a,e,o,s=ep.state
        text=(T.emit_text(ep.state,i % len(T.TEMPLATES)) + " " +
              f"Who {T.EVENTS[e]} the {T.OBJECTS[o]}, and how did it happen?")
        query_ep=episode_with_text(ep,text)
        p,_=brain.predict_text_stream(query_ep)
        components.append(T.accuracy(p,ep.state));exacts.append(T.exact(p,ep.state))
    return {"component_accuracy":mean(components),"exact_accuracy":mean(exacts),"trials":len(exacts),
            "boundary":"internal tuple retrieval only; no generated answer"}


def unsupported_abstention(brain, test, known_margin: float) -> Dict[str, float]:
    prompts=(
        "Why did the council postpone the vote after the harbor report?",
        "Explain whether the poem's final image changes the narrator's attitude.",
        "A rumor and a direct measurement conflict; which source should control the belief?",
        "What would have happened if the bridge had remained closed?",
        "The phrase 'the room exploded with laughter' is it literal or figurative?",
        "Summarize the argument, identify its weakest assumption, and propose a test.",
        "A student says all winged animals fly. Does one penguin settle the claim?",
        "Who does 'she' refer to when Maya thanked Lena because she was patient?",
    )
    margins=[];predictions=[]
    for i,text in enumerate(prompts):
        ep=test[i % len(test)]
        p,m=brain.predict_modality("text",episode_with_text(ep,text))
        margins.append(float(np.mean(m)));predictions.append(list(map(int,p)))
    # Diagnostic only. The current interface has no explicit UNKNOWN action, so
    # teenager promotion must fail even when confidence happens to be low.
    high=sum(m >= max(0.05,known_margin*0.25) for m in margins)
    return {
        "explicit_unknown_action":False,
        "unsupported_prompts":len(prompts),
        "confident_tuple_outputs":int(high),
        "mean_margin":mean(margins),
        "known_margin_reference":known_margin,
        "predictions":predictions,
        "status":"NOT_MET",
    }


def required_open_capabilities() -> Dict[str, Dict[str, object]]:
    # These are representational/interface inspections backed by direct calls
    # above.  A missing capability is kept as a zero gate, not estimated.
    return {
        "negation_and_polarity":{"score":0.0,"status":"NOT_MET","reason":"state has no proposition polarity"},
        "conditionals_and_counterfactuals":{"score":0.0,"status":"NOT_MET","reason":"no conditional world-state operator"},
        "ambiguous_reference_abstention":{"score":0.0,"status":"NOT_MET","reason":"no explicit ambiguity/unknown action"},
        "source_comparison_in_natural_dialogue":{"score":0.0,"status":"NOT_MET","reason":"provenance exists but no unrestricted language query path"},
        "causal_explanation_generation":{"score":0.0,"status":"NOT_MET","reason":"no language generator"},
        "metaphor_humor_pragmatics":{"score":0.0,"status":"NOT_MET","reason":"no nonliteral/pragmatic representation"},
        "long_document_comprehension":{"score":0.0,"status":"NOT_MET","reason":"single bounded episode interface"},
        "multi_session_save_reload":{"score":0.0,"status":"NOT_MET","reason":"this candidate has no serialized continuing brain state"},
        "free_form_response_generation":{"score":0.0,"status":"NOT_MET","reason":"no decoder or talking interface"},
        "raw_waveform_spoken_english":{"score":0.0,"status":"NOT_MET","reason":"waveforms are controlled factor tones, not speech"},
        "natural_open_world_video":{"score":0.0,"status":"NOT_MET","reason":"video is generated controlled sensor data"},
    }


def run_seed(seed:int,budget:int,n_train:int,n_test:int) -> Dict[str,object]:
    train,test=T.generate_dataset(seed,n_train,n_test)
    brain=T.SharedBrain("recurrent_pam",seed)
    T.train_history(brain,"noisy_then_clean",train,budget,seed)
    controlled=controlled_heldout(brain,test)
    paraphrase=custom_paraphrases(brain,test)
    reference=multi_sentence_reference(brain,test)
    question=bounded_question_retrieval(brain,test)
    abstention=unsupported_abstention(brain,test,float(controlled["mean_margin"]))
    one_shot=one_shot_live_labels(brain,test,seed)
    return {
        "seed":seed,
        "architecture":"recurrent_pam_hybrid_audio",
        "history":"noisy_then_clean",
        "budget":budget,
        "controlled_heldout":controlled,
        "novel_paraphrases":paraphrase,
        "one_shot_grounded_labels":one_shot,
        "multi_sentence_reference":reference,
        "bounded_question_retrieval":question,
        "unsupported_abstention":abstention,
        "open_capabilities":required_open_capabilities(),
        "memory_bytes":brain.memory_bytes(),
        "operations":brain.operations(),
    }


def aggregate(rows:List[Dict[str,object]]) -> Dict[str,object]:
    metric_paths=(
        ("controlled_heldout","component_accuracy"),
        ("controlled_heldout","exact_accuracy"),
        ("novel_paraphrases","component_accuracy"),
        ("novel_paraphrases","exact_accuracy"),
        ("one_shot_grounded_labels","target_role_accuracy"),
        ("one_shot_grounded_labels","whole_meaning_exact"),
        ("multi_sentence_reference","component_accuracy"),
        ("multi_sentence_reference","exact_accuracy"),
        ("bounded_question_retrieval","component_accuracy"),
        ("bounded_question_retrieval","exact_accuracy"),
    )
    metrics={}
    for group,key in metric_paths:
        vals=[float(r[group][key]) for r in rows]  # type: ignore[index]
        metrics[f"{group}.{key}"]={"mean":mean(vals),"min":min(vals),"max":max(vals)}
    required={
        "controlled_exact":metrics["controlled_heldout.exact_accuracy"]["mean"] >= .85,
        "novel_paraphrase_exact":metrics["novel_paraphrases.exact_accuracy"]["mean"] >= .75,
        "one_shot_grounded_label":metrics["one_shot_grounded_labels.target_role_accuracy"]["mean"] >= .75,
        "multi_sentence_reference":metrics["multi_sentence_reference.exact_accuracy"]["mean"] >= .75,
        "question_answering":False,  # tuple retrieval is not a natural answer
        "explicit_abstention":False,
        "negation":False,
        "conditionals":False,
        "ambiguity":False,
        "source_reasoning_dialogue":False,
        "explanation_generation":False,
        "metaphor_humor_pragmatics":False,
        "long_document":False,
        "persistent_multi_session":False,
        "free_form_generation":False,
        "spoken_english":False,
    }
    teenager_pass=all(required.values())
    return {
        "release":"TNN pre-v1 R5 teenager-language boundary gate",
        "seeds":[int(r["seed"]) for r in rows],
        "runs":len(rows),
        "selected_training":{"architecture":"recurrent_pam_hybrid_audio","history":"noisy_then_clean"},
        "metrics":metrics,
        "required_gates":required,
        "teenager_english": "PASS" if teenager_pass else "NOT_MET",
        "adult_english":"NOT_MET",
        "production_tnn_v1":"NOT_PROMOTED",
        "claim_boundary":"High controlled grounded tuple recovery is not unrestricted language comprehension or generation.",
    }


def main() -> None:
    p=argparse.ArgumentParser()
    p.add_argument("--out",type=Path,required=True)
    p.add_argument("--seeds",default="51,52,53,54,55")
    p.add_argument("--budget",type=int,default=512)
    p.add_argument("--train",type=int,default=420)
    p.add_argument("--test",type=int,default=120)
    args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    rows=[run_seed(int(x),args.budget,args.train,args.test) for x in args.seeds.split(",") if x.strip()]
    agg=aggregate(rows)
    (args.out/"per_seed.json").write_text(json.dumps(rows,indent=2,sort_keys=True),encoding="utf-8")
    (args.out/"status.json").write_text(json.dumps(agg,indent=2,sort_keys=True),encoding="utf-8")
    flat=[]
    for r in rows:
        flat.append({
            "seed":r["seed"],
            "controlled_component":r["controlled_heldout"]["component_accuracy"],
            "controlled_exact":r["controlled_heldout"]["exact_accuracy"],
            "paraphrase_component":r["novel_paraphrases"]["component_accuracy"],
            "paraphrase_exact":r["novel_paraphrases"]["exact_accuracy"],
            "one_shot_role":r["one_shot_grounded_labels"]["target_role_accuracy"],
            "one_shot_exact":r["one_shot_grounded_labels"]["whole_meaning_exact"],
            "reference_component":r["multi_sentence_reference"]["component_accuracy"],
            "reference_exact":r["multi_sentence_reference"]["exact_accuracy"],
            "question_tuple_component":r["bounded_question_retrieval"]["component_accuracy"],
            "question_tuple_exact":r["bounded_question_retrieval"]["exact_accuracy"],
            "explicit_abstention":0,
            "free_generation":0,
            "spoken_english":0,
        })
    with (args.out/"summary.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    print(json.dumps(agg,indent=2,sort_keys=True))


if __name__=="__main__":
    main()
