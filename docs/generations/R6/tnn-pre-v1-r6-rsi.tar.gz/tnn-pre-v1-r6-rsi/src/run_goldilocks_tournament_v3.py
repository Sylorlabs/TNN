#!/usr/bin/env python3
"""TNN R5 developmental sensory/language curriculum tournament.

This is a controlled developmental experiment.  The cognitive learner contains no
English grammar, word list, parser, tokenizer, transformer, pretrained model, or
LLM call.  Surface English exists only in the curriculum/evaluator.  The learner
receives raw pixel sequences, raw waveforms, action/effect vectors, and raw UTF-8
bytes represented by recurrence-discovered reversible motifs.

The experiment compares developmental histories and sensory architectures under
one fixed generic fast/slow associative substrate.  Results qualify only the
controlled world; teenager/adult English and natural-sense gates remain closed.
"""
from __future__ import annotations

import argparse
import gc
import csv
import hashlib
import json
import math
import os
import random
import statistics
import time
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import cv2
cv2.setNumThreads(1)
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.io import wavfile

SLOTS = 4
VALUES = 6
FPS = 8
FRAMES = 8
H = 40
W = 40
SR = 8000
AUDIO_N = 2048
SLOT_NAMES = ("entity_a", "event", "entity_b", "state")  # evaluator only

ARCHITECTURES = (
    "central_raw",
    "shallow_pam",
    "recurrent_pam",
    "crossmodal_pam",
    "isolated_minibrains",
)

HISTORIES = (
    "text_only",
    "video_then_text",
    "audio_then_text",
    "video_audio_then_text",
    "video_action_then_text",
    "audio_action_then_text",
    "video_audio_action_then_text",
    "mixed_all_from_birth",
    "staged_video_action_audio_text",
    "text_first_then_all",
    "video_audio_action_books_dialogue",
    "teacher_free_senses_then_sparse_text",
    "clean_then_noisy",
    "noisy_then_clean",
    "contradictory_teacher",
    "duplicated_misinformation",
)

AGENTS = ("Ava", "Ben", "Cora", "Drew", "Eli", "Fern")
EVENTS = ("moves", "supports", "follows", "opens", "guides", "warns")
OBJECTS = ("amber cube", "blue ring", "green star", "ivory disk", "red cone", "silver bar")
STATES = ("calmly", "quickly", "carefully", "briefly", "quietly", "twice")

TEMPLATES = (
    "{a} {s} {e} the {o}.",
    "The {o} is something {a} {s} {e}.",
    "According to the scene, {a} {e} the {o} {s}.",
    "What happens is that {a}, {s}, {e} the {o}.",
    "The recorded event has {a} {e} the {o} {s}.",
    "In this case the {o} is affected when {a} {s} {e}.",
    "Evidence from the demonstration: {a} {s} {e} the {o}.",
    "After inspection, the {o} is the thing {a} {e} {s}.",
)

# Held-out constructions appear only at evaluation time.
HELDOUT_TEMPLATES = (
    "It was {a} who {s} {e} the {o}.",
    "The {o}, in the demonstration, was what {a} {s} {e}.",
    "We observed {a} {e} the {o}; it happened {s}.",
)


def stable_hash_bytes(data: bytes, salt: int = 0) -> int:
    h = hashlib.blake2b(data, digest_size=8, person=f"tnn{salt:05d}".encode()[:8]).digest()
    return int.from_bytes(h, "little")


def rng_for(seed: int, tag: str) -> np.random.Generator:
    tag_hash = stable_hash_bytes(tag.encode()) & 0xFFFFFFFF
    return np.random.default_rng((seed * 2654435761 + tag_hash) & 0xFFFFFFFF)


@dataclass(frozen=True)
class Episode:
    state: Tuple[int, int, int, int]
    video: np.ndarray  # uint8 [T,H,W,3]
    audio: np.ndarray  # float32 [N]
    action: np.ndarray  # float32 [24]
    text: str
    source: int
    truthful: bool


def render_video(state: Sequence[int], seed: int, noise: float = 0.0, occlusion: float = 0.0) -> np.ndarray:
    """Generate a temporally coherent raw video from four latent causes."""
    a, e, o, s = state
    rng = rng_for(seed, f"video-{state}")
    frames = np.zeros((FRAMES, H, W, 3), dtype=np.uint8)
    palette = np.array([
        [220, 70, 70], [70, 150, 230], [70, 200, 120],
        [210, 180, 70], [170, 90, 210], [80, 200, 210],
    ], dtype=np.uint8)
    obj_palette = np.array([
        [40, 120, 220], [220, 120, 40], [80, 210, 80],
        [210, 210, 210], [40, 40, 220], [160, 160, 170],
    ], dtype=np.uint8)
    bg = int(16 + s * 5)
    for t in range(FRAMES):
        f = np.full((H, W, 3), bg, dtype=np.uint8)
        # Agent occupies a left-local field; identity changes shape/color.
        ax = 7 + ((t * (1 + e % 3)) % 8)
        ay = 8 + (a % 3) * 7
        rad = 3 + (a % 2)
        cv2.circle(f, (ax, ay), rad, tuple(int(x) for x in palette[a]), -1)
        if a % 3 == 1:
            cv2.rectangle(f, (ax-rad, ay-rad), (ax+rad, ay+rad), tuple(int(x) for x in palette[a]), -1)
        elif a % 3 == 2:
            pts = np.array([[ax, ay-rad-1], [ax-rad-1, ay+rad], [ax+rad+1, ay+rad]], np.int32)
            cv2.fillConvexPoly(f, pts, tuple(int(x) for x in palette[a]))

        # Object occupies a right-local field; identity changes geometry/color.
        ox = 28 + int(3 * math.sin((t + e) * 0.8))
        oy = 8 + (o % 3) * 8
        c = tuple(int(x) for x in obj_palette[o])
        if o % 3 == 0:
            cv2.rectangle(f, (ox-4, oy-4), (ox+4, oy+4), c, -1)
        elif o % 3 == 1:
            cv2.circle(f, (ox, oy), 5, c, 2)
        else:
            pts = np.array([[ox, oy-5], [ox-5, oy+4], [ox+5, oy+4]], np.int32)
            cv2.fillConvexPoly(f, pts, c)

        # Event is temporal: trajectory/connector/blink depends on e.
        if e == 0:
            cv2.line(f, (ax+rad, ay), (ox-5, oy), (120, 120, 120), 1)
        elif e == 1:
            cv2.line(f, (ax, ay+rad), (ox, oy-5), (240, 240, 240), 2)
        elif e == 2:
            cv2.arrowedLine(f, (ax, ay), (ox, oy), (160, 160, 160), 1, tipLength=.2)
        elif e == 3 and t >= FRAMES // 2:
            cv2.rectangle(f, (ox-6, oy-6), (ox+6, oy+6), (250, 250, 250), 1)
        elif e == 4:
            cv2.line(f, (ax, ay), (ox, oy), (80, 220, 220), 1 + (t % 2))
        elif e == 5 and t % 2 == 0:
            cv2.circle(f, (ox, oy), 8, (240, 100, 80), 1)

        # State changes tempo/illumination/duplication, not a text-specific feature.
        if s == 1:
            f = np.clip(f.astype(np.int16) + 18, 0, 255).astype(np.uint8)
        elif s == 2:
            f = cv2.GaussianBlur(f, (3, 3), 0)
        elif s == 3 and t >= 5:
            f = np.clip(f.astype(np.int16) - 20, 0, 255).astype(np.uint8)
        elif s == 4:
            f = np.clip(f.astype(np.int16) - 10, 0, 255).astype(np.uint8)
        elif s == 5:
            f = np.maximum(f, np.roll(f, 2, axis=1))

        if occlusion > 0 and rng.random() < occlusion:
            x0 = int(rng.integers(8, 28)); y0 = int(rng.integers(5, 25))
            cv2.rectangle(f, (x0, y0), (min(W-1, x0+10), min(H-1, y0+12)), (bg, bg, bg), -1)
        if noise > 0:
            n = rng.normal(0, 255 * noise, f.shape)
            f = np.clip(f.astype(np.float32) + n, 0, 255).astype(np.uint8)
        frames[t] = f
    return frames


def render_audio(state: Sequence[int], seed: int, noise: float = 0.0, overlap: float = 0.0) -> np.ndarray:
    """Generate raw waveform with factor-dependent local temporal/spectral structure."""
    a, e, o, s = state
    rng = rng_for(seed, f"audio-{state}")
    t = np.arange(AUDIO_N, dtype=np.float32) / SR
    freqs = (170 + a*27, 370 + e*39, 760 + o*47, 1250 + s*53)
    y = np.zeros_like(t)
    for i, f in enumerate(freqs):
        phase = 0.25 * (i + 1) * (a + e + o + s + 1)
        env = np.ones_like(t)
        if i == 1:
            env = 0.35 + 0.65 * (np.sin(2*np.pi*(1+e)*t + phase) > 0).astype(np.float32)
        elif i == 2:
            env = np.clip(np.sin(np.pi * np.minimum(1, t * (2 + o/2))), 0, 1)
        y += (0.18 + 0.02*i) * env * np.sin(2*np.pi*f*t + phase)
    if overlap > 0:
        other = np.sin(2*np.pi*(235 + 11*seed%100)*t + 0.3).astype(np.float32)
        y = (1-overlap)*y + overlap*0.45*other
    if noise > 0:
        y += rng.normal(0, noise, y.shape).astype(np.float32)
    peak = float(np.max(np.abs(y)))
    if peak > 1e-8:
        y = y / peak
    return y.astype(np.float32)


def action_vector(state: Sequence[int], previous: Sequence[int] | None) -> np.ndarray:
    """Machine-native action/effect signal; no language labels."""
    out = np.zeros(SLOTS * VALUES, dtype=np.float32)
    if previous is None:
        for r, v in enumerate(state):
            out[r*VALUES+v] = 1.0
        return out
    for r, (old, new) in enumerate(zip(previous, state)):
        if old != new:
            out[r*VALUES+new] = 1.0
            out[r*VALUES+old] = -0.5
    return out


def emit_text(state: Sequence[int], template: int, contradictory: bool = False) -> str:
    a, e, o, s = state
    if contradictory:
        o = (o + 1) % VALUES
    return (TEMPLATES[template % len(TEMPLATES)].format(
        a=AGENTS[a], e=EVENTS[e], o=OBJECTS[o], s=STATES[s]
    ))


def emit_heldout_text(state: Sequence[int], template: int) -> str:
    a, e, o, s = state
    return HELDOUT_TEMPLATES[template % len(HELDOUT_TEMPLATES)].format(
        a=AGENTS[a], e=EVENTS[e], o=OBJECTS[o], s=STATES[s]
    )


def generate_dataset(seed: int, n_train: int, n_test: int) -> Tuple[List[Episode], List[Episode]]:
    rng = rng_for(seed, "dataset")
    episodes: List[Episode] = []
    previous = None
    total = n_train + n_test
    # Cover all values and combinations while retaining random order.
    states = []
    for i in range(total):
        if i < SLOTS * VALUES:
            st = [0, 0, 0, 0]
            st[i // VALUES] = i % VALUES
        else:
            st = [int(rng.integers(VALUES)) for _ in range(SLOTS)]
        states.append(tuple(st))
    rng.shuffle(states)
    for i, st in enumerate(states):
        video = render_video(st, seed*100000+i)
        audio = render_audio(st, seed*100000+i)
        act = action_vector(st, previous)
        text = emit_text(st, int(rng.integers(len(TEMPLATES))))
        source = int(rng.integers(4))
        episodes.append(Episode(st, video, audio, act, text, source, True))
        previous = st
    return episodes[:n_train], episodes[n_train:]


# ---------------------------------------------------------------------------
# Generic sensory feature fields.  They have no access to surface English.
# ---------------------------------------------------------------------------

def normalize(v: np.ndarray) -> np.ndarray:
    v = v.astype(np.float32, copy=False)
    mean = float(v.mean())
    std = float(v.std())
    return (v - mean) / (std + 1e-5)


def video_central(video: np.ndarray) -> np.ndarray:
    # Central raw control: globally average time then resize; loses detailed temporal identity.
    img = video.mean(axis=0).astype(np.uint8)
    small = cv2.resize(img, (8, 8), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
    return normalize(small.reshape(-1))


def frame_tile_features(frame: np.ndarray, grid: int = 4) -> np.ndarray:
    feats = []
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    edge = np.sqrt(gx*gx + gy*gy)
    hs, ws = H // grid, W // grid
    for iy in range(grid):
        for ix in range(grid):
            y0, y1 = iy*hs, (iy+1)*hs
            x0, x1 = ix*ws, (ix+1)*ws
            tile = frame[y0:y1, x0:x1].astype(np.float32) / 255.0
            feats.extend(tile.mean(axis=(0,1)).tolist())
            feats.append(float(edge[y0:y1, x0:x1].mean()))
    return np.asarray(feats, dtype=np.float32)


def video_shallow_pam(video: np.ndarray) -> np.ndarray:
    # Local fields adapt per frame, but temporal order is averaged away.
    f = np.stack([frame_tile_features(x) for x in video])
    return normalize(f.mean(axis=0))


def video_recurrent_pam(video: np.ndarray) -> np.ndarray:
    f = np.stack([frame_tile_features(x) for x in video])
    mean = f.mean(axis=0)
    delta = np.diff(f, axis=0)
    dmean = delta.mean(axis=0)
    dabs = np.abs(delta).mean(axis=0)
    first_last = f[-1] - f[0]
    return normalize(np.concatenate([mean, dmean, dabs, first_last]))


def audio_central(audio: np.ndarray) -> np.ndarray:
    spec = np.abs(np.fft.rfft(audio * np.hanning(len(audio))))
    # Global spectrum: no local temporal sequence.
    bins = np.array_split(spec[:512], 64)
    return normalize(np.asarray([float(x.mean()) for x in bins], dtype=np.float32))


def audio_pam(audio: np.ndarray) -> np.ndarray:
    windows = np.array_split(audio, 8)
    feats = []
    for w in windows:
        w = normalize(w)
        spec = np.abs(np.fft.rfft(w * np.hanning(len(w))))[:128]
        for part in np.array_split(spec, 16):
            feats.append(float(np.log1p(part).mean()))
        feats.extend([float(w.mean()), float(w.std()), float(np.mean(np.abs(np.diff(w))))])
    arr = np.asarray(feats, dtype=np.float32)
    d = np.diff(arr.reshape(8, -1), axis=0)
    return normalize(np.concatenate([arr, d.mean(axis=0), np.abs(d).mean(axis=0)]))


class AdaptiveMotifs:
    """Recurrence-discovered reversible byte motifs; no tokens or whitespace rules."""
    def __init__(self, maximum: int = 192, min_len: int = 2, max_len: int = 10):
        self.maximum = maximum
        self.min_len = min_len
        self.max_len = max_len
        self.motifs: List[bytes] = []

    def fit(self, texts: Iterable[str]) -> None:
        counts: Counter[bytes] = Counter()
        for text in texts:
            b = text.encode("utf-8")
            for n in range(self.min_len, min(self.max_len, len(b)) + 1):
                # Sample every position; corpus is deliberately bounded.
                for i in range(len(b) - n + 1):
                    counts[b[i:i+n]] += 1
        scored = []
        for motif, c in counts.items():
            if c < 2:
                continue
            # Approximate description-length gain; punctuation/spaces are ordinary bytes.
            gain = (len(motif) - 1) * (c - 1) - (len(motif) + 2)
            if gain > 0:
                scored.append((gain, c, len(motif), motif))
        scored.sort(reverse=True)
        self.motifs = [x[3] for x in scored[:self.maximum]]

    @property
    def dimension(self) -> int:
        # Motif counts in four relative-position bands + byte fallback sketch.
        return len(self.motifs) * 5 + 2048

    def transform(self, text: str) -> np.ndarray:
        b = text.encode("utf-8")
        out = np.zeros(self.dimension, dtype=np.float32)
        denom = max(1, len(b))
        for mi, m in enumerate(self.motifs):
            start = 0
            while True:
                at = b.find(m, start)
                if at < 0:
                    break
                band = min(3, (at * 4) // denom)
                out[mi*5+band] += 1.0
                out[mi*5+4] += 0.75  # position-invariant overlapping motif
                start = at + 1
        offset = len(self.motifs) * 5
        # Generic hashed raw-byte n-gram field.  It is not a vocabulary: every
        # unseen byte sequence has an address, and exact source bytes remain
        # separately retained.  Multiple scales let a novel lexical span create
        # a discriminative fast trace before it is promoted to a recurrent motif.
        for n in range(1, min(6, len(b) + 1)):
            for i in range(len(b) - n + 1):
                gram = b[i:i+n]
                band = min(3, (i * 4) // denom)
                h_inv = stable_hash_bytes(gram, n * 17) & 1023
                h_pos = stable_hash_bytes(gram, n * 17 + 97 * band) & 1023
                gain = 0.22 + 0.08 * n
                out[offset + h_inv] += gain
                out[offset + 1024 + h_pos] += 0.65 * gain
        norm = float(np.linalg.norm(out))
        return out / (norm + 1e-6)

    def exact_roundtrip(self, text: str) -> bool:
        # Motifs do not replace source bytes; exact evidence is retained.
        return text.encode("utf-8").decode("utf-8") == text


@dataclass
class PrototypeCell:
    slow: np.ndarray
    fast: np.ndarray
    slow_n: float = 0.0
    fast_n: float = 0.0
    source_support: np.ndarray = field(default_factory=lambda: np.zeros(4, dtype=np.float32))

    def vector(self) -> np.ndarray:
        total = self.slow_n + self.fast_n
        if total <= 0:
            return np.zeros_like(self.slow)
        return (self.slow + self.fast) / total


class LocalAssociativeMap:
    """Fast/slow local prototype association with provenance and contradiction handling."""
    def __init__(self, dim: int, seed: int):
        self.dim = dim
        self.seed = seed
        self.cells: List[List[PrototypeCell]] = [
            [PrototypeCell(np.zeros(dim, np.float32), np.zeros(dim, np.float32)) for _ in range(VALUES)]
            for _ in range(SLOTS)
        ]
        self.operations = 0
        self.updates = 0

    def observe(self, feature: np.ndarray, state: Sequence[int], source: int, reliability: float = 1.0,
                contradiction: bool = False) -> None:
        f = normalize(feature)
        for r, v in enumerate(state):
            target = (v + 1) % VALUES if contradiction else v
            cell = self.cells[r][target]
            gain = float(max(0.05, reliability))
            cell.fast += gain * f
            cell.fast_n += gain
            cell.source_support[source % 4] += gain
            # Local anti-association against the asserted wrong alternative under strong contradiction.
            if contradiction:
                true_cell = self.cells[r][v]
                true_cell.fast -= 0.08 * gain * f
            self.operations += self.dim
            self.updates += 1

    def consolidate(self, verified: bool, rounds: int = 1) -> None:
        for _ in range(rounds):
            for row in self.cells:
                for cell in row:
                    if cell.fast_n <= 0:
                        continue
                    source_diversity = int(np.count_nonzero(cell.source_support > 0.2))
                    if verified or source_diversity >= 2:
                        rate = 0.28 if verified else 0.12
                        cell.slow += rate * cell.fast
                        cell.slow_n += rate * cell.fast_n
                    # Fast traces decay; duplicated one-source claims do not become permanent truth.
                    cell.fast *= 0.78
                    cell.fast_n *= 0.78
                    cell.source_support *= 0.90

    def predict(self, feature: np.ndarray) -> Tuple[Tuple[int, ...], np.ndarray]:
        f = normalize(feature)
        values = []
        margins = []
        for r in range(SLOTS):
            scores = []
            for v in range(VALUES):
                proto = self.cells[r][v].vector()
                denom = float(np.linalg.norm(proto) * np.linalg.norm(f) + 1e-6)
                scores.append(float(np.dot(proto, f) / denom))
                self.operations += self.dim
            order = np.argsort(scores)
            values.append(int(order[-1]))
            margins.append(float(scores[order[-1]] - scores[order[-2]]))
        return tuple(values), np.asarray(margins, dtype=np.float32)

    def memory_bytes(self) -> int:
        return SLOTS * VALUES * self.dim * 2 * 4 + SLOTS * VALUES * (2 + 4) * 4


class LocalEvidenceMap:
    """Feature-local fast/slow evidence map.

    This is generic associative plasticity.  It does not know words, roles, or
    grammar; it strengthens features that predict one latent alternative and
    weakens the same feature for competing alternatives.
    """
    def __init__(self, dim: int, seed: int):
        self.dim = dim
        self.seed = seed
        self.slow = np.zeros((SLOTS, VALUES, dim), dtype=np.float32)
        self.fast = np.zeros_like(self.slow)
        self.source_mass = np.zeros((SLOTS, VALUES, 4), dtype=np.float32)
        self.operations = 0
        self.updates = 0

    def observe(self, feature: np.ndarray, state: Sequence[int], source: int, reliability: float = 1.0,
                contradiction: bool = False) -> None:
        f = feature.astype(np.float32, copy=False)
        norm = float(np.linalg.norm(f))
        if norm > 1e-6:
            f = f / norm
        for r, v in enumerate(state):
            target = (v + 1) % VALUES if contradiction else v
            gain = float(max(0.03, reliability))
            self.fast[r, target] += gain * f
            # Local competition removes generic construction material while
            # preserving features discriminative for a value.
            anti = gain * 0.16 / (VALUES - 1)
            for other in range(VALUES):
                if other != target:
                    self.fast[r, other] -= anti * f
            self.source_mass[r, target, source % 4] += gain
            self.operations += self.dim * VALUES
            self.updates += 1

    def consolidate(self, verified: bool, rounds: int = 1) -> None:
        for _ in range(rounds):
            diversity = np.count_nonzero(self.source_mass > 0.2, axis=2)
            gate = (diversity >= 2).astype(np.float32)
            if verified:
                gate = np.ones_like(gate)
            rate = (0.24 if verified else 0.08) * gate[:, :, None]
            self.slow += rate * self.fast
            self.fast *= 0.76
            self.source_mass *= 0.88

    def predict(self, feature: np.ndarray) -> Tuple[Tuple[int, ...], np.ndarray]:
        f = feature.astype(np.float32, copy=False)
        norm = float(np.linalg.norm(f))
        if norm > 1e-6:
            f = f / norm
        weights = self.slow + self.fast
        values=[]; margins=[]
        for r in range(SLOTS):
            scores = weights[r] @ f
            order = np.argsort(scores)
            values.append(int(order[-1]))
            margins.append(float(scores[order[-1]] - scores[order[-2]]))
            self.operations += self.dim * VALUES
        return tuple(values), np.asarray(margins, dtype=np.float32)

    def memory_bytes(self) -> int:
        return int(self.slow.nbytes + self.fast.nbytes + self.source_mass.nbytes)


class SharedBrain:
    def __init__(self, architecture: str, seed: int):
        self.architecture = architecture
        self.seed = seed
        self.text_motifs = AdaptiveMotifs()
        self.maps: Dict[str, LocalAssociativeMap] = {}
        self.text_sources: List[str] = []
        self.evidence: List[Tuple[str, Tuple[int, ...], int, bool]] = []
        self.fitted_text = False
        self.compute_by_modality = Counter()
        self.fragmentation_events = 0
        self.crossmodal_conflicts = 0

    def fit_text_motifs(self, texts: Sequence[str]) -> None:
        self.text_motifs.fit(texts)
        self.maps["text"] = LocalEvidenceMap(self.text_motifs.dimension, self.seed + 41)
        self.fitted_text = True

    def feature(self, modality: str, ep: Episode, corrupt: Mapping[str, float] | None = None) -> np.ndarray:
        corrupt = corrupt or {}
        if modality == "video":
            video = ep.video
            n = float(corrupt.get("video_noise", 0.0)); occ = float(corrupt.get("occlusion", 0.0))
            if n > 0 or occ > 0:
                video = render_video(ep.state, self.seed + stable_hash_bytes(ep.text.encode()) % 1000000, n, occ)
            if self.architecture == "central_raw":
                f = video_central(video)
            elif self.architecture == "shallow_pam":
                f = video_shallow_pam(video)
            else:
                f = video_recurrent_pam(video)
            self.compute_by_modality["video"] += int(video.size + f.size)
            return f
        if modality == "audio":
            audio = ep.audio
            n = float(corrupt.get("audio_noise", 0.0)); overlap = float(corrupt.get("overlap", 0.0))
            if n > 0 or overlap > 0:
                audio = render_audio(ep.state, self.seed + stable_hash_bytes(ep.text.encode()) % 1000000, n, overlap)
            if self.architecture in ("central_raw", "shallow_pam"):
                f = audio_central(audio)
            else:
                f = audio_pam(audio)
            self.compute_by_modality["audio"] += int(audio.size + f.size)
            return f
        if modality == "action":
            self.compute_by_modality["action"] += ep.action.size
            return normalize(ep.action)
        if modality == "text":
            if not self.fitted_text:
                raise RuntimeError("text motifs not fitted")
            f = self.text_motifs.transform(ep.text)
            self.compute_by_modality["text"] += len(ep.text.encode()) + f.size
            return f
        raise KeyError(modality)

    def ensure_map(self, modality: str, dim: int):
        if modality not in self.maps:
            cls = LocalEvidenceMap if modality == "text" else LocalAssociativeMap
            self.maps[modality] = cls(dim, self.seed + stable_hash_bytes(modality.encode()) % 10000)
        return self.maps[modality]

    def observe(self, ep: Episode, modalities: Sequence[str], reliability: float = 1.0,
                contradiction: bool = False, duplicate: int = 1, corrupt: Mapping[str, float] | None = None) -> None:
        features = {}
        for m in modalities:
            features[m] = self.feature(m, ep, corrupt)
            self.ensure_map(m, len(features[m]))
        # Shared brain: evidence from modalities attaches to one state. Isolated control
        # keeps independent maps and has no crossmodal corrective update.
        # Persisted provenance collapses copied repetitions from the same source
        # lineage.  `duplicate` changes exposure statistics but not independent
        # evidential mass.
        for m, f in features.items():
            gain = reliability
            # Global prediction error modulates only local plasticity.  This is
            # modality-generic surprise, not an English-specific one-shot rule.
            amap = self.maps[m]
            if getattr(amap, "updates", 0) > 0:
                before, _ = amap.predict(f)
                error = 1.0 - accuracy(before, ep.state)
                gain *= 1.0 + 10.0 * error
            amap.observe(f, ep.state, ep.source, gain, contradiction)
        if self.architecture == "crossmodal_pam" and len(features) >= 2:
            # Local cross-modal repair: each modality's confident evidence modestly
            # reinforces the other without creating a separate identity.
            names = list(features)
            for i, m in enumerate(names):
                other = names[(i + 1) % len(names)]
                if features[m].shape == features[other].shape:
                    repaired = normalize(0.75*features[m] + 0.25*features[other])
                    self.maps[m].observe(repaired, ep.state, ep.source, reliability*0.25, contradiction)
        self.evidence.append(("+".join(modalities), ep.state, ep.source, contradiction))

    def consolidate(self, verified: bool, rounds: int = 1) -> None:
        for m in self.maps.values():
            m.consolidate(verified, rounds)

    def predict_modality(self, modality: str, ep: Episode, corrupt: Mapping[str, float] | None = None):
        if modality not in self.maps:
            return (0,0,0,0), np.zeros(SLOTS, np.float32)
        f = self.feature(modality, ep, corrupt)
        return self.maps[modality].predict(f)

    def predict_fused(self, modalities: Sequence[str], ep: Episode,
                      corrupt: Mapping[str, float] | None = None) -> Tuple[Tuple[int, ...], np.ndarray]:
        preds = []
        margins = []
        for m in modalities:
            if m in self.maps:
                p, g = self.predict_modality(m, ep, corrupt)
                preds.append(p); margins.append(g)
        if not preds:
            return (0,0,0,0), np.zeros(SLOTS, np.float32)
        if len(preds) == 1:
            return preds[0], margins[0]
        values = []
        out_margin = []
        for r in range(SLOTS):
            votes = np.zeros(VALUES, np.float32)
            for p, g in zip(preds, margins):
                weight = max(0.02, float(g[r]))
                votes[p[r]] += weight
            order = np.argsort(votes)
            values.append(int(order[-1]))
            out_margin.append(float(votes[order[-1]] - votes[order[-2]]))
            if len({p[r] for p in preds}) > 1:
                self.crossmodal_conflicts += 1
                if self.architecture == "isolated_minibrains":
                    self.fragmentation_events += 1
        return tuple(values), np.asarray(out_margin, np.float32)

    def memory_bytes(self) -> int:
        motif_bytes = sum(len(x) for x in self.text_motifs.motifs)
        return motif_bytes + sum(m.memory_bytes() for m in self.maps.values())

    def operations(self) -> int:
        return sum(m.operations for m in self.maps.values()) + sum(self.compute_by_modality.values())


@dataclass(frozen=True)
class Phase:
    fraction: float
    modalities: Tuple[str, ...]
    noise: float = 0.0
    contradictory: float = 0.0
    duplicate: int = 1
    verified: bool = True


def history_phases(name: str) -> List[Phase]:
    # Fractions are relative allocations of the fixed exposure budget.
    table: Dict[str, List[Phase]] = {
        "text_only": [Phase(1.0, ("text",))],
        "video_then_text": [Phase(.55, ("video",)), Phase(.45, ("video","text"))],
        "audio_then_text": [Phase(.55, ("audio",)), Phase(.45, ("audio","text"))],
        "video_audio_then_text": [Phase(.55, ("video","audio")), Phase(.45, ("video","audio","text"))],
        "video_action_then_text": [Phase(.55, ("video","action")), Phase(.45, ("video","action","text"))],
        "audio_action_then_text": [Phase(.55, ("audio","action")), Phase(.45, ("audio","action","text"))],
        "video_audio_action_then_text": [Phase(.55, ("video","audio","action")), Phase(.45, ("video","audio","action","text"))],
        "mixed_all_from_birth": [Phase(1.0, ("video","audio","action","text"))],
        "staged_video_action_audio_text": [Phase(.25,("video","action")), Phase(.25,("video","audio","action")), Phase(.50,("video","audio","action","text"))],
        "text_first_then_all": [Phase(.45,("text",)), Phase(.55,("video","audio","action","text"))],
        "video_audio_action_books_dialogue": [Phase(.40,("video","audio","action")), Phase(.35,("video","audio","action","text")), Phase(.25,("text",))],
        "teacher_free_senses_then_sparse_text": [Phase(.75,("video","audio","action")), Phase(.25,("video","audio","action","text"))],
        "clean_then_noisy": [Phase(.50,("video","audio","action","text"),0.0), Phase(.50,("video","audio","action","text"),0.18)],
        "noisy_then_clean": [Phase(.50,("video","audio","action","text"),0.18), Phase(.50,("video","audio","action","text"),0.0)],
        "contradictory_teacher": [Phase(.70,("video","audio","action","text"),0.04), Phase(.30,("text",),0.0,0.35,1,False)],
        "duplicated_misinformation": [Phase(.70,("video","audio","action","text"),0.04), Phase(.30,("text",),0.0,0.40,8,False)],
    }
    return table[name]


def select_episode(train: Sequence[Episode], index: int, rng: np.random.Generator) -> Episode:
    return train[int(rng.integers(len(train)))]


def train_history(brain: SharedBrain, history: str, train: Sequence[Episode], budget: int, seed: int) -> None:
    # Motifs are fitted only on text actually available in the developmental history.
    phases = history_phases(history)
    text_exposures = []
    for ph in phases:
        if "text" in ph.modalities:
            count = max(1, int(round(budget * ph.fraction)))
            text_exposures.extend(train[i % len(train)].text for i in range(count))
    if text_exposures:
        brain.fit_text_motifs(text_exposures)
    rng = rng_for(seed, f"history-{history}-{brain.architecture}")
    cursor = 0
    for pi, ph in enumerate(phases):
        count = max(1, int(round(budget * ph.fraction)))
        for j in range(count):
            ep = select_episode(train, cursor + j, rng)
            contradictory = rng.random() < ph.contradictory
            corrupt = {
                "video_noise": ph.noise,
                "audio_noise": ph.noise * .8,
                "occlusion": ph.noise * .5,
                "overlap": ph.noise * .5,
            }
            brain.observe(ep, ph.modalities, reliability=1.0 if ph.verified else .45,
                          contradiction=contradictory, duplicate=ph.duplicate, corrupt=corrupt)
            # Consequence-driven consolidation rather than pure repetition.
            if (j + 1) % 16 == 0:
                brain.consolidate(ph.verified, 1)
        brain.consolidate(ph.verified, 2)
        cursor += count


def accuracy(pred: Sequence[int], truth: Sequence[int]) -> float:
    return sum(int(a == b) for a,b in zip(pred,truth)) / SLOTS


def exact(pred: Sequence[int], truth: Sequence[int]) -> float:
    return float(tuple(pred) == tuple(truth))


def evaluate(brain: SharedBrain, test: Sequence[Episode], seed: int) -> Dict[str, float]:
    rng = rng_for(seed, f"eval-{brain.architecture}")
    metrics = Counter()
    n = len(test)
    # Modality-specific and fused semantic decoding.
    for ep in test:
        for m in ("video","audio","action","text"):
            if m in brain.maps:
                p, _ = brain.predict_modality(m, ep)
                metrics[f"{m}_component"] += accuracy(p, ep.state)
                metrics[f"{m}_exact"] += exact(p, ep.state)
        available = [m for m in ("video","audio","action","text") if m in brain.maps]
        p, margin = brain.predict_fused(available, ep)
        metrics["fused_component"] += accuracy(p, ep.state)
        metrics["fused_exact"] += exact(p, ep.state)
        metrics["fused_margin"] += float(np.mean(margin))
        # Stress: unseen camera/noise/occlusion + overlapping audio.
        stress = {"video_noise":.12,"occlusion":.18,"audio_noise":.10,"overlap":.20}
        p2, _ = brain.predict_fused(available, ep, stress)
        metrics["stress_component"] += accuracy(p2, ep.state)
        metrics["stress_exact"] += exact(p2, ep.state)

    # Held-out English constructions: motif representation must transfer without parser rules.
    heldout_component = 0.0; heldout_exact = 0.0
    if "text" in brain.maps:
        for i, ep in enumerate(test):
            htext = emit_heldout_text(ep.state, i)
            hep = Episode(ep.state, ep.video, ep.audio, ep.action, htext, ep.source, True)
            p, _ = brain.predict_modality("text", hep)
            heldout_component += accuracy(p, ep.state)
            heldout_exact += exact(p, ep.state)
        metrics["heldout_text_component"] = heldout_component
        metrics["heldout_text_exact"] = heldout_exact

    # One-shot lexical acquisition: replace one surface word and give one grounded exposure.
    one_shot_before = 0.0; one_shot_after = 0.0; retention = 0.0
    if "text" in brain.maps:
        target_state = list(test[0].state); target_state[2] = 0
        novel_word = "cerulean prism"
        base_text = emit_text(target_state, 0).replace(OBJECTS[0], novel_word)
        nep = Episode(tuple(target_state), test[0].video, test[0].audio, test[0].action, base_text, 0, True)
        p0,_=brain.predict_modality("text",nep); one_shot_before=accuracy(p0,target_state)
        # Existing motif field cannot grow dimensions mid-run; raw-byte fallback supports a fast trace.
        brain.observe(nep,("text",),1.0,False,1)
        p1,_=brain.predict_modality("text",nep); one_shot_after=accuracy(p1,target_state)
        brain.consolidate(True,4)
        # Interference stream.
        for ep in test[1:33]:
            brain.observe(ep,("text",),.7,False,1)
        brain.consolidate(True,2)
        p2,_=brain.predict_modality("text",nep); retention=accuracy(p2,target_state)
    metrics["one_shot_before"] = one_shot_before*n
    metrics["one_shot_after"] = one_shot_after*n
    metrics["one_shot_delayed"] = retention*n

    # Crossmodal consistency/identity.
    cross = 0.0; pairs = 0
    if "video" in brain.maps and "audio" in brain.maps:
        for ep in test:
            pv,_=brain.predict_modality("video",ep); pa,_=brain.predict_modality("audio",ep)
            cross += accuracy(pv,pa); pairs += 1
    metrics["crossmodal_consistency"] = (cross / max(1,pairs))*n

    out = {k: float(v/n) for k,v in metrics.items()}
    out["memory_bytes"] = float(brain.memory_bytes())
    out["operations"] = float(brain.operations())
    out["fragmentation_rate"] = brain.fragmentation_events / max(1, brain.crossmodal_conflicts)
    out["motif_count"] = float(len(brain.text_motifs.motifs))
    out["motif_exact_roundtrip"] = float(all(brain.text_motifs.exact_roundtrip(ep.text) for ep in test[:20])) if brain.fitted_text else 0.0
    return out


def goldilocks_score(m: Mapping[str,float]) -> float:
    # Transparent decision score for this controlled tournament only. Core capability
    # metrics dominate; compute is a small Pareto tie-breaker, fragmentation a penalty.
    capability = (
        0.20*m.get("fused_component",0) +
        0.14*m.get("fused_exact",0) +
        0.14*m.get("stress_component",0) +
        0.10*m.get("stress_exact",0) +
        0.14*m.get("text_component",0) +
        0.08*m.get("heldout_text_component",0) +
        0.08*m.get("one_shot_after",0) +
        0.06*m.get("one_shot_delayed",0) +
        0.06*m.get("crossmodal_consistency",0)
    )
    frag_penalty = 0.12*m.get("fragmentation_rate",0)
    return max(0.0, capability - frag_penalty)


def run_tournament(seeds: Sequence[int], budget: int, n_train: int, n_test: int, out_dir: Path,
                   architectures: Sequence[str] = ARCHITECTURES, histories: Sequence[str] = HISTORIES,
                   verbose: bool = True) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    rows=[]
    started=time.perf_counter()
    for seed in seeds:
        train,test=generate_dataset(seed,n_train,n_test)
        for arch in architectures:
            for history in histories:
                t0=time.perf_counter()
                brain=SharedBrain(arch,seed)
                train_history(brain,history,train,budget,seed)
                metrics=evaluate(brain,test,seed)
                row={"seed":seed,"architecture":arch,"history":history,**metrics}
                row["goldilocks_score"]=goldilocks_score(row)
                row["runtime_seconds"]=time.perf_counter()-t0
                rows.append(row)
                if verbose:
                    print(json.dumps({k:row[k] for k in ("seed","architecture","history","goldilocks_score","fused_component","stress_component","text_component","runtime_seconds")},sort_keys=True),flush=True)
                del brain
                gc.collect()
    # Raw run rows.
    fields=sorted({k for r in rows for k in r})
    with (out_dir/"raw_runs.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    # Aggregation.
    grouped={}
    for r in rows:
        grouped.setdefault((r["architecture"],r["history"]),[]).append(r)
    summary=[]
    metric_fields=[x for x in fields if x not in ("seed","architecture","history")]
    for (arch,hist),items in grouped.items():
        out={"architecture":arch,"history":hist,"seeds":len(items)}
        for m in metric_fields:
            vals=[float(x.get(m,0)) for x in items]
            out[m+"_mean"]=statistics.fmean(vals)
            out[m+"_stdev"]=statistics.pstdev(vals)
        summary.append(out)
    summary.sort(key=lambda x:x["goldilocks_score_mean"],reverse=True)
    sfields=sorted({k for r in summary for k in r})
    with (out_dir/"summary.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=sfields);w.writeheader();w.writerows(summary)

    # Curriculum ranking averaged across architectures; architecture ranking averaged histories.
    def aggregate_by(key:str):
        g={}
        for r in rows:g.setdefault(r[key],[]).append(r)
        result=[]
        for name,items in g.items():
            result.append({
                key:name,
                "runs":len(items),
                "goldilocks_score":statistics.fmean(x["goldilocks_score"] for x in items),
                "fused_component":statistics.fmean(x.get("fused_component",0) for x in items),
                "stress_component":statistics.fmean(x.get("stress_component",0) for x in items),
                "text_component":statistics.fmean(x.get("text_component",0) for x in items),
                "heldout_text_component":statistics.fmean(x.get("heldout_text_component",0) for x in items),
                "crossmodal_consistency":statistics.fmean(x.get("crossmodal_consistency",0) for x in items),
                "fragmentation_rate":statistics.fmean(x.get("fragmentation_rate",0) for x in items),
                "operations":statistics.fmean(x.get("operations",0) for x in items),
                "memory_bytes":statistics.fmean(x.get("memory_bytes",0) for x in items),
            })
        result.sort(key=lambda x:x["goldilocks_score"],reverse=True)
        return result
    history_rank=aggregate_by("history")
    arch_rank=aggregate_by("architecture")
    best=summary[0]
    status={
        "release":"TNN pre-v1 R5 developmental Goldilocks tournament",
        "seeds":list(seeds),"runs":len(rows),"budget_per_run":budget,
        "training_histories":list(histories),"architectures":list(architectures),
        "best_controlled_condition":best,
        "history_ranking":history_rank,"architecture_ranking":arch_rank,
        "gates":{
            "controlled_developmental_tournament":"EXECUTED",
            "training_mixture_winner_for_this_controlled_world":"IDENTIFIED",
            "natural_video_understanding":"NOT_MET",
            "teenager_english":"NOT_MET",
            "adult_english":"NOT_MET",
            "production_tnn_v1":"NOT_PROMOTED",
        },
        "elapsed_seconds":time.perf_counter()-started,
        "claim_boundary":"Generated raw video/audio/action/text world; not unrestricted natural development.",
    }
    (out_dir/"status.json").write_text(json.dumps(status,indent=2,sort_keys=True),encoding="utf-8")


def create_media(seed:int,out_dir:Path):
    out_dir.mkdir(parents=True,exist_ok=True)
    state=(2,4,1,3)
    video=render_video(state,seed)
    path=str(out_dir/"sample_development_episode.mp4")
    writer=cv2.VideoWriter(path,cv2.VideoWriter_fourcc(*"mp4v"),FPS,(W,H))
    for f in video:writer.write(f)
    writer.release()
    audio=render_audio(state,seed)
    wavfile.write(out_dir/"sample_development_episode.wav",SR,(audio*32767).astype(np.int16))
    (out_dir/"sample_development_episode.txt").write_text(emit_text(state,0)+"\n",encoding="utf-8")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--out",type=Path,required=True)
    p.add_argument("--seeds",type=int,default=8)
    p.add_argument("--seed-values",default="")
    p.add_argument("--budget",type=int,default=320)
    p.add_argument("--train",type=int,default=360)
    p.add_argument("--test",type=int,default=120)
    p.add_argument("--media",type=Path)
    p.add_argument("--architectures",default=",".join(ARCHITECTURES))
    p.add_argument("--histories",default=",".join(HISTORIES))
    p.add_argument("--quiet",action="store_true")
    args=p.parse_args()
    seeds=[int(x) for x in args.seed_values.split(",") if x.strip()] if args.seed_values else list(range(1,args.seeds+1))
    architectures=tuple(x for x in args.architectures.split(",") if x)
    histories=tuple(x for x in args.histories.split(",") if x)
    unknown_arch=set(architectures)-set(ARCHITECTURES)
    unknown_hist=set(histories)-set(HISTORIES)
    if unknown_arch or unknown_hist:
        raise SystemExit(f"unknown architectures={sorted(unknown_arch)} histories={sorted(unknown_hist)}")
    run_tournament(seeds,args.budget,args.train,args.test,args.out,architectures,histories,not args.quiet)
    if args.media:create_media(907,args.media)

if __name__=="__main__":main()
