# R6 claim-to-evidence matrix

| Claim | Evidence | Status |
|---|---|---|
| Failure-triggered shadow revision can beat R5 on new labels | 8-seed calibration/hidden tournament | Supported in bounded generated world |
| Regression can reject a tempting improvement | first schema and broad novelty attempts | Supported |
| Protected support-gap learning preserves old language | hidden 0.991135 before and after | Supported in bounded world |
| New labels can transfer after one grounded example | independent 0.885417 target accuracy | Supported, not perfect |
| More examples always help | delayed curve declines after two | Rejected |
| Adaptive Motifs are fixed human tokens | Motif Microscope | Rejected in this experiment |
| Hardcoded mature language solves general learning | 1.0 covered, 0.0 outside, no senses | Rejected |
| TNN beats humans | no matched participants | Not evaluated |
| TNN has open-ended recursive self-improvement | finite mutation library | Not met |
| TNN has teenager/adult English | required natural gates absent | Not met |
| Production TNN v1 is complete | production gates remain open | Not promoted |
