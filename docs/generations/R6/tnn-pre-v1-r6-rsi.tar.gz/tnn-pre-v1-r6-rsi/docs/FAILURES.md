# R6 failures and boundaries

1. **The first self-revision failed.** One-shot accuracy improved, but familiar
   language regressed. The branch was rolled back.
2. **Broad novelty learning failed catastrophically.** It confused shared raw
   fragments and reduced established-language exactness to about 7% on hidden
   seeds.
3. **One-shot is not perfect.** The independent curve reached 0.8854, not 1.0.
   Some failures begin with an incorrect cross-modal state estimate.
4. **More examples can hurt retention.** Delayed performance peaked at two
   exposures and declined thereafter.
5. **Hardcoded English is brittle.** It scored 1.0 only inside its authored
   grammar, 0 outside it, and had no sensory grounding.
6. **The world remains generated and small.** Four latent factors with six
   alternatives are not natural English or natural perception.
7. **Logic is not yet integrated with unrestricted language.** Prior bounded
   relation mechanisms do not establish adult reasoning through natural speech.
8. **The state format is research-only.** Python pickle is reproducible under a
   pinned hash seed, not a portable production memory format.
9. **Open-ended RSI is not established.** Candidate primitives and promotion
   metrics remain external.
10. **Humans were not tested.** No human-superiority claim is permitted.
