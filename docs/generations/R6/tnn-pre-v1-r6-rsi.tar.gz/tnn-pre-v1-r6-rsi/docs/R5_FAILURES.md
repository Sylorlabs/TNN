# Failures, boundaries, and rollbacks

## 1. More training did not rescue the early language architecture

The pre-contrastive raw-byte learner improved with exposure and then flattened
around 55–65% component accuracy. This triggered architecture work instead of a
claim that more data would eventually solve it automatically.

## 2. Flat and broad novelty memory caused interference

A broad surprise-span branch reached higher one-shot target-role scores in some
runs, but it also:

- overwrote established meanings with accidental cross-sentence spans;
- confused novel labels sharing byte fragments;
- increased operation counts substantially;
- regressed controlled and discourse performance.

It was rolled back. Selective variants improved isolated cases but remained
inconsistent across seeds, so they were not promoted.

## 3. Recurrent local audio discarded stable identity

The original recurrent audio PAM over-normalized local windows. Its accuracy was
far below the central spectrum control in one comparison. The promoted hybrid
keeps a global spectral identity channel and adds recurrent local temporal detail.

## 4. Whole-text decoding mixed multiple clauses

The whole-text decoder frequently selected an object/event/state from the wrong
clause. A generic temporal workspace fixed the bounded test by updating only
roles carrying explicit local motif evidence.

## 5. One-shot cross-construction labels remain weak

The hard boundary gate gives one grounded exposure to a novel raw-byte label and
then changes the construction. Target-role accuracy is only 0.3125 on average.
This is the most immediate language-memory architecture problem.

## 6. “Question answering” is not yet natural conversation

The system can recover a bounded internal state from some question-containing
text, but it has no general response generator. Tuple recovery is not renamed as
English conversation.

## 7. Senses remain controlled

The included MP4/WAV are generated receptor streams. There is no claim of
natural object permanence, arbitrary video understanding, adult speech, or
video-to-skill transfer.

## 8. Teenager and adult gates remain open

There is no implemented general representation for negation, conditionals,
ambiguity, pragmatics, long discourse, explanation generation, or spoken
conversation in the selected candidate.
