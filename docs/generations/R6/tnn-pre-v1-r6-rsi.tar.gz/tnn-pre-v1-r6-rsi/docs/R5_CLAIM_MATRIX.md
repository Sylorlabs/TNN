# Claim-to-evidence matrix

| Claim | Evidence | Status | Boundary |
|---|---|---|---|
| Training mixture was compared rather than assumed | 240-run broad screen plus 42 confirmation runs | SUPPORTED | Controlled generated world |
| Video-only or delayed-language development is best | Ranking tables | REJECTED | It has stronger isolated video but weaker integrated meaning |
| Moderate noisy multimodal experience followed by clean correction is current winner | 5-seed 512 and 3-seed 1024 confirmations | SUPPORTED | Current architecture/world only |
| Mixed multimodal experience from birth is competitive at larger budgets | 1024-exposure ranking | SUPPORTED | Near tie, not universal law |
| Recurrent PAMs are balanced winner | 4-architecture confirmation | SUPPORTED | Shallow PAM is more compute-efficient |
| PAMs and fibers are the same | Architecture definition | REJECTED | PAM = persistent sensory tissue; fiber = temporary cognition |
| Language core contains an English parser/word list | AST audit | REJECTED | Curriculum/evaluator contains English by design |
| Motif-gated workspace improves multi-clause reference | 5-seed control/candidate shadow test | SUPPORTED | Simple bounded discourse |
| One exposure yields robust new labels across constructions | Teen boundary gate | NOT_MET | Mean target-role accuracy 0.3125 |
| Teenager English has passed | Hard boundary gate | NOT_MET | Major required capabilities absent |
| Adult English has passed | Hard boundary gate | NOT_MET | No unrestricted comprehension/generation/speech |
| Natural video/audio understanding has passed | Sensor source inventory | NOT_MET | Generated streams only |
| Production TNN v1 is complete | Production gates | NOT_PROMOTED | Continue pre-v1 lineage |
