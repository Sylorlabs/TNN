# R6 first revision attempt

The first schema revision improved one-shot binding but failed the regression gate. It is preserved here as rollback evidence. The protected support-gap revision in results/rsi_tournament_v2 is the promoted bounded-SAR candidate.
