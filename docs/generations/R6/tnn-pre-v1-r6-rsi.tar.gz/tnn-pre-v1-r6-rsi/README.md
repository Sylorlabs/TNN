# TNN pre-v1 R6 — bounded self-revision and learning-efficiency frontier

R6 continues the verified R5 Goldilocks lineage. It adds:

- a failure-triggered architecture tournament;
- shadow evaluation, rollback, and hidden promotion;
- Grounded Contrastive Schema Memory;
- support-gap one-shot recruitment;
- a protected novelty fast path;
- a Motif Microscope;
- 1/2/4/8-exposure learning curves;
- an isolated hardcoded-English prosthesis control;
- deterministic state rebuild and save/reload checks.

The selected candidate raises hidden one-shot cross-construction target accuracy
from 0.3438 to 0.8281 while preserving established language. An independent
concept curve reaches 0.8854 after one grounded example.

This is not teenager/adult English, natural video/speech understanding,
human-superior learning, open-ended recursive self-improvement, AGI, or
production TNN v1.

## Verify

```bash
make verify
```

## Principal evidence

```text
results/rsi_tournament_v2/
results/learning_efficiency/
results/motif_microscope/
attempts/r6_unprotected_revision/
state/state-status.json
```

Read `docs/R6_RESULTS.md`, `docs/R6_FAILURES.md`, and
`docs/NEXT_STAGE_HANDOFF_R6.md` before making claims.
