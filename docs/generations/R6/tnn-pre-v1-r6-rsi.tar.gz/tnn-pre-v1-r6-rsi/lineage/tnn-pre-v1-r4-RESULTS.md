# TNN pre-v1 R4 results — Contrastive Motif Induction

R4 is a verified extension of the R3 lineage. It does not replace R3's
hypothesis, memory, provenance, clarification, or persistent-teaching results.
It adds a generic language-development mechanism whose cognitive core contains
no surface-language strings, fixed vocabulary, whitespace tokenizer, phrase
table, transformer, gradient framework, or LLM call.

## Mechanism

**Contrastive Motif Induction (CMI)** receives raw byte streams aligned with
changes in grounded world factors. When several experiences differ in one
factor while the remaining situation is stable, CMI finds their shared prefix
and suffix and recruits the variable region as a motif for that factor.

The learned hierarchy is:

```text
raw bytes
  -> contrastively discovered variable spans
  -> grounded role/value motifs
  -> learned ordered construction cells
  -> grounded tuple / learned surface generation
```

No word boundary is supplied. Spaces are ordinary bytes. Construction order is
learned from the positions of the discovered spans. A learned construction can
then provide the boundary for a novel lexical form after one grounded exposure.

Conflicting meanings are stored in context-specific motif banks selected by a
noisy sensory context cue. They remain parts of one shared `CmiBrain`; they are
not separate agents or private sensory minds.

## Promoted R4 evidence

The strict C experiment is `experiments/r460_contrastive_motif_induction.c`.
The generic cognitive implementation is isolated in `src/cmi.c` and
`src/cmi.h`. Forty deterministic randomized worlds were run under GCC and
Clang with byte-identical outputs.

| Metric | R4 | Control / boundary |
|---|---:|---:|
| arbitrary randomized surface tuple accuracy | 1.000000 | shuffled grounding 0.000000 |
| no-space surface tuple accuracy | 1.000000 | whitespace tokenizer not used |
| conflicting-context accuracy | 1.000000 | single shared context 0.143063 |
| first-context retention after conflicting context | 1.000000 | single shared context 0.143063 |
| new construction after one contrastive lesson | 1.000000 | whole-utterance memory 0.000000 |
| new lexical form after one grounded exposure | 1.000000 | chance 0.125000 |
| controlled ordinary-English tuple accuracy | 1.000000 | shuffled grounding 0.000000 |
| learned generation round-trip | 1.000000 | stored whole sentence 0.000000 |
| hierarchical operation ratio | 0.008086 | exhaustive flat n-gram evaluation 1.000000 |
| English-surface operation ratio | 0.011317 | exhaustive flat n-gram evaluation 1.000000 |
| one view with 2% byte substitution | 0.360187 | clean 1.000000 |
| five-view recurrent stabilization at 2% | 1.000000 | single view 0.360187 |
| five-view stabilization at 18% corruption | 0.804813 | required 0.950000 |
| exact save/reload continuation | 1.000000 | required 1.000000 |
| mean learned contexts | 2.000000 | maximum 4 |

The operation ratio counts semantic feature evaluations, not wall-clock time,
energy, or total hardware cost. It is valid only for this controlled
architecture comparison.

## Anti-hardcoding audit

`scripts/audit_r4_language_core.py` establishes:

```text
R4_LANGUAGE_CORE_SURFACE_STRINGS=0
R4_WHITESPACE_TOKENIZER=0
R4_FIXED_VOCABULARY=0
R4_LLM_WRAPPER=0
R4_CORE_CURRICULUM_SEPARATION_PASS=1
```

The English phrases and artificial byte surfaces exist only in the experiment
that supplies developmental experiences and evaluates behavior. They are not in
the learner. The same unmodified learner is tested on randomized lexicons,
no-space surfaces, reversed orders, conflicting mappings, and English-like
surfaces.

## Verification

The R4 experiment passes:

```text
GCC strict compilation                         PASS
Clang strict compilation                       PASS
GCC/Clang output identity                      PASS
fresh output versus promoted output            PASS
AddressSanitizer                               PASS
UndefinedBehaviorSanitizer                     PASS
leak detection                                 PASS
exact pointer-free state save/reload           PASS
R4 Zag static source contract                  PASS
native Zag quantitative parity                 NOT ESTABLISHED
```

Run:

```bash
make r4
make sanitizers-r4
make verify
```

## Gate decision

```text
controlled hierarchical language discovery    SUPPORTED
controlled learned surface generation          SUPPORTED
teenager-level English                         NOT_MET
adult written English                          NOT_MET
adult spoken English                           NOT_MET
natural open-world senses                      NOT_MET
self-architecture revision                     NOT_MET
production TNN v1                              NOT_PROMOTED
```

R4 is a real improvement over the R3 parser path because the cognitive mechanism
learns its motifs and construction boundaries from grounded variation. It is
still a bounded developmental experiment, not teenager-level discourse.
