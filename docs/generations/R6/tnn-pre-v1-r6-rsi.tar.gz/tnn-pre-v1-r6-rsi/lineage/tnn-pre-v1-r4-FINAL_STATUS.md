# TNN pre-v1 R4 final status

## Release decision

```text
RELEASE=TNN pre-v1 R4
R3_ACCEPTED_LINEAGE_REVERIFIED=1
R4_CONTRASTIVE_MOTIF_INDUCTION=SUPPORTED_CONTROLLED
R4_ANTI_HARDCODING_AUDIT=PASS
R4_GCC_CLANG_EXACT_PARITY=PASS
R4_ASAN_UBSAN_LEAK=PASS
R4_EXACT_STATE_RELOAD=PASS
TEENAGER_ENGLISH_GATE=0
ADULT_ENGLISH_GATE=0
NATURAL_SENSES_GATE=0
SELF_ARCHITECTURE_REVISION_GATE=0
NATIVE_ZAG_QUANTITATIVE_PARITY=0
PRODUCTION_TNN_V1=NOT_PROMOTED
```

R4 is accepted as the next **research checkpoint**, not as the requested
teenager-English endpoint. It replaces the failed parser-style continuation
with a generic learner that discovers variable byte spans, grounded motifs,
construction order, and context-specific mappings from controlled contrasts.

## What R4 establishes

- The unmodified cognitive core works on randomized byte languages, no-space
  languages, conflicting contextual mappings, and a controlled English surface.
- The core contains no English phrases, fixed vocabulary, whitespace tokenizer,
  phrase grammar, transformer, LLM call, or gradient framework.
- One contrastive lesson recruits a new construction in the controlled world.
- One grounded exposure recruits a new lexical form once a construction exists.
- Exact state save/reload preserves learned behavior.
- Five-view temporal stabilization repairs moderate independent byte corruption,
  while severe corruption remains an explicit failure boundary.
- All promoted R3 evidence remains present and reverified.

## What R4 does not establish

- teenager-equivalent conversation, reading, writing, pragmatics, humor,
  metaphor, broad knowledge, or long discourse;
- natural raw-waveform speech or continuous open-world vision;
- endogenous discovery of every useful contrast from action and attention;
- learned resource allocation inside the complete persistent brain;
- TNN-originated self-architecture revision;
- native Zag quantitative authority or real Zag programming competence.

## Quantitative inventory

```text
promoted programs             51
preserved attempt sources     77
promoted evidence rows       461
reported seeded evaluations 37,801
R4 evidence rows              20
```

The quantitative authority is `results/promoted-evidence.csv`. Controlled R4
interpretation is documented in `docs/R4_RESULTS.md`; failures and forbidden
claims are documented in `docs/R4_FAILURES.md` and
`docs/R4_CLAIM_MATRIX.md`.
