# R4 to R5 research handoff

R5 must continue from the accepted R4 state and must not restore a hand-authored
English parser. The central objective is to turn supplied contrastive learning
opportunities into **endogenously selected sensory experiments**, then test the
same learned hierarchy in natural discourse.

## 1. Integrate R3 evidence memory with R4 language induction

R4 currently returns grounded tuples and learned surfaces. R5 should connect
those tuples to R3's persistent provenance, contradiction, abstention, episodic
trace, slow consolidation, and hypothesis workspace. A sentence must not become
truth merely because its surface was parsed. The state should preserve:

- exact observed or taught surface evidence;
- the inferred grounded structure;
- source and context;
- current support and conflicts;
- uncertainty and alternative interpretations;
- later revisions without deleting prior evidence.

## 2. Replace supplied contrasts with active contrast discovery

The evaluator currently arranges examples in which one factor changes. R5 must
learn to create or seek those comparisons using ordinary actions:

- reorient or reinspect a sensor;
- repeat an action while holding other conditions stable;
- ask a teacher for a contrasting example;
- search or execute a tool test when sources disagree;
- choose the experiment on which live hypotheses disagree most.

The action selector must operate over predicted information gain and downstream
utility learned from consequences, not a named hardcoded "language-question"
mode.

## 3. Attach CMI to PAM sensory streams

PAMs remain persistent peripheral sensory tissue, while fibers remain temporary
concurrent cognition. R5 should feed temporal visual and audio motifs into the
same CMI/R3 shared state. Required comparisons:

- central raw processing;
- shallow PAMs;
- recurrent PAMs;
- cross-modal PAM repair;
- isolated sensory mini-brains as a fragmentation control;
- PAM growth/pruning and lesion reorganization.

The next sensory gate should use continuous sequences, active reinspection,
occlusion, speaker variation, overlap, lighting changes, and mismatched
cross-modal evidence.

## 4. Replace exact motif equality with calibrated recurrent matching

R4 fails on a corrupted single view because learned literals are exact. R5
should compare:

- edit-tolerant byte motifs;
- temporal recurrent motif evidence;
- overlapping hierarchical motifs;
- context-conditioned motif competition;
- cross-modal repair;
- abstention and targeted reinspection when the best/runner-up margin is small.

Every fuzzy mechanism must retain exact reversible source evidence separately
from its approximate recognition state.

## 5. Natural developmental-language tournament

Use one frozen cognitive implementation across multiple developmental histories:

- vision/action before text;
- audio/action before text;
- mixed audiovisual interaction;
- text-first control;
- clean then noisy instruction;
- noisy then clean instruction;
- contradictory teachers;
- teacher-free exploration;
- grounded demonstrations plus books/dialogue.

Language-specific labels may exist in the curriculum and evaluator, never in
the cognitive core. Evaluation must include unseen vocabulary, unseen
constructions, long reference chains, narratives, ambiguity, correction,
metaphor, humor, social inference, explanation, source adjudication, and
multi-session retention.

## 6. Resource-envelope compute tournament in the integrated brain

The owner specifies CPU/accelerator, RAM, storage, sensor bandwidth, and tool
concurrency. The TNN must learn which fibers exist and how much resource each
receives. Compare equal, serial, fixed-priority, and learned resource-elastic
allocation under matched accuracy. Report:

- wall-clock median and p95 latency;
- total operations and memory traffic;
- peak and retained memory;
- tool deduplication and stale-work rejection;
- energy proxy where measurable;
- task completion and delayed retention;
- resource allocation by context.

R4's operation ratio is only a controlled semantic-feature count and must not be
substituted for these measurements.

## 7. Begin bounded Self-Architecture Revision (SAR)

R5 should let the persistent brain identify a recurring failure, propose a local
variant, fork an exact shadow state, compare hidden tasks and replay, and either
promote or roll back. Start with safe bounded choices:

1. choose among known motif matchers;
2. tune or compose them;
3. recruit a local operator;
4. retain context-specific alternatives rather than forcing global replacement.

Promotion must require delayed regression tests, source/state provenance, and
exact rollback. The evaluator may define safety boundaries, but it must not
select the winning architecture for TNN.

## Promotion rule

Do not label R5 teenager English because a controlled template suite passes.
Promotion requires a blind, frozen-source natural-language battery with
sustained conversation, reading, writing, live concept learning, provenance,
uncertainty, and multi-session retention in the same persistent brain used for
senses and tools.
