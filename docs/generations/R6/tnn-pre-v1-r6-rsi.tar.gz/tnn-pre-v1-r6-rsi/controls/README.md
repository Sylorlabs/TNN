# Controls

The hardcoded English prosthesis is implemented inside
`src/run_r6_learning_efficiency.py` as an evaluator control. It contains
human-authored templates, slot identities, and lexicon insertion. It is
intentionally excluded from the cognitive-core and production gates.
