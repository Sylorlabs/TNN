# R6 release notes

- Preserves the R5 Goldilocks training and PAM decision.
- Adds bounded SAR/CAR with hidden promotion.
- Rejects the first unprotected schema revision and broad novelty control.
- Promotes protected support-gap schema memory as a research candidate.
- Adds motif inspection, hardcoded-English control, sample-efficiency curves,
  and a persistent selected state.
- Keeps human superiority, open-ended RSI, teenager/adult English, natural
  senses, and production TNN v1 explicitly unpromoted.
