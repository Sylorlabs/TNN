#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sha256sum -c MANIFEST.sha256
python scripts/verify.py
