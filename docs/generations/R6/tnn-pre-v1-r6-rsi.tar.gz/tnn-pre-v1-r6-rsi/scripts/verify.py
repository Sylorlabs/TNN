#!/usr/bin/env python3
from __future__ import annotations
import csv,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks={}
def run(cmd,env=None):return subprocess.run(cmd,check=True,text=True,capture_output=True,env=env)
def loadj(rel):return json.loads((ROOT/rel).read_text())
def csvrows(rel):
 with (ROOT/rel).open(newline='') as f:return list(csv.DictReader(f))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

# Syntax and anti-hardcoding audits.
py=sorted((ROOT/'src').glob('*.py'))
run([sys.executable,'-m','py_compile',*[str(x) for x in py]])
r5audit=json.loads(run([sys.executable,str(ROOT/'src/audit_cognitive_core.py'),str(ROOT/'src/run_goldilocks_tournament.py')]).stdout)
r6audit=json.loads(run([sys.executable,str(ROOT/'src/audit_r6_core.py')]).stdout)
checks['r5_core_audit']=r5audit['pass'] is True
checks['r6_core_audit']=r6audit['pass'] is True
checks['no_hardcoded_control_in_core']=r6audit['hardcoded_control_in_core'] is False
checks['no_whitespace_tokenizer']=r6audit['whitespace_tokenizer_calls']==0

# Preserve R5 Goldilocks evidence and locked boundaries.
broad=loadj('results/broad_aggregate/status.json');b512=loadj('results/training_confirmation_b512_aggregate/status.json');b1024=loadj('results/training_confirmation_b1024_aggregate/status.json');arch=loadj('results/architecture_confirmation_b512_aggregate/status.json');disc=loadj('results/discourse_workspace_confirmation/status.json');teen=loadj('results/teenager_boundary_gate_v6/status.json')
checks['r5_broad_240_runs']=broad['complete'] and broad['runs']==240
checks['r5_medium_winner']=b512['history_ranking'][0]['history']=='noisy_then_clean'
checks['r5_large_winner']=b1024['history_ranking'][0]['history']=='noisy_then_clean'
checks['r5_pam_winner']=arch['architecture_ranking'][0]['architecture']=='recurrent_pam'
checks['r5_discourse_promoted']=disc['promotion']['selected'] is True
checks['r5_teenager_locked']=teen['teenager_english']=='NOT_MET'

# R6 failure, revision, and hidden promotion.
first=loadj('attempts/r6_unprotected_revision/status.json');final=loadj('results/final_status.json');rsi=loadj('results/rsi_tournament_v2/status.json');decision=loadj('results/rsi_tournament_v2/revision_decision.json')
checks['first_revision_rejected']=first['status']=='NOT_PROMOTED'
checks['second_revision_hidden_pass']=decision['hidden_promotion_pass'] is True
checks['selected_candidate']=decision['round2_policy_selection']['candidate']=='grounded_schema_balanced'
h=decision['hidden_selected']
checks['hidden_one_shot']=h['cross_frame_target']>=.80
checks['hidden_fragment']=h['fragment_target']>=.80
checks['hidden_delayed']=h['delayed_target']>=.80
checks['hidden_established_regression']=h['established_regression']<=.001
checks['hidden_sensory_regression']=h['sensory_regression']<=.02
checks['hidden_snapshot_pass']=h['snapshot_pass_rate']==1.0
checks['bounded_sar_pass']=rsi['bounded_sar']=='PASS' and final['bounded_sar']=='PASS'
checks['open_ended_rsi_locked']=final['open_ended_recursive_self_improvement']=='NOT_MET'
checks['human_superiority_locked']=final['human_superiority']=='NOT_EVALUATED'
checks['language_gates_locked']=final['teenager_english']=='NOT_MET' and final['adult_english']=='NOT_MET'
checks['production_locked']=final['production_tnn_v1']=='NOT_PROMOTED'

# Motif microscope.
micro=csvrows('results/motif_microscope/summary.csv')
contrast=[r for r in micro if r['source']=='contrastive_memory' and r['budget']=='512']
checks['motif_microscope_complete']=len(contrast)==2
checks['contrastive_grounding_alignment']=all(float(r['known_surface_aligned_fraction'])>=.95 for r in contrast)

# Independent one/few-shot curves and hardcoded control.
curves=csvrows('results/learning_efficiency/learning_curves.csv')
def curve(learner,n):return next(r for r in curves if r['learner']==learner and r['exposures']==str(n))
one=curve('grounded_schema_balanced',1);two=curve('grounded_schema_balanced',2);r5=curve('r5_unchanged',1);near=curve('nearest_surface_control',1)
checks['independent_one_shot']=float(one['target_accuracy'])>=.85
checks['one_shot_beats_r5']=float(one['target_accuracy'])>=float(r5['target_accuracy'])+.45
checks['one_shot_beats_nearest']=float(one['whole_meaning_exact'])>=float(near['whole_meaning_exact'])+.80
checks['two_exposure_delayed']=float(two['delayed_target_accuracy'])>=.90
hard=loadj('results/learning_efficiency/hardcoded_control.json')
checks['hardcoded_covered']=hard['covered_grammar_exact']==1.0
checks['hardcoded_outside_fails']=hard['outside_authored_grammar_exact']==0.0
checks['hardcoded_no_senses']=hard['prosthesis_has_sensory_grounding'] is False
checks['hardcoded_withdrawal_fails']=hard['withdrawal_without_internal_training_exact']==0.0

# Media decode remains available without pretrained semantics.
import cv2
from scipy.io import wavfile
cap=cv2.VideoCapture(str(ROOT/'media/sample_development_episode.mp4'));frames=0
while True:
 ok,_=cap.read()
 if not ok:break
 frames+=1
cap.release();sr,wav=wavfile.read(ROOT/'media/sample_development_episode.wav')
checks['media_video_frames']=frames==8
checks['media_audio']=sr==8000 and len(wav)==2048

# Canonical selected state hash, deterministic rebuild under pinned hash seed,
# and prediction-preserving reload.
state=loadj('state/state-status.json');state_path=ROOT/'state/r6-selected-state.pkl'
checks['state_hash_matches']=sha(state_path)==state['sha256']
checks['state_reload_parity']=state['reload_prediction_parity'] is True
env=dict(os.environ);env['PYTHONHASHSEED']='0'
with tempfile.TemporaryDirectory() as td:
 a=Path(td)/'a';b=Path(td)/'b'
 run([sys.executable,str(ROOT/'src/build_r6_selected_state.py'),'--out',str(a),'--seed','13'],env=env)
 run([sys.executable,str(ROOT/'src/build_r6_selected_state.py'),'--out',str(b),'--seed','13'],env=env)
 checks['state_rebuild_byte_determinism']=(a/'r6-selected-state.pkl').read_bytes()==(b/'r6-selected-state.pkl').read_bytes()==state_path.read_bytes()
 # Reduced deterministic R6 candidate smoke in two fresh processes.
 sa=Path(td)/'seed-a.json';sb=Path(td)/'seed-b.json'
 run([sys.executable,str(ROOT/'src/run_r6_seed.py'),'--seed','31','--out',str(sa),'--budget','128','--train','96','--test','48'],env=env)
 run([sys.executable,str(ROOT/'src/run_r6_seed.py'),'--seed','31','--out',str(sb),'--budget','128','--train','96','--test','48'],env=env)
 checks['r6_deterministic_smoke']=sa.read_bytes()==sb.read_bytes()

failed=[k for k,v in checks.items() if not v]
print(json.dumps({'checks':checks,'failed':failed,'pass':not failed},indent=2,sort_keys=True))
raise SystemExit(1 if failed else 0)
