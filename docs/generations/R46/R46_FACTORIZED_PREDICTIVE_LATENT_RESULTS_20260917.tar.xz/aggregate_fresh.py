from pathlib import Path
import json
import statistics

D = Path(__file__).resolve().parent
rows = [json.loads(p.read_text()) for p in sorted((D / "fresh_jobs").glob("*.json"))]
selected = json.loads((D / "DEV_RESULTS.json").read_text())["selected_for_fresh"]
if not selected:
    raise SystemExit("fresh aggregation is not authorized: no selected development candidate")

def rows_for(name):
    return [r for r in rows if r["candidate"] == name]

def mean(name, key, scenario=None):
    vals = [r["result"][key] for r in rows_for(name) if (scenario is None or r["scenario"] == scenario) and r["result"][key] is not None]
    return statistics.mean(vals)

def summary(name):
    rs = rows_for(name)
    diag = [r["result"]["diag"] for r in rs]
    out = {"rows": len(rs), "mean_regret": mean(name, "mean_regret"), "post_change_regret": mean(name, "post_change_regret"), "return_regret": mean(name, "return_regret"), "cost_reversal_return": mean(name, "return_regret", "cost_reversal_return"), "stationary_spikes_mean": mean(name, "mean_regret", "stationary_spikes"), "max_success_experts": max(x.get("success_experts", 1) for x in diag), "max_cost_experts": max(x.get("cost_experts", 1) for x in diag), "min_residual_updates": min(x.get("latent_residual_updates", 0) for x in diag), "mean_abs_utility_correction": statistics.mean(x.get("mean_abs_utility_correction", 0.0) for x in diag)}
    v2 = {(r["seed"], r["scenario"]): r["result"] for r in rows_for("v2")}
    ratios = []
    for row in rs:
        b = v2[(row["seed"], row["scenario"])]
        x = row["result"]
        if x["return_regret"] is not None and b["return_regret"] not in (None, 0):
            ratios.append(x["return_regret"] / b["return_regret"])
    out["worst_return_ratio_vs_v2"] = max(ratios) if ratios else None
    return out

summaries = {name: summary(name) for name in ["v2", "r36", "r39", selected]}
base = summaries["r39"]
x = summaries[selected]
gates = {"mean_regret": x["mean_regret"] <= 0.98 * base["mean_regret"], "mean_return": x["return_regret"] <= 0.95 * base["return_regret"], "post_change": x["post_change_regret"] <= base["post_change_regret"], "cost_reversal_return": x["cost_reversal_return"] <= 0.95 * base["cost_reversal_return"], "stationary_spikes": x["stationary_spikes_mean"] <= 1.02 * base["stationary_spikes_mean"], "worst_return": x["worst_return_ratio_vs_v2"] < base["worst_return_ratio_vs_v2"], "bounded": x["max_success_experts"] <= 5 and x["max_cost_experts"] <= 5, "exercised": x["min_residual_updates"] >= 100 and x["mean_abs_utility_correction"] >= 0.003}
out = {"status": "R46_FRESH", "selected_candidate": selected, "job_count": len(rows), "controls": {name: summaries[name] for name in ["v2", "r36", "r39"]}, "candidate": {**x, "gates": gates, "pass": all(gates.values())}, "fresh_pass": all(gates.values())}
(D / "FRESH_RESULTS.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
print(json.dumps(out, indent=2, sort_keys=True))
