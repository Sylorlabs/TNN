from pathlib import Path
import concurrent.futures
import json
import os
import subprocess
import sys

D = Path(__file__).resolve().parent
OUT = D / "fresh_jobs"
OUT.mkdir(exist_ok=True)

selected = json.loads((D / "DEV_RESULTS.json").read_text()).get("selected_for_fresh")
if not selected:
    raise SystemExit("fresh execution is not authorized: no development candidate selected")

SEEDS = [46011, 46023, 46037, 46051]
SCENARIOS = ["very_long_return", "cost_reversal_return", "corruption_then_return", "delayed_recombine", "gradual_dynamics", "stationary_spikes"]
CANDIDATES = ["v2", "r36", "r39", selected]

jobs = []
for seed in SEEDS:
    for scenario in SCENARIOS:
        for candidate in CANDIDATES:
            out = OUT / f"{seed}_{scenario}_{candidate}.json"
            if not out.exists():
                jobs.append((seed, scenario, candidate, out))

env = os.environ.copy()
env.update({
    "OPENBLAS_NUM_THREADS": "1",
    "OMP_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
})


def run_one(job):
    seed, scenario, candidate, out = job
    proc = subprocess.run(
        [sys.executable, str(D / "r46_factorized_latent_residual.py"), "--fresh", "--seed", str(seed), "--scenario", scenario, "--candidate", candidate, "--out", str(out)],
        capture_output=True,
        text=True,
        env=env,
    )
    return {
        "seed": seed,
        "scenario": scenario,
        "candidate": candidate,
        "rc": proc.returncode,
        "stderr": proc.stderr[-2000:],
    }


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    status = list(pool.map(run_one, jobs))

(D / "FRESH_JOB_STATUS.json").write_text(json.dumps(status, indent=2, sort_keys=True) + "\n")
if any(row["rc"] for row in status):
    raise SystemExit(1)
(D / "FRESH_JOBS_COMPLETE").write_text("PASS\n")
print(f"completed {len(status)} jobs for {selected}")
