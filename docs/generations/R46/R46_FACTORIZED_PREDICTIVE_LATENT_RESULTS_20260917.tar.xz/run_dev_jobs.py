from pathlib import Path
import concurrent.futures
import json
import os
import subprocess
import sys

D = Path(__file__).resolve().parent
OUT = D / "dev_jobs"
OUT.mkdir(exist_ok=True)

SEEDS = [36501, 36507, 36513, 36519]
SCENARIOS = ["staggered_return", "cost_recurrence", "unseen_pairing", "double_recombine", "cross_noise"]
CANDIDATES = ["latent_cautious", "latent_balanced", "latent_fast"]

jobs = []
for seed in SEEDS:
    for scenario in SCENARIOS:
        for candidate in CANDIDATES:
            out = OUT / f"{seed}_{scenario}_{candidate}.json"
            if not out.exists():
                jobs.append((seed, scenario, candidate, out))

env = os.environ.copy()
env.update({
    "OPENBLAS_NUM_THREADS": "1",
    "OMP_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
})


def run_one(job):
    seed, scenario, candidate, out = job
    proc = subprocess.run(
        [sys.executable, str(D / "r46_factorized_latent_residual.py"), "--seed", str(seed), "--scenario", scenario, "--candidate", candidate, "--out", str(out)],
        capture_output=True,
        text=True,
        env=env,
    )
    return {
        "seed": seed,
        "scenario": scenario,
        "candidate": candidate,
        "rc": proc.returncode,
        "stderr": proc.stderr[-2000:],
    }


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    status = list(pool.map(run_one, jobs))

(D / "DEV_JOB_STATUS.json").write_text(json.dumps(status, indent=2, sort_keys=True) + "\n")
if any(row["rc"] for row in status):
    raise SystemExit(1)
(D / "DEV_JOBS_COMPLETE").write_text("PASS\n")
print(f"completed {len(status)} jobs")
