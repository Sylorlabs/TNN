from __future__ import annotations

import argparse
import importlib.util
import json
import math
import random
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
R39 = ROOT / "R39_ONLINE_FACTOR_EXPERTS_20260917"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


base = load("r39base_for_r46", R39 / "r39_online_factor_experts.py")
wave3 = load("r39wave3_for_r46", R39 / "r39_wave3_stability.py")
dev_worlds = load("r39fresh_for_r46", R39 / "r39_fresh_challenge.py")
r36 = base.r36
STRATS = r36.STRATS
STEPS = r36.STEPS
FDIM = r36.FDIM


class FactorizedLatentResidual:
    FEATURE_DIM = 18

    def __init__(self, lr, success_cap, cost_cap, fast_eta, slow_eta):
        self.core = wave3.FixedBlend(0.70)
        self.count = self.core.count
        self.lr = float(lr)
        self.success_cap = float(success_cap)
        self.cost_cap = float(cost_cap)
        self.fast_eta = float(fast_eta)
        self.slow_eta = float(slow_eta)
        self.fast_s = np.zeros(STRATS); self.slow_s = np.zeros(STRATS)
        self.fast_c = np.zeros(STRATS); self.slow_c = np.zeros(STRATS)
        self.fast_abs_s = np.zeros(STRATS); self.slow_abs_s = np.zeros(STRATS)
        self.fast_abs_c = np.zeros(STRATS); self.slow_abs_c = np.zeros(STRATS)
        self.trace_fast_s = np.zeros((STRATS, FDIM)); self.trace_slow_s = np.zeros((STRATS, FDIM))
        self.trace_fast_c = np.zeros((STRATS, FDIM)); self.trace_slow_c = np.zeros((STRATS, FDIM))
        self.theta_s = np.zeros((STRATS, self.FEATURE_DIM)); self.theta_c = np.zeros((STRATS, self.FEATURE_DIM))
        self.pending = {}; self.updates = 0
        self.residual_abs = 0.0; self.success_residual_abs = 0.0; self.cost_residual_abs = 0.0; self.residual_n = 0
        self.success_residual_max = 0.0; self.cost_residual_max = 0.0

    @staticmethod
    def clip(v):
        return float(np.clip(v, -1.0, 1.0))

    @staticmethod
    def similarity(f, trace):
        den = math.sqrt((float(f @ f) + 1e-9) * (float(trace @ trace) + 1e-9))
        return float(np.clip(float(f @ trace) / den, -1.0, 1.0))

    def raw_components(self, f):
        pf, cf = self.core.factor.predict(f); ps, cs = self.core.stable.predict(f)
        bp = 0.70 * pf + 0.30 * ps; bc = 0.70 * cf + 0.30 * cs
        return pf, cf, ps, cs, bp, bc

    def features(self, f, s, pf, cf, ps, cs):
        success_post = float(self.core.factor.sb.w.max()); cost_post = float(self.core.factor.cb.w.max())
        stable_post = float(self.core.stable.w.max()) if len(self.core.stable.w) else 1.0
        return np.asarray([
            1.0,
            self.clip(self.fast_s[s]), self.clip(self.slow_s[s]), self.clip(self.fast_s[s] - self.slow_s[s]),
            self.clip(self.fast_c[s]), self.clip(self.slow_c[s]), self.clip(self.fast_c[s] - self.slow_c[s]),
            self.clip(self.fast_abs_s[s] - self.slow_abs_s[s]), self.clip(self.fast_abs_c[s] - self.slow_abs_c[s]),
            self.clip((float(pf[s]) - float(ps[s])) / 0.35), self.clip((float(cf[s]) - float(cs[s])) / 0.12),
            self.similarity(f, self.trace_fast_s[s]) - self.similarity(f, self.trace_slow_s[s]),
            self.similarity(f, self.trace_fast_c[s]) - self.similarity(f, self.trace_slow_c[s]),
            self.clip((success_post - 0.5) * 2.0), self.clip((cost_post - 0.5) * 2.0), self.clip((stable_post - 0.5) * 2.0),
            self.clip(float(self.core.factor.sb.evidence)), self.clip(float(self.core.factor.cb.evidence) / 0.5),
        ], dtype=float)

    @staticmethod
    def bounded(theta, z, cap):
        q = math.tanh(float(theta @ z))
        return cap * q, q

    def predict_all(self, f):
        pf, cf, ps, cs, bp, bc = self.raw_components(f)
        p = np.empty(STRATS); c = np.empty(STRATS); zs = []; rs = []; rc = []
        for s in range(STRATS):
            z = self.features(f, s, pf, cf, ps, cs)
            sr, _ = self.bounded(self.theta_s[s], z, self.success_cap); cr, _ = self.bounded(self.theta_c[s], z, self.cost_cap)
            p[s] = np.clip(bp[s] + sr, 0.01, 0.99); c[s] = np.clip(bc[s] + cr, 0.005, 0.45)
            zs.append(z); rs.append(sr); rc.append(cr)
        return bp, bc, p, c, zs, rs, rc

    def predict(self, f):
        x = self.predict_all(f)
        return x[2], x[3]

    def choose(self, f, rng):
        bp, bc, p, c, zs, rs, rc = self.predict_all(f)
        u = p - c
        s = rng.randrange(STRATS) if rng.random() < 0.04 else int(np.argmax(u + 0.08 / np.sqrt(self.count + 1)))
        self.pending.setdefault(f.tobytes(), []).append({"s": s, "z": zs[s], "bp": float(bp[s]), "bc": float(bc[s])})
        sr = abs(float(rs[s])); cr = abs(float(rc[s]))
        self.success_residual_abs += sr; self.cost_residual_abs += cr; self.residual_abs += sr + cr; self.residual_n += 1
        self.success_residual_max = max(self.success_residual_max, sr); self.cost_residual_max = max(self.cost_residual_max, cr)
        return s

    def train(self, theta, z, normalized_target):
        pred = math.tanh(float(theta @ z))
        theta *= 0.9995
        theta += self.lr * (normalized_target - pred) * (1.0 - pred * pred) * z
        np.clip(theta, -2.0, 2.0, out=theta)

    def update(self, s, f, o, c, t):
        key = f.tobytes(); queue = self.pending.get(key); rec = None
        if queue:
            idx = next((i for i, x in enumerate(queue) if x["s"] == s), 0); rec = queue.pop(idx)
            if not queue: self.pending.pop(key, None)
        if rec is None:
            pf, cf = self.core.factor.predict(f); ps, cs = self.core.stable.predict(f)
            bp = 0.70 * pf + 0.30 * ps; bc = 0.70 * cf + 0.30 * cs
            rec = {"z": self.features(f, s, pf, cf, ps, cs), "bp": float(bp[s]), "bc": float(bc[s])}

        raw_s = float(o) - rec["bp"]; raw_c = float(c) - rec["bc"]
        self.train(self.theta_s[s], rec["z"], self.clip(raw_s / max(self.success_cap, 1e-9)))
        self.train(self.theta_c[s], rec["z"], self.clip(raw_c / max(self.cost_cap, 1e-9)))
        signed_s = self.clip(raw_s / 0.35); signed_c = self.clip(raw_c / 0.12); fe, se = self.fast_eta, self.slow_eta
        self.fast_s[s] = (1 - fe) * self.fast_s[s] + fe * signed_s; self.slow_s[s] = (1 - se) * self.slow_s[s] + se * signed_s
        self.fast_c[s] = (1 - fe) * self.fast_c[s] + fe * signed_c; self.slow_c[s] = (1 - se) * self.slow_c[s] + se * signed_c
        self.fast_abs_s[s] = (1 - fe) * self.fast_abs_s[s] + fe * abs(signed_s); self.slow_abs_s[s] = (1 - se) * self.slow_abs_s[s] + se * abs(signed_s)
        self.fast_abs_c[s] = (1 - fe) * self.fast_abs_c[s] + fe * abs(signed_c); self.slow_abs_c[s] = (1 - se) * self.slow_abs_c[s] + se * abs(signed_c)
        self.trace_fast_s[s] = (1 - fe) * self.trace_fast_s[s] + fe * signed_s * f; self.trace_slow_s[s] = (1 - se) * self.trace_slow_s[s] + se * signed_s * f
        self.trace_fast_c[s] = (1 - fe) * self.trace_fast_c[s] + fe * signed_c * f; self.trace_slow_c[s] = (1 - se) * self.trace_slow_c[s] + se * signed_c * f
        self.updates += 1
        self.core.update(s, f, o, c, t); self.count = self.core.count

    def diag(self):
        d = self.core.diag(); n = max(1, self.residual_n)
        d.update({
            "latent_residual_updates": self.updates,
            "mean_abs_success_residual": self.success_residual_abs / n,
            "mean_abs_cost_residual": self.cost_residual_abs / n,
            "mean_abs_utility_correction": self.residual_abs / n,
            "max_abs_success_residual": self.success_residual_max,
            "max_abs_cost_residual": self.cost_residual_max,
            "theta_success_norm": float(np.linalg.norm(self.theta_s)), "theta_cost_norm": float(np.linalg.norm(self.theta_c)),
            "success_cap": self.success_cap, "cost_cap": self.cost_cap,
        })
        return d


CANDIDATES = {
    "latent_cautious": (0.008, 0.10, 0.035, 0.060, 0.010),
    "latent_balanced": (0.015, 0.14, 0.045, 0.080, 0.012),
    "latent_fast": (0.025, 0.18, 0.060, 0.120, 0.018),
}


def model(name):
    if name == "v2": return base.make_model("v2")
    if name == "r36": return base.make_model("r36")
    if name == "r39": return wave3.FixedBlend(0.70)
    if name in CANDIDATES: return FactorizedLatentResidual(*CANDIDATES[name])
    raise KeyError(name)


def run(name, tape, seed, sc, windows, steps):
    F, P, C, O, D = tape; rng = random.Random(seed * 13007 + sum(map(ord, sc))); m = model(name); pending = {}; exp = []; choices = []; opts = []
    for t in range(steps):
        for s, f, o, c in pending.pop(t, []): m.update(s, f, o, c, t)
        tu = P[t] - C[t]; opt = int(np.argmax(tu)); s = m.choose(F[t], rng); choices.append(s); opts.append(opt); exp.append(float(tu[s])); due = t + int(D[t, s]); pending.setdefault(due, []).append((s, F[t].copy(), float(O[t, s]), float(C[t, s])))
    oracle = np.max(P - C, axis=1); exp = np.asarray(exp); choices = np.asarray(choices); opts = np.asarray(opts); boundaries, ret = windows(sc)
    posts = [float(np.mean(oracle[x:min(steps, x + 360)] - exp[x:min(steps, x + 360)])) for x in boundaries]
    rr = float(np.mean(oracle[ret[0]:ret[1]] - exp[ret[0]:ret[1]])) if ret else None
    return {"mean_regret": float(np.mean(oracle - exp)), "optimal": float(np.mean(choices == opts)), "post_change_regret": float(np.mean(posts)), "return_regret": rr, "diag": m.diag()}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--seed", type=int, required=True); ap.add_argument("--scenario", required=True); ap.add_argument("--candidate", required=True); ap.add_argument("--out", required=True); ap.add_argument("--fresh", action="store_true"); a = ap.parse_args()
    if a.fresh:
        fresh = load("r46fresh_runtime", HERE / "r46_fresh_worlds.py"); tape = fresh.make_tape(a.seed, a.scenario); windows = fresh.windows; steps = fresh.STEPS
    else:
        tape = dev_worlds.make_tape(a.seed, a.scenario); windows = dev_worlds.windows; steps = STEPS
    obj = {"seed": a.seed, "scenario": a.scenario, "candidate": a.candidate, "fresh": bool(a.fresh), "result": run(a.candidate, tape, a.seed, a.scenario, windows, steps)}
    Path(a.out).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__": main()

