from __future__ import annotations

import importlib.util
import random
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
R39 = ROOT / "R39_ONLINE_FACTOR_EXPERTS_20260917"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


r39fresh = load("r39fresh_for_r46_fresh", R39 / "r39_fresh_challenge.py")
r36 = r39fresh.r36
STRATS = r36.STRATS
FDIM = r36.FDIM
DELAY = r36.DELAY
STEPS = 5600

SCENARIOS = [
    "very_long_return",
    "cost_reversal_return",
    "corruption_then_return",
    "delayed_recombine",
    "gradual_dynamics",
    "stationary_spikes",
]
SEEDS = [46011, 46023, 46037, 46051]


def discrete_factors(sc, t):
    if sc == "very_long_return":
        if t < 700: return 0, 0
        if t < 1550: return 1, 1
        if t < 2700: return 2, 2
        if t < 4250: return 3, 3
        return 0, 0
    if sc == "cost_reversal_return":
        if t < 900: return 0, 0
        if t < 2050: return 0, 2
        if t < 3400: return 0, 3
        if t < 4400: return 0, 0
        return 0, 2
    if sc == "corruption_then_return":
        if t < 1000: return 0, 0
        if t < 2200: return 1, 1
        if t < 3550: return 2, 0
        return 0, 0
    if sc == "delayed_recombine":
        if t < 850: return 0, 0
        if t < 1750: return 1, 0
        if t < 2700: return 0, 2
        if t < 3900: return 1, 2
        if t < 4750: return 2, 0
        return 0, 0
    if sc == "stationary_spikes": return 0, 0
    raise KeyError(sc)


def gradual_mix(t):
    if t < 900: return 0.0
    if t < 2200: return (t - 900) / 1300.0
    if t < 3500: return 1.0
    if t < 4900: return 1.0 - (t - 3500) / 1400.0
    return 0.0


def make_tape(seed, sc):
    if sc not in SCENARIOS: raise KeyError(sc)
    ctx = r36.gen_contexts(seed * 29 + 607)
    rng = random.Random(seed * 1777 + sum(map(ord, sc)))
    F = np.zeros((STEPS, FDIM)); P = np.zeros((STEPS, STRATS)); C = np.zeros((STEPS, STRATS)); O = np.zeros((STEPS, STRATS)); D = np.zeros((STEPS, STRATS), int)
    for t in range(STEPS):
        f = r36.phi3([rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-1, 1)]); F[t] = f
        if sc == "gradual_dynamics":
            q = gradual_mix(t); Ws = (1 - q) * ctx[0][0] + q * ctx[1][0]; Wc = (1 - q) * ctx[0][1] + q * ctx[2][1]
        else:
            si, ci = discrete_factors(sc, t); Ws, Wc = ctx[si][0], ctx[ci][1]
        p = np.array([r36.sigmoid(Ws[s] @ f) for s in range(STRATS)]); c = np.array([0.02 + 0.28 * r36.sigmoid(Wc[s] @ f) for s in range(STRATS)])
        P[t] = p; C[t] = c
        corrupt_success = sc == "corruption_then_return" and 3420 <= t < 3600
        spike = sc == "stationary_spikes" and (850 <= t < 970 or 2380 <= t < 2520 or 4100 <= t < 4250)
        for s in range(STRATS):
            qobs = p[s]
            if corrupt_success and rng.random() < 0.72: qobs = 1 - p[s]
            O[t, s] = 1.0 if rng.random() < qobs else 0.0
            if spike: C[t, s] = min(0.45, max(0.01, c[s] + rng.uniform(0.07, 0.16)))
            D[t, s] = rng.randint(*DELAY)
    return F, P, C, O, D


def windows(sc):
    if sc == "very_long_return": return [700, 1550, 2700, 4250], (4250, 5450)
    if sc == "cost_reversal_return": return [900, 2050, 3400, 4400], (4400, 5450)
    if sc == "corruption_then_return": return [1000, 2200, 3550], (3550, 5350)
    if sc == "delayed_recombine": return [850, 1750, 2700, 3900, 4750], (4750, 5500)
    if sc == "gradual_dynamics": return [900, 2200, 3500, 4900], (4900, 5500)
    if sc == "stationary_spikes": return [850, 970, 2380, 2520, 4100, 4250], None
    raise KeyError(sc)

