from pathlib import Path
import json
import statistics

D = Path(__file__).resolve().parent
ROOT = D.parent
R41 = ROOT / "R41_STRATEGY_RELIABILITY_20260917"
R42 = ROOT / "R42_STATE_CONDITIONED_RELIABILITY_20260917"

new_rows = [json.loads(p.read_text()) for p in sorted((D / "dev_jobs").glob("*.json"))]


def inherited(directory, suffix):
    return [json.loads(p.read_text()) for p in sorted((directory / "dev_jobs").glob(f"*_{suffix}.json"))]


controls = {
    "v2": inherited(R41, "v2"),
    "r36": inherited(R41, "r36"),
    "r39": inherited(R41, "r39"),
}
historical = {
    "r42_state_cautious": inherited(R42, "state_cautious"),
    "r42_state_balanced": inherited(R42, "state_balanced"),
    "r42_state_fast": inherited(R42, "state_fast"),
}


def normalize(row):
    return {"seed": row["seed"], "scenario": row["scenario"], "result": row["result"]}


def rows_for(name):
    if name in controls:
        return [normalize(r) for r in controls[name]]
    if name in historical:
        return [normalize(r) for r in historical[name]]
    return [normalize(r) for r in new_rows if r["candidate"] == name]


def mean(name, key, scenario=None):
    values = [r["result"][key] for r in rows_for(name) if (scenario is None or r["scenario"] == scenario) and r["result"][key] is not None]
    return statistics.mean(values)


def summary(name):
    rows = rows_for(name)
    diag = [r["result"]["diag"] for r in rows]
    out = {
        "rows": len(rows),
        "mean_regret": mean(name, "mean_regret"),
        "post_change_regret": mean(name, "post_change_regret"),
        "return_regret": mean(name, "return_regret"),
        "cost_recurrence_return": mean(name, "return_regret", "cost_recurrence"),
        "unseen_pairing_return": mean(name, "return_regret", "unseen_pairing"),
        "cross_noise_mean": mean(name, "mean_regret", "cross_noise"),
        "max_success_experts": max(d.get("success_experts", 1) for d in diag),
        "max_cost_experts": max(d.get("cost_experts", 1) for d in diag),
        "min_residual_updates": min(d.get("latent_residual_updates", 0) for d in diag),
        "mean_abs_utility_correction": statistics.mean(d.get("mean_abs_utility_correction", 0.0) for d in diag),
    }
    v2 = {(r["seed"], r["scenario"]): r["result"] for r in rows_for("v2")}
    ratios = []
    for row in rows:
        baseline = v2[(row["seed"], row["scenario"])]
        result = row["result"]
        if result["return_regret"] is not None and baseline["return_regret"] not in (None, 0):
            ratios.append(result["return_regret"] / baseline["return_regret"])
    out["worst_return_ratio_vs_v2"] = max(ratios) if ratios else None
    return out


candidate_names = ["latent_cautious", "latent_balanced", "latent_fast"]
all_names = list(controls) + list(historical) + candidate_names
summaries = {name: summary(name) for name in all_names}
base = summaries["r39"]
candidates = {}
for name in candidate_names:
    x = summaries[name]
    gates = {
        "cost_recurrence": x["cost_recurrence_return"] <= 0.95 * base["cost_recurrence_return"],
        "worst_return": x["worst_return_ratio_vs_v2"] < base["worst_return_ratio_vs_v2"],
        "mean_return": x["return_regret"] <= base["return_regret"],
        "overall": x["mean_regret"] <= 1.01 * base["mean_regret"],
        "post_change": x["post_change_regret"] <= base["post_change_regret"],
        "unseen_pairing": x["unseen_pairing_return"] <= 1.02 * base["unseen_pairing_return"],
        "cross_noise": x["cross_noise_mean"] <= 1.02 * base["cross_noise_mean"],
        "bounded_and_exercised": x["max_success_experts"] <= 5 and x["max_cost_experts"] <= 5 and x["min_residual_updates"] >= 100 and x["mean_abs_utility_correction"] >= 0.003,
    }
    candidates[name] = {**x, "gates": gates, "pass": all(gates.values())}

passing = [name for name, x in candidates.items() if x["pass"]]
selected = min(passing, key=lambda n: (candidates[n]["cost_recurrence_return"], candidates[n]["worst_return_ratio_vs_v2"], candidates[n]["return_regret"])) if passing else None

out = {
    "status": "R46_DEVELOPMENT",
    "candidate_job_count": len(new_rows),
    "paired_control_source": "R41_STRATEGY_RELIABILITY_20260917/dev_jobs",
    "historical_control_source": "R42_STATE_CONDITIONED_RELIABILITY_20260917/dev_jobs",
    "controls": {name: summaries[name] for name in controls},
    "historical_controls": {name: summaries[name] for name in historical},
    "candidates": candidates,
    "selected_for_fresh": selected,
    "fresh_open_allowed": selected is not None,
}
(D / "DEV_RESULTS.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
print(json.dumps(out, indent=2, sort_keys=True))
