# R32 Handoff — Epistemic World-State Uncertainty + Native Self-Chunking

R31 should not be restarted. Its central architecture decision is supported:

`raw episodic route + endogenous reversible chunks + active grounded evidence`

## Priority 0 — Native Zag authority
Obtain a real `znc` from `Sylorlabs/zag`, persist it durably, compile the exact R31 source, repair source incompatibilities, run deterministic double-build/checked parity, and reproduce the quantitative gates natively. No Python result promotes.

## Priority 1 — Epistemic ambiguity representation
The best R31 policy handles misleading evidence well but recognizes only ~57% of deliberately no-unique-answer cases. Do not add another fixed probe threshold.

Build a persistent non-graph hypothesis population that represents:
- multiple possible referents/world states;
- evidence provenance and dependence;
- probability/evidence mass that remains unresolved;
- temporal stability/instability of the latent source;
- cross-modal consistency;
- expected information gain of another observation;
- explicit `UNKNOWN` when remaining hypotheses cannot be discriminated economically.

Train only from delayed outcomes/regret; do not expose an ambiguity label.

## Priority 2 — Native dual-route chunking
Port/reproduce the causal ablation natively:
- raw-only;
- chunk-only;
- dual raw+chunk.

The native system should retain chunk compression/indexing while proving that exact raw episodic retrieval preserves hard discriminative capability.

## Priority 3 — Chunk resource policy
Use TNN-controlled memory to decide:
- which chunks deserve exact raw exemplars;
- which can be compressed;
- when to retrieve raw evidence;
- when a chunk should split, merge, specialize, archive, or be rebuilt.

Use future regret and resource envelopes, not aesthetic compression targets.

## Priority 4 — Natural continuous media
Move self-chunking from synthetic microstate streams toward natural synchronized raw audio/video/action streams. Evaluator annotations may score human-aligned boundaries after the fact but never enter TNN cognition.

No pretrained ASR, vision model, tokenizer, transformer, or LLM inside TNN.

## Priority 5 — Long native life
Run >=250k events if curves justify it, with recurring world regimes, entity replacements, natural coarticulation, siblings with different chunk histories, teacher withdrawal, save/reload, resource pressure, and self-revision.

Persist every major checkpoint immediately to `/TNN/Research`.
